package loto;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Tirage extends JPanel implements ActionListener{

	private JButton btRandTirage;
	private JLabel[] lRand;
	
	public Tirage() {
		super();
	
		GridLayout grille = new GridLayout(2,8);
		this.setLayout(grille);
		
		int i;
		
		JLabel[] lTxt = new JLabel[8];
		
		lTxt[0] = newCenterLabel("Tirage");
		this.add(lTxt[0]);
		for(i=0; i<7; i++)
		{
			lTxt[i] = newCenterLabel(String.valueOf(i+1));
			this.add(lTxt[i]);
		}
		lTxt[6].setForeground(Color.RED);
		
		URL imgURL = getClass().getResource("trefle.jpeg");
		ImageIcon img = new ImageIcon(imgURL);
		
		btRandTirage = new JButton(img);
		this.add(btRandTirage);
		lRand = new JLabel[7];
		for(i=0; i<7; i++)
		{
			lRand[i] = newCenterLabel("");
			this.add(lRand[i]);
		}
		lRand[6].setForeground(Color.RED);
		
		btRandTirage.addActionListener(this);
	}

	//on cree un nouveau label centre
	private JLabel newCenterLabel(String txt)
	{
		JLabel label = new JLabel(txt);
		label.setHorizontalAlignment(JLabel.CENTER);
		return label;
	}

	public void actionPerformed(ActionEvent e) {
		JButton evenSource = (JButton)e.getSource();
		if(evenSource == btRandTirage){
			int[] nb = new int[7];
			int i, j;
			boolean estChoisi;
			
			//on genere les chiffres
			for(i=0; i<7; i++)
			{
				do
				{
					nb[i] = (int) (Math.random()*49) + 1; //1 <= nb <= 49
					
					estChoisi = true;
					
					for(j=0; j<i; j++)
					{
						if(nb[i] == nb[j]) estChoisi = false;
					}
				} while(!estChoisi);
			}
			
			//on affiche les chiffres
			for(i=0; i<7; i++)
			{
				lRand[i].setText(String.valueOf(nb[i]));
			}
		}
	}
}
