package loto;

import java.awt.Container;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JApplet;

import com.sun.j3d.utils.applet.MainFrame;

public class Loto extends JApplet{

	public Loto() throws IOException 
    {
		Container myFrame = this.getContentPane();
		myFrame.setLayout(new BoxLayout(myFrame, BoxLayout.Y_AXIS));
		
		this.setSize(512, 512);
		
		URL imgURL = getClass().getResource("logoloto.jpeg");
		//on affiche le patch
		System.out.println(imgURL.getPath());
		//File imgSrc = new File(imgURL.getPath());
		
		ImageIcon imgData = new ImageIcon(imgURL);
		
		
		JImagePanel image = new JImagePanel(imgData.getImage());
		myFrame.add(image);
		
		Tirage tirage = new Tirage();
		myFrame.add(tirage);
    }
	
	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		new MainFrame(new Loto(), 570, 570); //on cree la fenetre
	}

}
