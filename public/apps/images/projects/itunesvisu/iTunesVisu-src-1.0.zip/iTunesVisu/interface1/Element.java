package interface1;

import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;

import filtres.FiltresEvent;

import visu.User;
import visu.UserTrack;

public class Element extends Item{
	UserTrack eUT; //UserTrack caracterisant l'element
	User eU;//utilisateur qui possede le UserTrack
	boolean isInWheel; //indique si l'element appartient a la roue ou non
	
	/**
	 * on rend unique les noms, artist, album, track en les prefixant par 3 lettres + "_"
	 */ 
	Element(UserTrack ut, double rank, User u) {
		super("Nom_"+ut.getName());
		
		eUT = ut;
		eU = u;
		
		colorVal = ut.getRating(u) / 100;
		if(colorVal > 1) colorVal = 1;
		if(colorVal < 0) colorVal = 0;
		
		this.rank = rank;
	}
	
	public String getArtist() {
		return "Art_"+eUT.getArtiste().getName();
	}
	
	public String getAlbum() {
		return "Alb_"+eUT.getAlbum().getName();
	}
	
	public String getGenre() {
		return "Gen_"+eUT.getGenre().getName();
	}
	
	public String getType() {
		return "Typ_"+eUT.getKind().getName();
	}
	
	public String getPlayCount() {
		return "P_C_"+eUT.getPlayCount(eU);
	}
	
	public String getTaille() {
		return "Siz_"+(int)(eUT.getSize()/1000000);
	}

	public String getDuree() {
		return "Tim_"+eUT.getTotalTimeMinute();
	}
	
	public String getBitRate() {
		return "B_R_"+eUT.getBitRate();
	}

	public String getSampleRate() {
		return "S_R_"+eUT.getSampleRate();
	}
	
	public String getRating() {
		return "Rat_"+(int)(eUT.getRating(eU)); //on arrondi a l'entier
	}
	
	@Override
	public void displayConsole() {
		for(int i=0; i<level; i++)
		{
			System.out.print("  ");
		}
		System.out.println(nom+" | "+rank +" | "+getGenre()+", "+getAlbum()+", "+getArtist());
	}
	
	@Override
	Collection<Item> getChilds() {
		//il n'y a pas d'enfants dans un element
		return new ArrayList<Item>();
	}
	
	@Override
	public String getGroupBy(String groupBy) {
		if(groupBy.equals("Artist")) return getArtist();
		else if(groupBy.equals("Album")) return getAlbum();
		else if(groupBy.equals("Genre")) return getGenre();
		else if(groupBy.equals("Type")) return getType();
		else if(groupBy.equals("PlayCount")) return getPlayCount();
		else if(groupBy.equals("Taille")) return getTaille();
		else if(groupBy.equals("Duree")) return getDuree();
		else if(groupBy.equals("BitRate")) return getBitRate();
		else if(groupBy.equals("SampleRate")) return getSampleRate();
		else if(groupBy.equals("Rating")) return getRating();
		else return getGenre();
	}

	@Override
	public double addItem(Item i, Wheel wheel) {
		//on ne fait rien car on n'ajoute pas d'item enfant dans un element
		return 0;
	}

	@Override
	void removeItem(Item i, double removeRank, Wheel wheel) {
		if(parent != null) parent.removeItem(this, this.rank, wheel);
	}

	@Override
	void addGroupBy(String groupBy, int levelToReach, Wheel wheel) {
		//on ne fait rien, car on ne regroupe pas un element
	}
	
	@Override
	void removeGroupBy(String groupBy, int levelToReach, Wheel wheel) {
		//on ne fait rien, car on ne degroupe pas un element
	}
	
	//retourne si l'element est inclu dans le filtre ou pas
	public boolean isInFiltre(FiltresEvent e) {
		return eUT.isInFiltre(e, eU);
	}

	public void setInWheel(boolean val) {
		isInWheel = val;
	}
	
	public boolean isInWheel() {
		return isInWheel;
	}
	
	public void mouseClicked(int radiusMouse, int angleMouse) {
		boolean isCollideCliked = radiusMouse > radiusMin && radiusMouse < radiusMax &&
								  angleRight > angleMouse && angleLeft < angleMouse;
		
		if(isCollideCliked) {
			Outils.setInfosUT(eUT, eU);
		}
	}
}
