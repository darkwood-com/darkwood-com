package interface1;

public class AngleCalculation {
	static final double PI = 4 * Math.atan(1);
	static final double DEG_TO_RAD = PI / 180;
	static final double RAD_TO_DEG = 1 / DEG_TO_RAD;
	
	static final int detailLevel = 1; // > 0
	static private double[] cosVal;
	static private double[] sinVal;
	
	/*
	 * les angles sont compris entre 0 et 360 degres
	 */
	static double getCosVal(double deg) {
		int degInt = (int) deg;
		degInt = degInt % 360;
		return cosVal[degInt * detailLevel];
	}
	
	static double getSinVal(double deg) {
		int degInt = (int) deg;
		degInt = degInt % 360;
		return sinVal[degInt * detailLevel];
	}
	
	public AngleCalculation()
	{
		final int nbValues = 360 * detailLevel;
		cosVal = new double[nbValues];
		sinVal = new double[nbValues];
		
		for(int i = 0; i < nbValues; i++) {
			cosVal[i] = Math.cos((double)i / detailLevel * DEG_TO_RAD);
			sinVal[i] = Math.sin((double)i / detailLevel * DEG_TO_RAD);
		}
	}
}
