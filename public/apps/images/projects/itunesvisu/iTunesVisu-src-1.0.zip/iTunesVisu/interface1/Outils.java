package interface1;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;

import visu.DateVizu;
import visu.Genre;
import visu.Kind;
import visu.Track;
import visu.TrackNumber;
import visu.User;
import visu.UserTrack;

public class Outils extends JPanel implements ActionListener {
	Wheel wheel;
	
	static LinkedList<String> elementsRetires;
	
	JComboBox combo;
	DefaultComboBoxModel comboModel;
	JButton ajouter;
	JButton retirer;
	JCheckBox isDisplayFast;
	
	static JPanel infos;

	static JLabel infosUTLabel;
	static JLabel infosUTname;
	static JLabel infosUTgenre;
	static JLabel infosUTartist;
	static JLabel infosUTkind;
	static JLabel infosUTsize;
	static JLabel infosUTtotalTime;
	static JLabel infosUTdataAdded;
	static JLabel infosUTbitRate;
	static JLabel infosUTplayCount;
	static JLabel infosUTrating;
	
	Outils() {
		super();
		
		elementsRetires = new LinkedList<String>();
		
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
		comboModel = new DefaultComboBoxModel();
		comboModel.addElement("Artist");
		comboModel.addElement("Album");
		comboModel.addElement("Genre");
		comboModel.addElement("Type");
		comboModel.addElement("PlayCount");
		comboModel.addElement("Taille");
		comboModel.addElement("Duree");
		comboModel.addElement("BitRate");
		comboModel.addElement("SampleRate");
		comboModel.addElement("Rating");
		
		combo = new JComboBox(comboModel);
		combo.setMaximumSize(combo.getPreferredSize());
		
		
		ajouter = new JButton("Grouper");
		retirer = new JButton("D�grouper");
		
		infos = new JPanel();
		infos.setLayout(new BoxLayout(infos, BoxLayout.Y_AXIS));
		//creation du premier type d'info
		infosUTLabel = new JLabel();
		infos.add(infosUTLabel);
		infosUTname = new JLabel("Aucun");
		infos.add(infosUTname);
		infosUTgenre = new JLabel();
		infos.add(infosUTgenre);
		infosUTartist = new JLabel();
		infos.add(infosUTartist);
		infosUTkind = new JLabel();
		infos.add(infosUTkind);
		infosUTsize = new JLabel();
		infos.add(infosUTsize);
		infosUTtotalTime = new JLabel();
		infos.add(infosUTtotalTime);
		infosUTdataAdded = new JLabel();
		infos.add(infosUTdataAdded);
		infosUTbitRate = new JLabel();
		infos.add(infosUTbitRate);
		infosUTplayCount = new JLabel();
		infos.add(infosUTplayCount);
		infosUTrating = new JLabel();
		infos.add(infosUTrating);
		
		isDisplayFast = new JCheckBox("Rendu Rapide");
		isDisplayFast.setSelected(Wheel.isFastDisplay);
		
		this.add(Box.createVerticalGlue());
		addJComponent(infos);
		this.add(Box.createVerticalGlue());
		addJComponent(combo);
		addJComponent(ajouter);
		addJComponent(retirer);
		this.add(Box.createVerticalGlue());
		addJComponent(isDisplayFast);
		this.add(Box.createVerticalGlue());
		URL imgURL = getClass().getResource("legende.jpg");
	    ImageIcon imgData = new ImageIcon(imgURL);
	    JImagePanel legende = new JImagePanel(imgData.getImage());
	    addJComponent(legende);
	    
		ajouter.addActionListener(this);
		retirer.addActionListener(this);
		isDisplayFast.addActionListener(this);
	}

	public void addJComponent(JComponent jC) {
		this.add(jC);
		jC.setAlignmentX(Component.CENTER_ALIGNMENT);
	}
	
	public void setWheel(Wheel wheel) {
		this.wheel = wheel;
	}

	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == ajouter) {
			String group = (String) combo.getSelectedItem();
			elementsRetires.addLast(group);
			combo.removeItem(group);
			wheel.addGroupBy(group);
		} else if(e.getSource() == retirer) {
			if(elementsRetires.size() > 0) {
				wheel.removeGroupBy();
				combo.addItem(elementsRetires.removeLast());
			}
		} else if(e.getSource() == isDisplayFast) {
			Wheel.isFastDisplay = !Wheel.isFastDisplay;
		}
	}
	
	static public void setInfos(String newInfos, int level) {
		infosUTLabel.setText(elementsRetires.get(level - 1));
		infosUTname.setText(newInfos);
		infosUTgenre.setText("");
		infosUTartist.setText("");
		infosUTkind.setText("");
		infosUTsize.setText("");
		infosUTtotalTime.setText("");
		infosUTbitRate.setText("");
		infosUTplayCount.setText("");
		infosUTrating.setText("");
	}
	
	static public void setInfosUT(UserTrack ut, User u) {
		infosUTLabel.setText("");
		infosUTname.setText("Nom : "+ut.getName());
		infosUTgenre.setText("Genre : "+ut.getGenre().getName());
		infosUTartist.setText("Artist : "+ut.getArtiste().getName());
		infosUTkind.setText("Type : "+ut.getKind().getName());
		infosUTsize.setText("Taille : "+ut.getSize() /(1000000)+" Mo");
		infosUTtotalTime.setText("Duree : "+(ut.getTotalTime() / (60 * 1000))+" min");
		infosUTbitRate.setText("Bitrate : "+ut.getBitRate()+" kBits");
		
		infosUTplayCount.setText("PlayCount : "+ut.getPlayCount(u));
		infosUTrating.setText("Rating : "+(int)ut.getRating(u)+"/100");
	}

	public void clean() {
		int nbElts = elementsRetires.size();
		for(int i = 0; i < nbElts; i++) {
			combo.addItem(elementsRetires.removeLast());
		}
	}
}
