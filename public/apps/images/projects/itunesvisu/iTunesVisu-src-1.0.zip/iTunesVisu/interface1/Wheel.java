package interface1;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.util.LinkedList;

import javax.swing.JPanel;

public class Wheel extends JPanel{
	public static int currentLevel; //niveau actuel de regrouppement
	public static final int CD_HoleSize = 10; //trou du CD
	public static int centerX, centerY;
	public static int radiusMax;
	public static boolean isFastDisplay = false; //affichage rapide ou non
	
	private int width, height; //taille du component
	LinkedList<String> currentGroupBy; //nom des types de groupe courament affiches
	
	Group root; //racine de l'arbre
	
	Wheel(int width, int height) {
		super();
		
		//calcule les angles
		new AngleCalculation();
		
		resize(width, height);
		
		setLayout(null);
		setVisible(true);
		
		this.clean();
	}
	
	public void resize(int width, int height) {
		this.width = width;
		this.height = height;
		
		//on met a jour le centre et le rayon maximum de la roue
		//qui seront reprit directement pour l'affichage des items
		this.centerX = width / 2;
		this.centerY = height / 2;
		
		if(this.width > this.height)
		{
			this.radiusMax = this.centerY;
		} else {
			this.radiusMax = this.centerX;
		}
	}
	
	public void addElement(Element e) {
		//on cree une branche de l'element selon les groupes
		Item limb;
		if(currentGroupBy.isEmpty()) {
			limb = e;
		} else {
			limb = new Group(1, currentGroupBy, e);
		}
		
		//on fusionne cette branche a l'arbre recursivement
		root.addItem(limb, this);
		
		//l'element appartient a la roue
		e.setInWheel(true);
		
		mouseMoved(centerX, centerY);
	}
	
	public void removeElement(Element e) {
		e.removeItem(null, 0, this);

		//l'element n'appartient plus a la roue
		e.setInWheel(false);
		
		mouseMoved(centerX, centerY);
	}
	
	public void addGroupBy(String goupBy) {
		currentGroupBy.addLast(goupBy);
		root.addGroupBy(goupBy, currentLevel, this);
		
		currentLevel++;
		
		mouseMoved(centerX, centerY);
	}
	
	public void removeGroupBy() {
		currentLevel--;
		String lastGroupBy = currentGroupBy.removeLast();
		root.removeGroupBy(lastGroupBy, currentLevel, this);
		
		mouseMoved(centerX, centerY);
	}
	
	public void displayConsole() {
		root.displayConsole();
	}
	
	public synchronized void paintComponent(Graphics g) {
		super.paintComponent(g); //on efface les graphiques avant de repeindre
		Graphics2D gr=(Graphics2D) g;
		
		/*RenderingHints rh = new RenderingHints(
				RenderingHints.KEY_TEXT_ANTIALIASING,
				RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
		gr.setRenderingHints(rh);*/
		
		root.paintRoot(gr);
		
		//on affiche les cercles intermediaires qui delimitent les niveaux
		gr.drawArc(centerX - Wheel.CD_HoleSize, centerY - Wheel.CD_HoleSize,
				Wheel.CD_HoleSize * 2, Wheel.CD_HoleSize * 2, 0, 360);
		int radiusLevel;
		for(int level = 0; level <= Wheel.currentLevel; level++) {
			radiusLevel = Wheel.radiusMax;
			radiusLevel -= Wheel.CD_HoleSize;
			radiusLevel = (int)(radiusLevel * (level + 1) * 1.0 / (Wheel.currentLevel + 1));
			radiusLevel += Wheel.CD_HoleSize;
			
			gr.drawArc(centerX - radiusLevel, centerY - radiusLevel,
					radiusLevel * 2, radiusLevel * 2, 0, 360);
		}
	}

	public void mouseMoved(int mX, int mY) {
		mX -= centerX;
		mY -= centerY;
		
		//calcul du rayon que fait la souris avec la roue
		int radiusMouse = (int) Math.sqrt(mX*mX + mY*mY);
		
		//calcul de l'angle que fait la souris sur la roue
		int angleMouse = - (int) (Math.atan2(mY, mX) * AngleCalculation.RAD_TO_DEG);
		if(angleMouse < 0  ) angleMouse += 360;
		if(angleMouse > 360) angleMouse -= 360;
		
		root.checkCollideRoot(radiusMouse, angleMouse);
	}

	public void mouseClicked(int mX, int mY) {
		mX -= centerX;
		mY -= centerY;
		
		//calcul du rayon que fait la souris avec la roue
		int radiusMouse = (int) Math.sqrt(mX*mX + mY*mY);
		
		//calcul de l'angle que fait la souris sur la roue
		int angleMouse = - (int) (Math.atan2(mY, mX) * AngleCalculation.RAD_TO_DEG);
		if(angleMouse < 0  ) angleMouse += 360;
		if(angleMouse > 360) angleMouse -= 360;
		
		root.mouseClickedRoot(radiusMouse, angleMouse);
	}

	/**
	 * on vide la roue
	 *
	 */
	public void clean() {
		currentLevel = 0;
		currentGroupBy = new LinkedList<String>();
		root = new Group("root");
	}
}
