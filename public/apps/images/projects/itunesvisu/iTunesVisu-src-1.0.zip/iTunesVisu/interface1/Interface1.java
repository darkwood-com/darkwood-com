package interface1;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ComponentEvent;
import java.awt.event.ComponentListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;

import javax.swing.JFrame;
import javax.swing.JPanel;

import filtres.FiltresEvent;
import filtres.FiltresListener;
import filtres.InterfaceFiltres;


import visu.User;
import visu.UserTrack;
import visu.Visu;

public class Interface1 extends JPanel implements ComponentListener, MouseListener, MouseMotionListener, FiltresListener{
	Wheel wheel;
	Outils outils;
	public MouseEvent currMouse;
	
	final int hauteurFenetre = 25;
	
	private ArrayList<UserTrack> currListDisplayed;
	
	//liste de tous les elements ajoutes ou non a la roue
	LinkedList<Element> elements = new LinkedList<Element>();
	
	public Interface1(int width, int height) {
		//setTitle("Interface 1"); //On donne un titre a l'application
		setSize(width,height); //On donne une taille a notre fenetre
		//setLocationRelativeTo(null); //On centre la fenetre sur l'ecran
		//setResizable(true); //On autorise la redimensionnement de la fenetre
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //On dit a l'application de se fermer lors du clic sur la cro
		setLayout(new BorderLayout());
		
		this.addComponentListener(this);
		this.addMouseMotionListener(this);
		this.addMouseListener(this);
		
		outils = new Outils();
		this.add(outils, BorderLayout.EAST);
		
		//width - 150 taille de la barre d'outils
		//height - 25 car la barre de titre est contenue dans la hauteur de la fenetre
		wheel = new Wheel(width - 150,height - hauteurFenetre);
		this.add(wheel, BorderLayout.CENTER);
		outils.setWheel(wheel);
		
		setVisible(true);//On rend la roue visible
		
		currMouse = null;
		
		currListDisplayed = null;
	}
	
	public void modifyUser(User u, ArrayList<UserTrack> l) {
		//si on change de liste on remet toutes l'interface a zero
		if(currListDisplayed != l)
		{
			wheel.clean();
			outils.clean();
			elements.clear();
			
			currListDisplayed = l;
			
			Element e;
			Iterator<UserTrack> it = l.iterator();
			while(it.hasNext()) {
				e = new Element(it.next(), 1, u);
				wheel.addElement(e);
				elements.add(e);
			}
			//this.repaint();
		}
	}

	/**
	 * MouseListener
	 */
	public void mouseClicked(MouseEvent e) {
		currMouse = e;
		int mX = (int) currMouse.getPoint().getX();
	    int mY = (int) currMouse.getPoint().getY();
	    
	    wheel.mouseClicked(mX, mY - hauteurFenetre);
	}

	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * MouseMotionListener
	 */
	public void mouseDragged(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void mouseMoved(MouseEvent e) {
		currMouse = e;
		int mX = (int) currMouse.getPoint().getX();
	    int mY = (int) currMouse.getPoint().getY();
	    
	    wheel.mouseMoved(mX, mY - hauteurFenetre);
	    
	    //this.repaint();
	}
	
	/**
	 * ComponentListener
	 */
	public void componentHidden(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void componentMoved(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void componentResized(ComponentEvent e) {
		Dimension dim = this.getSize();
		
		//width,height - 25 car la barre de titre est contenue dans la hauteur de la fenetre
		wheel.resize((int)dim.getWidth() - outils.getWidth(), (int)dim.getHeight() - hauteurFenetre);
		
		//this.repaint();
	}
	
	public void componentShown(ComponentEvent e) {
		// TODO Auto-generated method stub
		
	}
	
	/**
	 * FiltresListener
	 */
	public void filtresChanged(FiltresEvent e) {
		//quand on recoit les filtres, on remet a jour l'interface
		//si l'on change d'utilisateur
		if(e.u != null && e.listeUT !=null)
		{
			modifyUser(e.u, e.listeUT);
		}
		
		Element elt;
		Iterator<Element> it = elements.iterator();
		boolean isInFiltre, isInWheel;
		while(it.hasNext()) {
			elt = it.next();
			isInFiltre = elt.isInFiltre(e);
			isInWheel = elt.isInWheel();
			
			if(isInFiltre && !isInWheel) {
				//on ajoute a la roue si l'element est dans le filtre
				wheel.addElement(elt);
			} else if(!isInFiltre && isInWheel) {
				//on retire de la roue si l'element n'est pas dans le filtre
				wheel.removeElement(elt);
			}
			//dans les deux autres cas, on ne change rien, car
			//l'element est dans le filtre et dans la roue ou
			//l'element n'est pas dans le filtre et pas dans la roue
		}
	}
	
	/**
	 * main
	 * @param args
	 */
	public static void main(String[] args) {
		User u = Visu.getInstance().getUser1();
		JFrame j=new JFrame();
		Interface1 i1 = new Interface1(800, 600);
		i1.modifyUser(u, u.getPossede());
		
		InterfaceFiltres IF= new InterfaceFiltres();
		IF.addFiltresListener(i1);
		
		//thread pour animer l'affichage
		ThreadInterface1 TI = new ThreadInterface1(i1);
		TI.start();
		
		j.add(i1);
	}
}
