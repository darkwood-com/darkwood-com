package interface1;

import java.awt.Graphics2D;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

public class Group extends Item{
	//sous items du groupe identifies directement par leur nom
	HashMap<String, Item> subItems;
	//subItems = subItemsPos, sauf que l'on conserve la position des elements
	LinkedList<Item> subItemsPos;
	
	Group(String name){
		super(name);
		
		subItems = new HashMap<String, Item>();
		subItemsPos = new LinkedList<Item>();
	}
	
	//constructeur particulier pour creer des branches a un niveau donne
	//currentGroupBy n'est pas vide
	Group(int level, LinkedList<String> currentGroupBy, Element e){
		super("limb");
		subItems = new HashMap<String, Item>();
		subItemsPos = new LinkedList<Item>();
		this.level = level;
		
		Iterator<String> it = currentGroupBy.iterator();
		nom = e.getGroupBy(it.next());
		Item limbIt = this;
		Group g;
		while(it.hasNext()) {
			g = new Group(e.getGroupBy(it.next()));
			limbIt.addItem(g, null);
			limbIt.rank = e.rank;
			
			limbIt = g;
		}
		
		limbIt.addItem(e, null);
		limbIt.rank = e.rank;
	}
	
	@Override
	Collection<Item> getChilds() {
		return subItems.values();
	}

	@Override
	public void displayConsole() {
		super.displayConsole();
		Iterator<Item> it = subItems.values().iterator();
		while(it.hasNext()) {
			(it.next()).displayConsole();
		}
	}
	
	@Override
	String getGroupBy(String groupBy) {
		//normalement, on a pas a connaitre le regrouppement par groupe
		return "NodeGroup";
	}
	
	@Override
	public double addItem(Item i, Wheel wheel) {		
		if(subItems.containsKey(i.nom))
		{
			Item subItemExist = subItems.get(i.nom);
			//si le nom existe deja,
			//on ajoute les elements du sous groupe dans le sous groupe existant
			Iterator<Item> it = i.getChilds().iterator();
			while(it.hasNext()) {
				rank += subItemExist.addItem(it.next(), wheel);
			}
		}
		else
		{
			//sinon l'item n'exite pas et on ajoute un nouveau item dans ce groupe
			i.level = level + 1;
			i.parent = this;
			subItems.put(i.nom, i);
			subItemsPos.add(i);
			
			//on ajoute le rank de l'item a ce groupe
			rank += i.rank;
		}
		
		return i.rank;
	}

	@Override
	void removeItem(Item i, double removeRank, Wheel wheel) {
		//on soustrait le rank
		this.rank -= removeRank;
		//on retire l'enfant s'il est precise
		if(i != null) {
			subItems.remove(i.getNom());
			subItemsPos.remove(i);
		}
		
		if(parent != null){
			if(subItems.isEmpty()) parent.removeItem(this, removeRank, wheel);
			else 				   parent.removeItem(null, removeRank, wheel);
		}
	}
	
	void addGroupBy(String groupBy, int levelToReach, Wheel wheel) {
		if(levelToReach > 0) {
			//tant que l'on est pas a la profondeur voulue
			//on regroupera a tous les fils de profondeur - 1
			Iterator<Item> it = subItems.values().iterator();
			while(it.hasNext()) {
				(it.next()).addGroupBy(groupBy, levelToReach - 1, wheel);
			}
		} else {
			//on est a la profondeur voulue, on regroupe les elements
			
			//sous groups du groupe qui seront formes
			HashMap<String, Item> subGroups = new HashMap<String, Item>();
			LinkedList<Item> elementsRegroupes = new LinkedList<Item>();
			
			String groupE;
			Item e, g;
			Iterator<Item> it = subItems.values().iterator();
			while(it.hasNext()) {
				//techniquement, les items enfants a regrouper sont des elements
				e = it.next();
				groupE = e.getGroupBy(groupBy);
				if(subGroups.containsKey(groupE)) {
					g = subGroups.get(groupE);
				} else {
					g = new Group(groupE);
					g.level = this.level + 1;
					subGroups.put(groupE, g);
				}
				
				//que l'on met dans le groupe cree
				g.addItem(e, null);
				elementsRegroupes.add(e);
			}
			
			//puis on met les tous groupes crees dans le groupe actuel
			//en gardant le rank actuel
			double currentRank = this.rank;
			it = subGroups.values().iterator();
			while(it.hasNext()) {
				g = it.next();
				addItem(g, wheel);
			}
			this.rank = currentRank;
			
			//on vire tous les elements du noeud actuel, car ils viennent d'etre regroupes
			it = elementsRegroupes.iterator();
			while(it.hasNext()) {
				e = it.next();
				removeItem(e, 0, null);
			}
		}
	}

	void removeGroupBy(String groupBy, int levelToReach, Wheel wheel) {
		if(levelToReach > 0) {
			//tant que l'on est pas a la profondeur voulue
			//on degroupera a tous les fils de profondeur - 1
			Iterator<Item> it = subItems.values().iterator();
			while(it.hasNext()) {
				(it.next()).removeGroupBy(groupBy, levelToReach - 1, wheel);
			}
		} else {
			//on est a la profondeur voulue, on degroupe les elements
			
			LinkedList<Item> groupsDegroupes = new LinkedList<Item>();
			
			Iterator<Item> it = subItems.values().iterator();
			while(it.hasNext()) {
				//techniquement, les items enfants a degrouper sont
				//des groups contenant des elements
				//on les repertories tous dans la liste
				groupsDegroupes.add(it.next());
			}
			
			//pour tous les groups repertories,
			//on descend tous les enfants d'un niveau
			//en gardant le rank actuel
			double currentRank = this.rank;
			Item g, e;
			it = groupsDegroupes.iterator();
			Iterator<Item> itSubItems;
			while(it.hasNext()) {
				g = it.next();
				//on descend tous les enfants d'un niveau (ce niveau)
				itSubItems = g.getChilds().iterator();
				while(itSubItems.hasNext()) {
					e = itSubItems.next();
					this.addItem(e, wheel);
				}
				
				//puis on detruit le groupe
				this.removeItem(g, 0, null);
			}
			this.rank = currentRank;
		}
	}

	public double paint(Graphics2D gr, double cumuledRankGroup) {
		double cumuledRankItem = 0;
		Iterator<Item> it = subItemsPos.iterator();
		Item i;
		int nbItem = 0;
		float cumuledColor = 0;
		while(it.hasNext()) {
			i = it.next();
			cumuledRankItem = i.paint(gr, cumuledRankItem);
			
			nbItem++;
			cumuledColor += i.colorVal;
		}
		
		colorVal = cumuledColor / nbItem;
		cumuledRankGroup = super.paint(gr, cumuledRankGroup);
		
		return cumuledRankGroup;
	}
	
	//on synchronise pour eviter les erreur d'acces avec les threads
	public synchronized void paintRoot(Graphics2D gr) {
		double cumuledRank = 0;
		Iterator<Item> it = subItemsPos.iterator();
		while(it.hasNext()) {
			cumuledRank = (it.next()).paint(gr, cumuledRank);
		}
	}

	public double checkCollide(int radiusMouse, int angleMouse, double cumuledRankGroup) {
		cumuledRankGroup = super.checkCollide(radiusMouse, angleMouse, cumuledRankGroup);
		
		double cumuledRankItem = 0;
		Iterator<Item> it = subItemsPos.iterator();
		while(it.hasNext()) {
			cumuledRankItem = (it.next()).checkCollide(radiusMouse, angleMouse, cumuledRankItem);
		}
		this.rankMouseParent = cumuledRankItem;
		
		return cumuledRankGroup;
	}
	
	public void checkCollideRoot(int radiusMouse, int angleMouse) {
		double cumuledRank = 0;
		Iterator<Item> it = subItemsPos.iterator();
		while(it.hasNext()) {
			cumuledRank = (it.next()).checkCollide(radiusMouse, angleMouse, cumuledRank);
		}
		this.rankMouseParent = cumuledRank;
	}

	public void mouseClicked(int radiusMouse, int angleMouse) {
		super.mouseClicked(radiusMouse, angleMouse);
		Iterator<Item> it = subItemsPos.iterator();
		while(it.hasNext()) {
			(it.next()).mouseClicked(radiusMouse, angleMouse);
		}
	}
	
	public void mouseClickedRoot(int radiusMouse, int angleMouse) {
		Iterator<Item> it = subItemsPos.iterator();
		while(it.hasNext()) {
			(it.next()).mouseClicked(radiusMouse, angleMouse);
		}
	}
}
