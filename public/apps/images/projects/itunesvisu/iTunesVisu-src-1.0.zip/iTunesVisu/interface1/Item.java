package interface1;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.Shape;
import java.awt.font.FontRenderContext;
import java.awt.font.GlyphVector;
import java.awt.geom.AffineTransform;
import java.awt.geom.Arc2D;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Point2D;
import java.util.Collection;

abstract public class Item{
	String nom; //nom de l'element
	double rank; //classement de l'element
	int level; //profondeur dans l'arbre
	Group parent; //parent de l'item, null si c'est la racine
	float colorVal; //couleur de l'item (entre 0 et 1)
	
	//variables relatifs aux graphismes
	int radiusMin, radiusMax;
	int angleLeft, angleRight;
	double rankMouse, rankMouseParent;
	int radiusMouse;
	Ellipse2D circle;
	Arc2D arc;
	int colorMin = 127;
	int colorMax = 255;
	int colorCreate;
	
	boolean isCollide;
	
	Item(String nom) {
		this.radiusMin = 50;
		this.radiusMax = 100;
		this.angleLeft = 0;
		this.angleRight = 360;
		this.isCollide = false;
		this.colorVal = 1;
		
		this.nom = nom;
		this.rank = 0;
		this.level = 0;
		this.parent = null;
		circle = new Ellipse2D.Float(0,0,radiusMin * 2,radiusMin * 2);
		arc = new Arc2D.Float(0, 0,
				  radiusMax * 2, radiusMax * 2,
				  angleLeft, angleRight - angleLeft, Arc2D.PIE);
	}
	
	public void displayConsole() {
		for(int i=0; i<level; i++)
		{
			System.out.print("  ");
		}
		System.out.println(nom+" | "+rank);
	}
	
	public String getNom(){
		return nom;
	}

	abstract Collection<Item> getChilds();
	abstract String getGroupBy(String groupBy);
	abstract public double addItem(Item i, Wheel wheel);
	abstract void removeItem(Item i, double removeRank, Wheel wheel);
	abstract void addGroupBy(String groupBy, int levelToReach, Wheel wheel);
	abstract void removeGroupBy(String groupBy, int levelToReach, Wheel wheel);
	
	public double paint(Graphics2D gr, double cumuledRank) {
		int centerX = Wheel.centerX;
		int centerY = Wheel.centerY;
		radiusMax = Wheel.radiusMax;
		
		//on change les parametres avant de dessiner
		//parent != null, car on ne dessine pas l'item root
		
		//on change les rayons
		radiusMax -= Wheel.CD_HoleSize;
		
		radiusMin = (int)(radiusMax * (this.level - 1) * 1.0 / (Wheel.currentLevel + 1));
		radiusMax = (int)(radiusMax *  this.level      * 1.0 / (Wheel.currentLevel + 1));
		
		radiusMin += Wheel.CD_HoleSize;
		radiusMax += Wheel.CD_HoleSize;
		
		double addedRank;
		double rankParent;
		if(radiusMouse > radiusMin && radiusMouse < Wheel.radiusMax)
		{
			addedRank = rankMouse;
			rankParent = parent.rankMouseParent;
		} else {
			addedRank = rank;
			rankParent = parent.rank;
		}
		//on change les angles
		angleLeft   = parent.angleLeft;
		angleLeft  += (parent.angleRight - parent.angleLeft) *  cumuledRank              / rankParent;

		angleRight  = parent.angleLeft;
		angleRight += (parent.angleRight - parent.angleLeft) * (cumuledRank + addedRank) / rankParent;
		
		//on dessine l'eventail
		double sinVal, cosVal;
		
		//on rempli l'eventail grace a une technique de clippage
		Color oldColor = gr.getColor();
		if(isCollide) {
			gr.setColor(new Color(colorMin, colorMin, colorMax));
		} else {
			colorCreate = (int) ((0.5 - Math.abs(0.5 - colorVal)) * (colorMax - colorMin));
			colorCreate += colorMin;
			
			if(colorVal > 0.5)
			{
				gr.setColor(new Color(colorCreate, colorMax, colorMin));
			} else {
				gr.setColor(new Color(colorMax, colorCreate, colorMin));
			}
		}
		
		//on affiche rapidement ou pas les eventails
		//selon le mode d'affichage
		if(Wheel.isFastDisplay && angleRight - angleLeft > 1 ||
		  !Wheel.isFastDisplay ||
		   isCollide)
		{
			circle.setFrame(centerX - radiusMin,
					centerY - radiusMin,
					radiusMin * 2,
					radiusMin * 2);
			Area area1 = new Area(circle);
			arc.setArc(centerX - radiusMax, centerY - radiusMax,
					   radiusMax * 2, radiusMax * 2,
					   angleLeft, angleRight - angleLeft, Arc2D.PIE);
		    Area area2 = new Area(arc); 
		    area2.subtract(area1);
		    gr.fill(area2);
		    
		    gr.setColor(Color.BLACK);
		}
		
        //on dessine les contours de l'eventail
		/*gr.drawArc(centerX - radiusMin, centerY - radiusMin,
				   radiusMin * 2, radiusMin * 2,
				   angleLeft, angleRight - angleLeft);
		gr.drawArc(centerX - radiusMax, centerY - radiusMax,
				   radiusMax * 2, radiusMax * 2,
				   angleLeft, angleRight - angleLeft);*/
		cosVal =  AngleCalculation.getCosVal(angleLeft);
		sinVal = -AngleCalculation.getSinVal(angleLeft);
		gr.drawLine((int)(centerX + cosVal * radiusMin),
				    (int)(centerY + sinVal * radiusMin),
				    (int)(centerX + cosVal * radiusMax),
				    (int)(centerY + sinVal * radiusMax));
		cosVal =  AngleCalculation.getCosVal(angleRight);
		sinVal = -AngleCalculation.getSinVal(angleRight);
		gr.drawLine((int)(centerX + cosVal * radiusMin),
				    (int)(centerY + sinVal * radiusMin),
				    (int)(centerX + cosVal * radiusMax),
				    (int)(centerY + sinVal * radiusMax));
		
		gr.setColor(oldColor);
		
		/*cosVal =  AngleCalculation.getCosVal((angleRight + angleLeft) / 2);
		sinVal = -AngleCalculation.getSinVal((angleRight + angleLeft) / 2);
		
		gr.drawString(Double.toString((int)(rank * 10) * 1.0/10),
				      (int)(centerX + cosVal * (radiusMax + radiusMin) / 2),
				      (int)(centerY + sinVal * (radiusMax + radiusMin) / 2));*/
		/*gr.drawString(nom.substring(4),
					 (int)(centerX + cosVal * (radiusMax + radiusMin) / 2),
			         (int)(centerY + sinVal * (radiusMax + radiusMin) / 2));*/
		
		//on affiche le texte si l'eventail a au moins 15 degres d'ouverture
		if(angleRight - angleLeft > 15)
		{
			String s = nom.substring(4);
		    Font font = new Font("Helvetica", Font.BOLD, 12);
		    FontRenderContext frc = gr.getFontRenderContext();
	
		    GlyphVector gv = font.createGlyphVector(frc, s);
		    
		    double angleGlyph;
		    double angleLeftGlyph, angleRightGlyph;
		    double rotationGlyph;
		    int length = gv.getNumGlyphs();
		    double alpha;
		    double theta;
		    AffineTransform at;
		    Shape glyph, transformedGlyph;
		    
		    //permet d'afficher le texte de gauche a droite
		    //si celuis ci est a plus ou moins de 180 degres
		    if((angleRight + angleLeft) / 2 < 180) {
		    	angleLeftGlyph = angleLeft;
		    	angleRightGlyph = angleRight;
		    	rotationGlyph = -90;
		    } else {
		    	angleLeftGlyph = angleRight;
		    	angleRightGlyph = angleLeft;
		    	rotationGlyph = +90;
		    }
		    
		    //on affiche chacune des lettres a la bonne position et rotation
		    for (int i = 0; i < length; i++) {
				Point2D p = gv.getGlyphPosition(i);
				alpha = (double)(i + 0.5) / length;
				//la localisation de la lettre est interpolee par rapport
				//a sa position dans le mot et les angles gauches et droits
				angleGlyph = angleLeftGlyph * alpha + angleRightGlyph * (1 - alpha);
				cosVal =  AngleCalculation.getCosVal(angleGlyph);
				sinVal = -AngleCalculation.getSinVal(angleGlyph);
				at = AffineTransform.getTranslateInstance(
						centerX + cosVal * (radiusMax + radiusMin) / 2,
						centerY + sinVal * (radiusMax + radiusMin) / 2);
				theta = (angleGlyph + rotationGlyph) * AngleCalculation.DEG_TO_RAD;
				at.rotate(-theta);
				glyph = gv.getGlyphOutline(i, (float)(-p.getX()), (float)(-p.getY()));
				transformedGlyph = at.createTransformedShape(glyph);
				gr.fill(transformedGlyph);
			}
		}
		
		return cumuledRank + addedRank;
	}
	
	public double checkCollide(int radiusMouse, int angleMouse, double cumuledRank) {
		isCollide = radiusMouse > radiusMin && radiusMouse < radiusMax &&
					angleRight > angleMouse && angleLeft < angleMouse;
		
		double ecart = angleMouse - (angleLeft + angleRight) * 0.5;
		if(ecart > 180) ecart -= 360;
		else if(ecart < -180) ecart += 360;
		
		//on interpole le rankmouse
		double newRankMouse = rankMouse * 0.75 + rank * Math.exp(-ecart * ecart / 10000) * 0.25;
		if(Math.abs(newRankMouse - rankMouse) > 0.1)
		{
			//on modifie le rankMouse que si l'ecart est important
			//afin d'eviter une animation continue genante a l'oeil
			rankMouse = newRankMouse;
		}
		
		this.radiusMouse = radiusMouse;
		
		return cumuledRank + rankMouse;
	}
	
	public void mouseClicked(int radiusMouse, int angleMouse) {
		boolean isCollideCliked = radiusMouse > radiusMin && radiusMouse < radiusMax &&
								  angleRight > angleMouse && angleLeft < angleMouse;
		
		if(isCollideCliked) {
			Outils.setInfos(nom.substring(4), level);
		}
	}
}
