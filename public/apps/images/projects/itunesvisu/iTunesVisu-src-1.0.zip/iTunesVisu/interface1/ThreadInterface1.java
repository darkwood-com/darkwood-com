package interface1;

public class ThreadInterface1 extends Thread{
	Interface1 i1;
	public ThreadInterface1(Interface1 i1) {
		this.i1 = i1;
	}
	
	public void run() {
		while(true) {
			if(i1.currMouse != null) {
				i1.mouseMoved(i1.currMouse);
				
				/*int mX = (int) i1.currMouse.getPoint().getX();
			    int mY = (int) i1.currMouse.getPoint().getY();
				
			    System.out.println(mX+" et "+mY);*/
			}
			
			
		    
			i1.repaint();
			
			try {
				this.sleep((long) (1000.0/24));
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
    }
}
