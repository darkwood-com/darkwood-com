/**
 * 
 */
package interface2;

import java.awt.Color;
import java.awt.Dimension;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

import filtres.FiltresEvent;

import visu.Genre;
import visu.User;
import visu.UserTrack;

/**
 * @author rdurand
 *
 */
public class CouronneBuilderGenre extends CouronneBuilder {

	//decalages a l'interieur des franges
	public static final int nbDecalage=10;
	
	@Override
	public void createCouronne(FiltresEvent f, 
			LinkedList<Etiquette> mesEtiquettes, 
			LinkedList<Segment> mesSegments, 
			LinkedList<Legende> mesLegendes) {

		//il y a nbFrange cat�gories
		int nbFranges= Genre.GENRES.size();
		
		//chaque frange a un angle a sa disposition de angleFrange
		double angleFrange=(Math.PI*2)/nbFranges;
		
		Random rand=new Random();
		UserTrack temp;
		Iterator<UserTrack> it = f.listeUT.iterator();
		double totalTimeMax=0;
		double min;
		double max;
		double totalTimeMin=Double.MAX_VALUE;
		double tempAngle;
		int tempDistance;
		
		
		it = f.listeUT.iterator();
		while(it.hasNext()){
			temp=it.next();
			if(temp.getTotalTime()>=f.minTotalTime && temp.getTotalTime()<=f.maxTotalTime &&
					temp.getRating(f.u) >= f.minRating && temp.getRating(f.u) <= f.maxRating &&
					temp.getSize() >= f.minSize && temp.getSize() <= f.maxSize &&
					temp.getBitRate() >= f.minBitRate && temp.getBitRate() <= f.maxBitRate &&
					temp.getSampleRate() >= f.minSampleRate && temp.getSampleRate() <= f.maxSampleRate &&
					temp.getPlayCount(f.u) >= f.minPlayCount && temp.getPlayCount(f.u) <= f.maxPlayCount
				){
				if(!temp.getName().equals("aucun")){
					int aleat=rand.nextInt();
					//System.err.println(nbDecalage+": "+a+", "+((float)(a%nbDecalage)));
					tempAngle=Genre.GENRES.indexOf(temp.getGenre());
					tempAngle=angleFrange*(tempAngle+((float)Math.abs(aleat%nbDecalage))/(nbDecalage+2));
					mesEtiquettes.add(new Etiquette(temp.getRating(f.u),tempAngle,  temp));
				}
			}
		}

		//on ajoute les "ronds"
		drawRond(mesSegments, nbFranges, Color.BLACK, 0, 20);
		drawRond(mesSegments, nbFranges, Color.RED, 20, 40);
		drawRond(mesSegments, nbFranges, Color.YELLOW, 40, 60);
		drawRond(mesSegments, nbFranges, Color.ORANGE, 60, 80);
		drawRond(mesSegments, nbFranges, Color.GREEN, 80, 100);
		drawRond(mesSegments, nbFranges, Color.LIGHT_GRAY, 100, 100);

		double segSize=2*Math.PI/nbFranges;
		int numero=0;
		Genre tempGenre;
		Iterator<Genre> itGenre = Genre.GENRES.iterator();
		while(itGenre.hasNext()){
			String toDraw=itGenre.next().getName();
			mesLegendes.add(new Legende(segSize*numero+segSize/2,toDraw));
			numero++;
		}
		
	}
	
	private void drawRond(LinkedList<Segment> segments, int nbFranges, Color couleur, float rating, float ratingVertical){
		Segment tempEti;
		double segsize=360/(double)nbFranges;
		for(double i=0;i<360;i+=segsize){
			/*tempEti=new Segment(
					(float) (Math.cos(i*Math.PI/180)*(100-rating)),
					(float) (Math.sin(i*Math.PI/180)*(100-rating)),
					(float) (Math.cos((i+30)*Math.PI/180)*(100-rating)),
					(float) (Math.sin((i+30)*Math.PI/180)*(100-rating)),
					couleur
					);*/
			tempEti=new Segment(rating, i*Math.PI/180, (i+segsize)*Math.PI/180, couleur);
			segments.add(tempEti);
			if(rating!=ratingVertical){
				tempEti=new Segment(rating, ratingVertical , i*Math.PI/180, Color.GRAY);
				segments.add(tempEti);
			}
		}
	}

	@Override
	public void changeCouronne(FiltresEvent f, 
			LinkedList<Etiquette> lesEtiquettes, 
			LinkedList<Segment> mesSegments, 
			LinkedList<Legende> mesLegendes) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	
}
