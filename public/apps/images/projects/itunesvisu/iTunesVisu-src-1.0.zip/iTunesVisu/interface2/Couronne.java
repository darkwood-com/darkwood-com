/**
 * 
 */
package interface2;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;

import filtres.FiltresEvent;
import filtres.FiltresListener;

import visu.DateVizu;
import visu.Genre;
import visu.Kind;
import visu.Track;
import visu.TrackNumber;
import visu.User;
import visu.UserTrack;
import visu.Visu;

/**
 * @author rdurand
 *
 */
public class Couronne extends JComponent implements MouseListener, MouseMotionListener, MouseWheelListener, FiltresListener {
	final static int LARGEUR_ANNEAU=50;
	final static public int TROU_MILIEU=5;
	
	private LinkedList<Etiquette> mesEtiquettes;
	private LinkedList<Segment> mesSegments;
	private LinkedList<Legende> mesLegendes;

	private float minRating=0, maxRating=100;
	private float minTotalTime=0, maxTotalTime=999999999;
	private float minSize=0, maxSize=999999999;
	private float minBitRate=0, maxBitRate=999999999;
	private float minSampleRate=0, maxSampleRate=999999999;
	private float minPlayCount=0, maxPlayCount=999999999;
	
	private CouronneBuilder monFabricant;
	private ArrayList<UserTrack> affiche;
	private User currentUser;
	
	/*double min;
	double max;*/
	
	private int prevMousePosX=0, prevMousePosY=0;
	private double zoom;
	private double posx,posy;
	
	public Couronne(ArrayList<UserTrack> aAfficher, User utilisateur){
		affiche=aAfficher;
		currentUser=utilisateur;
		mesEtiquettes=new LinkedList<Etiquette>();
		mesSegments=new LinkedList<Segment>();
		mesLegendes=new LinkedList<Legende>();
		posx=0;
		posy=0;
		zoom=1;
		
		monFabricant=new CouronneBuilderGenre();
		monFabricant.createCouronne(new FiltresEvent(minRating, maxRating,
				minTotalTime, maxTotalTime,
				minSize, maxSize,
				minBitRate, maxBitRate,
				minSampleRate, maxSampleRate,
				minPlayCount, maxPlayCount,
				affiche, currentUser)
			, mesEtiquettes, mesSegments, mesLegendes);

		this.setSize(500,500);
		this.setPreferredSize(new Dimension(500,500));
	}
	
	public int getPos(){
		return 4+LARGEUR_ANNEAU+(this.getWidth()-10)/2;
	}
	
	public void paintComponent(Graphics g){
		Graphics2D gra=(Graphics2D) g;
		
		/*int posx=this.getX()+5;
		int posy=this.getY()+5;*/
		//System.err.println("x="+this.posx+", y="+this.posy);
		int largeur=this.getWidth()-10;
		int hauteur=this.getHeight()-10;
		int demiLargeur;
		int demiHauteur;
		//on se deplace un peu sur le cot� pour les bordures
		AffineTransform init=gra.getTransform();
		AffineTransform trsfBordure= gra.getTransform();
		AffineTransform trsf;
		gra.setColor(Color.BLACK);
		gra.drawLine(4, 4, -5+this.getWidth(), 4);
		gra.drawLine(4, 4, 4, -5+this.getHeight());
		trsfBordure.translate(5,5);
		gra.setTransform(trsfBordure);
		
		gra.setColor(Color.WHITE);
		gra.fillRect(0, 0, largeur, hauteur);
		
		//on dessine le premier anneau
		gra.setColor(Color.BLACK);
		gra.drawOval(0, 0, largeur, hauteur);
		
		//ainsi que la legende
		trsf=gra.getTransform();
		trsfBordure=gra.getTransform();
		trsfBordure.translate( (largeur/2) , (hauteur/2) );
		gra.setTransform(trsfBordure);
		/*for(int angle=0;angle<340;angle+=10){
			String toDraw=Integer.toString((int) ((min+angle*(max-min)/360)/1000));
			/*gra.drawString(toDraw, 
							(int) ( Math.cos(angle*Math.PI/180) * (largeur/2 - 20)-10 ),
							(int) ( Math.sin(angle*Math.PI/180) * (hauteur/2 - 20)+10 ) );
			// gra.drawString(Integer.toString(angle), (int) ((Math.cos(angle*Math.PI/180)*100)*largeur/100), (int) ((Math.sin(angle*Math.PI/180)*120)*largeur/100));
		}*/
		gra.setTransform(trsf);
		
		//on ajoute la bordure de la couronne
		trsfBordure= gra.getTransform();
		trsfBordure.translate(LARGEUR_ANNEAU,LARGEUR_ANNEAU);
		gra.setTransform(trsfBordure);
		largeur=this.getWidth()-10 -LARGEUR_ANNEAU*2;
		hauteur=this.getHeight()-10 -LARGEUR_ANNEAU*2;
		demiLargeur=(largeur/2) ;
		demiHauteur=(hauteur/2) ;

		//deuxieme anneau
		gra.drawOval(0, 0, largeur, hauteur);
		
		//puis ceux de niveaux
		/*gra.setColor(Color.RED);
		gra.drawOval(((80)*demiLargeur/100), ((80)*demiHauteur/100), largeur-((80)*demiLargeur/50), hauteur-((80)*demiHauteur/50));
		gra.setColor(Color.ORANGE);
		gra.drawOval(((40)*demiLargeur/100), ((40)*demiHauteur/100), largeur-((40)*demiLargeur/50), hauteur-((40)*demiHauteur/50));
		gra.setColor(Color.YELLOW);
		gra.drawOval(((60)*demiLargeur/100), ((60)*demiHauteur/100), largeur-((60)*demiLargeur/50), hauteur-((60)*demiHauteur/50));
		gra.setColor(Color.GREEN);
		gra.drawOval(((80)*demiLargeur/100), ((80)*demiHauteur/100), largeur-((80)*demiLargeur/50), hauteur-((80)*demiHauteur/50));
		/* */
		/*gra.setColor(Color.RED);
		double tempval=toHyperbolic(20f/100);
		gra.drawOval((int) ((tempval*demiLargeur)), 
				(int) ((tempval*demiHauteur)), 
				(int) (largeur-((tempval*demiLargeur*2))), 
				(int) (hauteur-((tempval*demiHauteur*2))) );
		gra.setColor(Color.ORANGE);
		tempval=toHyperbolic(40f/100);
		gra.drawOval((int) ((tempval*demiLargeur)), 
				(int) ((tempval*demiHauteur)), 
				(int) (largeur-((tempval*demiLargeur*2))), 
				(int) (hauteur-((tempval*demiHauteur*2))) );
		gra.setColor(Color.YELLOW);
		tempval=toHyperbolic(60f/100);
		gra.drawOval((int) ((tempval*demiLargeur)), 
				(int) ((tempval*demiHauteur)), 
				(int) (largeur-((tempval*demiLargeur*2))), 
				(int) (hauteur-((tempval*demiHauteur*2))) );
		gra.setColor(Color.GREEN);
		tempval=toHyperbolic(80f/100);
		gra.drawOval((int) ((tempval*demiLargeur)), 
				(int) ((tempval*demiHauteur)), 
				(int) (largeur-((tempval*demiLargeur*2))), 
				(int) (hauteur-((tempval*demiHauteur*2))) );
		
		/*gra.setColor(Color.ORANGE);
		gra.drawOval(((40)*demiLargeur/100), ((40)*demiHauteur/100), largeur-((40)*demiLargeur/50), hauteur-((40)*demiHauteur/50));
		gra.setColor(Color.YELLOW);
		gra.drawOval(((60)*demiLargeur/100), ((60)*demiHauteur/100), largeur-((60)*demiLargeur/50), hauteur-((60)*demiHauteur/50));
		gra.setColor(Color.GREEN);
		gra.drawOval(((80)*demiLargeur/100), ((80)*demiHauteur/100), largeur-((80)*demiLargeur/50), hauteur-((80)*demiHauteur/50));
		*/
		
		//on se met au centre pour les etiquettes
		trsf= gra.getTransform();
		trsf.translate( (largeur/2) , (hauteur/2) );
		gra.setTransform(trsf);
		//on affiche les segments
		Iterator<Segment> its = mesSegments.iterator();
		while(its.hasNext()){
			its.next().paintComponent(gra, new Point2D.Double(posx,posy), (largeur/2), (hauteur/2), zoom );
		}
		//on affiche les etiquettes
		Iterator<Etiquette> ite = mesEtiquettes.iterator();
		while(ite.hasNext()){
			ite.next().paintComponent(gra, new Point2D.Double(posx,posy), (largeur/2), (hauteur/2), zoom );
		}
		
		Iterator<Legende> itl = mesLegendes.iterator();
		while(itl.hasNext()){
			itl.next().paintComponent(gra, new Point2D.Double(posx,posy), (largeur/2), (hauteur/2), zoom );
		}
		//on se remet la ou il faut
		gra.setTransform(init);
	}
	
	public void setCouronneBuilder(CouronneBuilder build){
		monFabricant=build;
		mesEtiquettes=new LinkedList<Etiquette>();
		mesSegments=new LinkedList<Segment>();
		mesLegendes=new LinkedList<Legende>();
		posx=0;
		posy=0;
		zoom=1;
		monFabricant.createCouronne(new FiltresEvent(minRating, maxRating,
				minTotalTime, maxTotalTime,
				minSize, maxSize,
				minBitRate, maxBitRate,
				minSampleRate, maxSampleRate,
				minPlayCount, maxPlayCount,
				affiche, currentUser)
			, mesEtiquettes, mesSegments, mesLegendes);
		this.repaint();
	}
	

	private void setDAtaAffiche(ArrayList<UserTrack> aAfficher, User utilisateur){
		affiche=aAfficher;
		currentUser=utilisateur;
		mesEtiquettes=new LinkedList<Etiquette>();
		mesSegments=new LinkedList<Segment>();
		mesLegendes=new LinkedList<Legende>();
		posx=0;
		posy=0;
		zoom=1;
		monFabricant.createCouronne(new FiltresEvent(minRating, maxRating,
				minTotalTime, maxTotalTime,
				minSize, maxSize,
				minBitRate, maxBitRate,
				minSampleRate, maxSampleRate,
				minPlayCount, maxPlayCount,
				affiche, currentUser)
			, mesEtiquettes, mesSegments, mesLegendes);
		this.repaint();
	}
	
	static public double toHyperbolic(double val){
		//return Math.pow(Math.tanh(val),4);
		return Math.pow(val,10);
	}
	
	static public LinkedList<UserTrack> enplus;
	
	static public void  main(String[] args){
		User data = Visu.getInstance().getUser1();
		
		JFrame j=new JFrame("interface2");
		Couronne cou=new Couronne(data.getPossede(), data);
		j.add(cou);
		j.addMouseListener(cou);
		j.addMouseMotionListener(cou);
		cou.addMouseListener(cou);
		cou.addMouseMotionListener(cou);
		cou.addMouseWheelListener(cou);
		j.setSize(500,500);
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		j.setVisible(true);
		
	}
	/*static public void  main(String[] args){
		ArrayList<UserTrack> tab= new ArrayList<UserTrack>();
		
		Random r=new Random();
		
		User u=new User(1);
		
		Track t1=new Track("chanson 1");
		Track t2=new Track("chanson 2");
		Track t3=new Track("chanson 3");
		Track t4=new Track("chanson 4");
		
		Genre g=new Genre("genre");
		Kind k=new Kind("kind");
		TrackNumber tn=new TrackNumber(0);
		
		tab.add(new UserTrack(t1,g,k, 0,1000*(60+Math.abs(r.nextInt()%120)),tn,0,0));
		tab.add(new UserTrack(t1,g,k, 0,1000*(60+Math.abs(r.nextInt()%120)),tn,0,0));
		tab.add(new UserTrack(t2,g,k, 0,1000*(60+Math.abs(r.nextInt()%120)),tn,0,0));
		tab.add(new UserTrack(t3,g,k, 0,1000*(60+Math.abs(r.nextInt()%120)),tn,0,0));
		tab.add(new UserTrack(t4,g,k, 0,1000*(60+Math.abs(r.nextInt()%120)),tn,0,0));
		tab.add(new UserTrack(t4,g,k, 0,1000*(60+Math.abs(r.nextInt()%120)),tn,0,0));
		
		for(int i=0;i<1000;i++){
			tab.add(new UserTrack(t4,g,k, 0,(60+Math.abs(r.nextInt()%160000)),tn,0,0));
		}
		
		
		
		DateVizu d=new DateVizu(0);
		Iterator<UserTrack> it = tab.iterator();
		while(it.hasNext()){
			it.next().setUserInfos(d, d, 0, d, "qql part", u);
		}

		it = tab.iterator();
		it.next().setRating(u, 100f);
		while(it.hasNext()){
			it.next().setRating(u, r.nextFloat()*100);
			//it.next().setRating(u, 0);
		}
		
		
		
		JFrame j=new JFrame("test");
		
		Couronne cou=new Couronne(tab, u);
		j.add(cou);
		j.addMouseListener(cou);
		j.addMouseMotionListener(cou);
		cou.addMouseListener(cou);
		cou.addMouseMotionListener(cou);
		cou.addMouseWheelListener(cou);
		j.setSize(500,500);
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		j.setVisible(true);
		
		
	}*/
	
	

	public void mouseDragged(MouseEvent e) {
		this.posx=this.posx-(e.getX()-prevMousePosX)/10f;
		this.posy=this.posy-(e.getY()-prevMousePosY)/10f;
		if(Math.sqrt(posx*posx+posy*posy)>100){
			this.posx=this.posx+(e.getX()-prevMousePosX)/10f;
			this.posy=this.posy+(e.getY()-prevMousePosY)/10f;
		}
		prevMousePosX=e.getX();
		prevMousePosY=e.getY();
		//System.err.println(prevMousePosX+", "+prevMousePosY);
		this.repaint();
	}

	public void mouseMoved(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void mouseClicked(MouseEvent e) {
		
		
	}

	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void mousePressed(MouseEvent e) {
		prevMousePosX=e.getX();
		prevMousePosY=e.getY();
	}

	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	public void mouseWheelMoved(MouseWheelEvent e) {
		zoom=(zoom*(1+e.getUnitsToScroll()/50.0f));
		this.repaint();
	}
	
	
	public void filtresChanged(FiltresEvent e) {
		minRating=e.minRating; maxRating=e.maxRating;
		minTotalTime=e.minTotalTime; maxTotalTime=e.maxTotalTime;
		minSize=e.minSize; maxSize=e.maxSize;
		minBitRate=e.minBitRate; maxBitRate=e.maxBitRate;
		minSampleRate=e.minSampleRate; maxSampleRate=e.maxSampleRate;
		affiche=e.listeUT;
		currentUser=e.u;
		
		mesEtiquettes=new LinkedList<Etiquette>();
		mesSegments=new LinkedList<Segment>();
		mesLegendes=new LinkedList<Legende>();
		posx=0;
		posy=0;
		zoom=1;
		monFabricant.createCouronne(e, mesEtiquettes, mesSegments, mesLegendes);
		this.repaint();
	}

	public Collection<Etiquette> getMesEtiquettes() {
		return mesEtiquettes;
	}
	
	
}
