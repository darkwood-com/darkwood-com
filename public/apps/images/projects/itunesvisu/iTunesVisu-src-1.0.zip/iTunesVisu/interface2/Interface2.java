/**
 * 
 */
package interface2;

import interface1.Interface1;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Iterator;

import javax.swing.DefaultListModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import filtres.FiltresEvent;
import filtres.FiltresListener;
import filtres.InterfaceFiltres;

import visu.User;
import visu.UserTrack;
import visu.Visu;

/**
 * @author rdurand
 *
 */
public class Interface2 extends JPanel implements MouseListener, FiltresListener{

	JList listeMusiques;
	JList listeTris;
	JLabel informationsMusique;
	Couronne cou;
	Visu donnees;
	InterfaceFiltres filtres;
	User uCourrant;
	
	public Interface2(Visu data, InterfaceFiltres intf){
		
		donnees=data;
		filtres=intf;
		uCourrant=data.getUser1();
		
		cou=new Couronne(data.getUser1().getPossede(), data.getUser1());
		intf.addFiltresListener(cou);
		intf.addFiltresListener(this);
		/*this.addMouseListener(cou);
		this.addMouseListener(this);
		this.addMouseMotionListener(cou);
		this.addMouseWheelListener(cou);*/
		cou.addMouseListener(cou);
		cou.addMouseListener(this);
		cou.addMouseMotionListener(cou);
		cou.addMouseWheelListener(cou);
		createComponents(data);
		
		
		
	}
	
	private void createComponents(Visu data){
		//JPanel jpScPanel=new JPanel();
		JPanel jpDroit=new JPanel();
		listeMusiques=new JList(new DefaultListModel());
		listeMusiques.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		listeMusiques.setLayoutOrientation(JList.VERTICAL);
		listeMusiques.addListSelectionListener(new ListSelectionListener(){
			public void valueChanged(ListSelectionEvent e) {
				JList list=(JList) e.getSource();
				if (e.getValueIsAdjusting() == false) {

			        if (list.getSelectedIndex() == -1) {
			        //No selection

			        } else {
			        //Selection
			        	ListModel model=list.getModel();
			        	UserTrack ut=(UserTrack) model.getElementAt(list.getSelectedIndex());
			        	String st;
			        	st="<html>Nom : "+ut.getName();
			        	st=st+"<br>Genre : "+ut.getGenre().getName();
						st=st+"<br>Artist : "+ut.getArtiste().getName();
						st=st+"<br>Type : "+ut.getKind().getName();
						st=st+"<br>Taille : "+ut.getSize() /(1000000)+" Mo";
						st=st+"<br>Duree : "+(ut.getTotalTime() / (60 * 1000))+" min";
						st=st+"<br>Bitrate : "+ut.getBitRate()+" kBits";
						st=st+"<br>PlayCount : "+ut.getPlayCount(uCourrant);
						st=st+"<br>Rating : "+new Float((ut.getRating(uCourrant))).intValue()+"/100";
						st=st+"</html>";
			        	informationsMusique.setText(st);
			        }
			    }
			}
		});
		((DefaultListModel)listeMusiques.getModel()).addElement(new String("pas de selection"));
		listeMusiques.setEnabled(false);
		informationsMusique=new JLabel("- aucune selection -");
		jpDroit.setLayout(new BorderLayout());
		jpDroit.add(new JLabel("Musiques selection�es:"), BorderLayout.NORTH);
		//jpScPanel.setLayout(new BorderLayout());
		//jpScPanel.add(listeMusiques);
		//jpScroll.add(jpScPanel);
		JScrollPane jpScroll=new JScrollPane(listeMusiques);
		jpDroit.add(jpScroll);
		//jpDroit.add(informationsMusique);
		
		JPanel jpGauche=new JPanel();
		jpGauche.setLayout(new BorderLayout());
		jpGauche.add(new JLabel("choisissez le tri:"), BorderLayout.NORTH);
		createListeTris();
		jpGauche.add(listeTris);

		JPanel jpTTGauche=new JPanel();
		jpTTGauche.setLayout(new GridLayout(3,1));
		jpTTGauche.add(jpGauche);
		jpTTGauche.add(jpDroit);
		jpTTGauche.add(informationsMusique);
		
		
		this.setLayout(new BorderLayout());
		//this.add(jpDroit, BorderLayout.EAST);
		this.add(jpTTGauche, BorderLayout.WEST);
		this.add(cou,BorderLayout.CENTER);
		this.setVisible(true);
	}

	private void createListeTris() {
		DefaultListModel listModel = new DefaultListModel();
		listModel.addElement("genres");
		listModel.addElement("duree");
		
		listeTris=new JList(listModel);
		listeTris.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
		listeTris.setLayoutOrientation(JList.VERTICAL);
		listeTris.setSelectedIndex(0);
		
		final Interface2 me=this;
		listeTris.addListSelectionListener(new ListSelectionListener(){
			public void valueChanged(ListSelectionEvent e) {
	        	JList list=(JList) e.getSource();
				if (e.getValueIsAdjusting() == false) {

			        if (list.getSelectedIndex() == -1) {
			        //No selection

			        } else {
			        //Selection
						if(list.getSelectedIndex()==0){
							cou.setCouronneBuilder(new CouronneBuilderGenre());
							me.repaint();
						}else if(list.getSelectedIndex()==1){
							cou.setCouronneBuilder(new CouronneBuilderTotalTime());
							me.repaint();
						}
			        }
			    }
			}
		});
		
	}
	
	
	
	static public void  main(String[] args){
		InterfaceFiltres intf=new InterfaceFiltres();
		Interface2 i=new Interface2(Visu.getInstance(), intf);
		JFrame j=new JFrame("interface2");
		//Couronne cou=new Couronne(data.getPossede(), data);
		j.add(i);
		//j.addMouseListener(cou);
		//j.addMouseMotionListener(cou);
		//cou.addMouseListener(cou);
		//cou.addMouseMotionListener(cou);
		//cou.addMouseWheelListener(cou);
		j.setSize(700,500);
		j.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		j.setVisible(true);
	}

	public void mouseClicked(MouseEvent e) {
		DefaultListModel listModel = (DefaultListModel) listeMusiques.getModel();//new DefaultListModel();
		this.informationsMusique.setText("- aucune selection -");
		listModel.removeAllElements();
		int x=e.getX()-cou.getWidth()/2;
		int y=e.getY()-cou.getHeight()/2;
		Etiquette et;
		Iterator<Etiquette> it = this.cou.getMesEtiquettes().iterator();
		while(it.hasNext()){
			et=it.next();
			if(et.isDrawing() &&
					x >= et.getAnneauPosx()-30 && 
					y >= et.getAnneauPosy()-6 &&
					x <= et.getAnneauPosx()+30 && 
					y <= et.getAnneauPosy()+6 ){
				
				listModel.addElement(et.getMorceau());
			}
		}
		if(listModel.getSize()==0){
			//informationsMusique.setText("- aucune selection -");
			listModel.addElement(new String("pas de selection"));
			listeMusiques.setEnabled(false);
		}else{
			listeMusiques.setSelectedIndex(0);
			listeMusiques.setEnabled(true);
		}
	}

	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	public void filtresChanged(FiltresEvent e) {
		uCourrant=e.u;
		
	}
}
