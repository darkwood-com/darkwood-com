package interface2;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;
import java.awt.geom.QuadCurve2D;

import visu.UserTrack;

public class Segment {
	
	private float p1x,p1y,p2x,p2y;
	private Color coul;
	
	public Segment(float x1, float y1, float x2, float y2, Color c){
		p1x=x1; p1y=y1;
		p2x=x2; p2y=y2;
		coul=c;
	}

	public Segment(float rating, double angle1, double angle2, Color c) {
		p1x=(float) (Math.cos(angle1)*(100-rating+Couronne.TROU_MILIEU));
		p1y=(float) (Math.sin(angle1)*(100-rating+Couronne.TROU_MILIEU));
		p2x=(float) (Math.cos(angle2)*(100-rating+Couronne.TROU_MILIEU));
		p2y=(float) (Math.sin(angle2)*(100-rating+Couronne.TROU_MILIEU));
		coul=c;
	}

	public Segment(float rating1, float rating2, double angle, Color c) {
		p1x=(float) (Math.cos(angle)*(100-rating1+Couronne.TROU_MILIEU));
		p1y=(float) (Math.sin(angle)*(100-rating1+Couronne.TROU_MILIEU));
		p2x=(float) (Math.cos(angle)*(100-rating2+Couronne.TROU_MILIEU));
		p2y=(float) (Math.sin(angle)*(100-rating2+Couronne.TROU_MILIEU));
		coul=c;
	}
	
	public void paintComponent(Graphics2D g, Point2D pCentre, double largeur, double hauteur, double zoom){
		int tempPosX1,tempPosY1;
		int tempPosX2,tempPosY2;

		// calcul coor1
		double angle1=Segment.calculAngle(new Point2D.Double(p1x,p1y), pCentre);
		double distance1=zoom*Math.sqrt( (p1x-pCentre.getX())*(p1x-pCentre.getX()) 
				+ (p1y-pCentre.getY())*(p1y-pCentre.getY()) );
//		pour rester dans l'espace affichable
		if(distance1>(100+Couronne.TROU_MILIEU)) distance1=(100+Couronne.TROU_MILIEU);
		double tempval=1-Couronne.toHyperbolic(1-distance1/(100+Couronne.TROU_MILIEU));
		tempPosX1=(int) (Math.cos(angle1)*tempval*largeur);
		tempPosY1=(int) (Math.sin(angle1)*tempval*hauteur);

		// calcul coor2
		double angle2=Segment.calculAngle(new Point2D.Double(p2x,p2y), pCentre);
		double distance2=zoom*Math.sqrt( (p2x-pCentre.getX())*(p2x-pCentre.getX()) 
				+ (p2y-pCentre.getY())*(p2y-pCentre.getY()) );
//		pour rester dans l'espace affichable
		if(distance2>(100+Couronne.TROU_MILIEU)) distance2=(100+Couronne.TROU_MILIEU);
		double tempval2=1-Couronne.toHyperbolic(1-distance2/(100+Couronne.TROU_MILIEU));
		tempPosX2=(int) (Math.cos(angle2)*tempval2*largeur);
		tempPosY2=(int) (Math.sin(angle2)*tempval2*hauteur);

		double angle;
		g.setColor(coul);
		//si on est affich� sur une grande distance on cr�e des etapes intermediaires pour un meilleur affichage
		/*int nbSegments=((Math.abs(tempPosX2-tempPosX1)+Math.abs(tempPosY2-tempPosY1))/2)/10;
		if(nbSegments>1){
			int tempPosX3=tempPosX1,tempPosY3=tempPosY1;
			int tempPosX4,tempPosY4;
			float p4x,p4y;
			for(int i=1;i<nbSegments-1;i++){
				p4x=(p1x*(nbSegments-i)+p2x*i)/nbSegments;
				p4y=(p1y*(nbSegments-i)+p2y*i)/nbSegments;
//				 calcul coor4
				angle=Segment.calculAngle(new Point2D.Double(p4x,p4y), pCentre);
				double distance4=zoom*Math.sqrt( (p4x-pCentre.getX())*(p4x-pCentre.getX()) 
						+ (p4y-pCentre.getY())*(p4y-pCentre.getY()) );
//				pour rester dans l'espace affichable
				if(distance4>(100+Couronne.TROU_MILIEU)) distance4=(100+Couronne.TROU_MILIEU);
				double tempval4=1-Couronne.toHyperbolic(1-distance4/(100+Couronne.TROU_MILIEU));
				tempPosX4=(int) (Math.cos(angle)*tempval4*largeur);
				tempPosY4=(int) (Math.sin(angle)*tempval4*hauteur);
				//on dessine
				createSegments(tempPosX3, tempPosY3, tempPosX4, tempPosY4, g, pCentre, largeur, hauteur, zoom);
				//g.drawLine(tempPosX3,tempPosY3,tempPosX4,tempPosY4);
				tempPosX3=tempPosX4;
				tempPosY3=tempPosY4;
			}
			
			createSegments(tempPosX3, tempPosY3, tempPosX2, tempPosY2, g, pCentre, largeur, hauteur, zoom);
			//g.drawLine(tempPosX3,tempPosY3,tempPosX2,tempPosY2);
			
		}else{
			createSegments(tempPosX1, tempPosY1, tempPosX2, tempPosY2, g, pCentre, largeur, hauteur, zoom);
			//g.drawLine(tempPosX1,tempPosY1,tempPosX2,tempPosY2);
			
		}*/
		tempval=Math.abs(tempPosX2-tempPosX1)+Math.abs(tempPosY2-tempPosY1);
		if(tempval < 5){
		}else if(tempval<20){
			//g.drawLine(tempPosX, tempPosY, tempPosX, tempPosY);
			g.drawLine(tempPosX1, tempPosY1, tempPosX2, tempPosY2);
		}else{
			createSegments(p1x, p1y, p2x, p2y, tempPosX1, tempPosY1, tempPosX2, tempPosY2, g, pCentre, largeur, hauteur, zoom);
		}
		
		
		
		/*/ affichage mode normal
		tempPosX1=(int) ((p1x/100)*largeur);
		tempPosY1=(int) (((p1y)/100)*hauteur);

		tempPosX2=(int) ((p2x/100)*largeur);
		tempPosY2=(int) (((p2y)/100)*hauteur);
		g.drawLine(tempPosX1,tempPosY1,tempPosX2,tempPosY2);/* */
	}
	
	private void createSegments(float p1x, float p1y, float p2x, float p2y, int tempPosX1, int tempPosY1, int tempPosX2,int tempPosY2, Graphics2D g, Point2D pCentre, double largeur, double hauteur, double zoom){
		if(((Math.abs(tempPosX2-tempPosX1)+Math.abs(tempPosY2-tempPosY1)))>20){
			//System.err.println(Math.abs(tempPosX2-tempPosX1)+", "+Math.abs(tempPosY2-tempPosY1));
			int nbSegments=5;
			int tempPosX3=tempPosX1,tempPosY3=tempPosY1;
			int tempPosX4,tempPosY4;
			float p4x,p4y, p3x=p1x, p3y=p1y;
			for(int i=1;i<nbSegments-1;i++){
				p4x=(p1x*(nbSegments-i)+p2x*i)/nbSegments;
				p4y=(p1y*(nbSegments-i)+p2y*i)/nbSegments;
	//			 calcul coor4
				double angle=Segment.calculAngle(new Point2D.Double(p4x,p4y), pCentre);
				double distance4=zoom*Math.sqrt( (p4x-pCentre.getX())*(p4x-pCentre.getX()) 
						+ (p4y-pCentre.getY())*(p4y-pCentre.getY()) );
	//			pour rester dans l'espace affichable
				if(distance4>(100+Couronne.TROU_MILIEU)) distance4=(100+Couronne.TROU_MILIEU);
				double tempval4=1-Couronne.toHyperbolic(1-distance4/(100+Couronne.TROU_MILIEU));
				tempPosX4=(int) (Math.cos(angle)*tempval4*largeur);
				tempPosY4=(int) (Math.sin(angle)*tempval4*hauteur);
				//on dessine
				createSegments(p3x, p3y, p4x, p4y, tempPosX3, tempPosY3, tempPosX4, tempPosY4, g, pCentre, largeur, hauteur, zoom);
				//g.drawLine(tempPosX3,tempPosY3,tempPosX4,tempPosY4);
				tempPosX3=tempPosX4;
				tempPosY3=tempPosY4;
				p3x=p4x;
				p3y=p4y;
			}
			createSegments(p3x, p3y, p2x, p2y, tempPosX3, tempPosY3, tempPosX2, tempPosY2, g, pCentre, largeur, hauteur, zoom);
			
		}else{
			g.drawLine(tempPosX1,tempPosY1,tempPosX2,tempPosY2);
		}
		
	}
	
	//correct \/
	public static Double calculAngle(Point2D p1, Point2D p2)
	{
		double prodscal=p1.getX()-p2.getX();
		double norm=Math.sqrt( (p1.getX()-p2.getX())*(p1.getX()-p2.getX()) 
								+ (p1.getY()-p2.getY())*(p1.getY()-p2.getY()) );
		if(norm==0)return (p1.getY()-p2.getY()>0?0:Math.PI);
		return (p1.getY()-p2.getY())>0?Math.acos(prodscal/norm):Math.PI*2-Math.acos(prodscal/norm);
	}
	

}
