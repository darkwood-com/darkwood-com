package interface2;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.AffineTransform;
import java.awt.geom.Point2D;

import visu.UserTrack;

public class Legende {

	private double posx, posy;
	//private double angle;
	//private double rating;
	private String texte;

	public Legende(double angle, String t) {
		//this.angle=angle;
		//this.rating=rating;
		posx=(Math.cos(angle)*(110));
		posy=(Math.sin(angle)*(110));
		texte=t;
	}
	
	
	public void paintComponent(Graphics2D g, Point2D pCentre, double largeur, double hauteur, double zoom){
		int tempPosX,tempPosY;
		//tempPosX=(int) ((posx/100)*largeur);
		//tempPosY=(int) (((posy)/100)*hauteur);
		
		double angle=(Segment.calculAngle(new Point2D.Double(posx,posy), pCentre));
		double distance=zoom*Math.sqrt( (posx-pCentre.getX())*(posx-pCentre.getX()) 
				+ (posy-pCentre.getY())*(posy-pCentre.getY())+0.0001d );
		double tempval=1-Couronne.toHyperbolic(1-distance/110);
		tempPosX=(int) (Math.cos(angle)*tempval*largeur);
		tempPosY=(int) (Math.sin(angle)*tempval*hauteur);
		
		g.setColor(Color.BLACK);
		AffineTransform init=g.getTransform();
		AffineTransform trsfLegende= g.getTransform();
		trsfLegende.translate(Math.cos(angle) * (largeur + 20), ( Math.sin(angle) * (hauteur + 20) ));
		if(Math.cos(angle)<0){
			trsfLegende.rotate(angle-Math.PI);
			g.setTransform(trsfLegende);
			g.drawString(texte, 10-texte.length()*6 ,0);//
		}else{
			trsfLegende.rotate(angle);
			g.setTransform(trsfLegende);
			g.drawString(texte, -10 ,0);
		}
		//		(int) ( Math.cos(angle) * (largeur + 20)-10 ),
		//		(int) ( Math.sin(angle) * (hauteur + 20)+10 ) );
		g.setTransform(init);
	}
	
	
	
	
}
