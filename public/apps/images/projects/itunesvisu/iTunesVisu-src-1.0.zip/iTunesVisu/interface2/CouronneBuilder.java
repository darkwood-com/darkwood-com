package interface2;

import java.util.Collection;
import java.util.LinkedList;

import filtres.FiltresEvent;

import visu.User;
import visu.UserTrack;

public abstract class CouronneBuilder {

	//pour construire la couronne la premiere fois, initialise tout
	public abstract void createCouronne(FiltresEvent f, 
			LinkedList<Etiquette> mesEtiquettes, 
			LinkedList<Segment> mesSegments, 
			LinkedList<Legende> mesLegendes);
	
	//pour changer la couronne avec des annimation d'un builder a un autre
	public abstract void changeCouronne(FiltresEvent f, 
			LinkedList<Etiquette> lesEtiquettes, 
			LinkedList<Segment> mesSegments, 
			LinkedList<Legende> mesLegendes);
	
}
