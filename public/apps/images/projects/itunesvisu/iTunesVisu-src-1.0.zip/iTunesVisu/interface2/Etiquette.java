package interface2;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.geom.Point2D;

import visu.UserTrack;

public class Etiquette {

	private double posx, posy;
	private double angle;
	private double rating;
	private UserTrack morceau;
	private int tempPosX=0,tempPosY=0;
	private boolean drawCarre=false;

	public Etiquette(float rating, double angle, UserTrack m) {
		this.angle=angle;
		this.rating=rating;
		posx=(Math.cos(angle)*(100-rating+Couronne.TROU_MILIEU));
		posy=(Math.sin(angle)*(100-rating+Couronne.TROU_MILIEU));
		morceau=m;
	}
	

	public double getPosx() {
		return posx;
	}


	public double getPosy() {
		return posy;
	}

	public double getAnneauPosx() {
		return tempPosX;
	}


	public double getAnneauPosy() {
		return tempPosY;
	}
	
	public boolean isDrawing(){
		return drawCarre;
	}


	public void paintComponent(Graphics2D g, Point2D pCentre, double largeur, double hauteur, double zoom){
		//tempPosX=(int) ((posx/100)*largeur);
		//tempPosY=(int) (((posy)/100)*hauteur);
		
		double angle=Segment.calculAngle(new Point2D.Double(posx,posy), pCentre);
		double distance=zoom*Math.sqrt( (posx-pCentre.getX())*(posx-pCentre.getX()) 
				+ (posy-pCentre.getY())*(posy-pCentre.getY()) );
		
		//si on sort de l'espace affichable
		if(distance>=100+Couronne.TROU_MILIEU){
			tempPosX=(int) (Math.cos(angle)*largeur);
			tempPosY=(int) (Math.sin(angle)*hauteur);
			g.setColor(Color.BLACK);
			//g.drawLine(tempPosX, tempPosY, tempPosX, tempPosY);
			g.drawRect(tempPosX, tempPosY, 1, 1);
		}else{
			double tempval= 1-Couronne.toHyperbolic(1-distance/(100+Couronne.TROU_MILIEU));
			tempPosX=(int) (Math.cos(angle)*tempval*largeur);
			tempPosY=(int) (Math.sin(angle)*tempval*hauteur);
	
			g.setColor(Color.BLACK);
			//on dessine quelque chose en focntion de son endroit d'affichage
			drawCarre=false;
			if(tempval>0.999){
			}else if(tempval>0.99){
				//g.drawLine(tempPosX, tempPosY, tempPosX, tempPosY);
				g.drawRect(tempPosX, tempPosY, 1, 1);
			}else if(tempval>0.9){
				g.drawRect(tempPosX-1, tempPosY-1, 2, 2);
			}else if(tempval>0.8){
				g.drawRect(tempPosX-2, tempPosY-2, 4, 4);
			}else{
				drawCarre=true;
				g.drawRect(tempPosX-30, tempPosY-6, 60, 12);
				if( morceau.getName().length()<=10){
					g.drawString(morceau.getName(),tempPosX-29, tempPosY+5);
				}else{
					g.drawString(morceau.getName().substring(0, 9),tempPosX-29, tempPosY+5);
				}
			}
		}
	}


	public UserTrack getMorceau() {
		return morceau;
	}
	
}
