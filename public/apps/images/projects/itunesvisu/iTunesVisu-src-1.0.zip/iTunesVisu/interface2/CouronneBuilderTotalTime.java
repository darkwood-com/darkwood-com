/**
 * 
 */
package interface2;

import java.awt.Color;
import java.awt.Dimension;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;

import filtres.FiltresEvent;

import visu.User;
import visu.UserTrack;

/**
 * @author rdurand
 *
 */
public class CouronneBuilderTotalTime extends CouronneBuilder {

	@Override
	public void createCouronne(FiltresEvent f, 
			LinkedList<Etiquette> mesEtiquettes, 
			LinkedList<Segment> mesSegments, 
			LinkedList<Legende> mesLegendes) {
		UserTrack temp;
		Iterator<UserTrack> it = f.listeUT.iterator();
		double totalTimeMax=0;
		double min;
		double max;
		double totalTimeMin=Double.MAX_VALUE;
		double tempAngle;
		int tempDistance;
		while(it.hasNext()){
			temp=it.next();
			if(temp.getTotalTime()>=f.minTotalTime && temp.getTotalTime()<=f.maxTotalTime &&
					temp.getRating(f.u) >= f.minRating && temp.getRating(f.u) <= f.maxRating &&
					temp.getSize() >= f.minSize && temp.getSize() <= f.maxSize &&
					temp.getBitRate() >= f.minBitRate && temp.getBitRate() <= f.maxBitRate &&
					temp.getSampleRate() >= f.minSampleRate && temp.getSampleRate() <= f.maxSampleRate &&
					temp.getPlayCount(f.u) >= f.minPlayCount && temp.getPlayCount(f.u) <= f.maxPlayCount
			){
				if(totalTimeMin>temp.getTotalTime()) totalTimeMin=temp.getTotalTime();
				if(totalTimeMax<temp.getTotalTime()) totalTimeMax=temp.getTotalTime(); 
			}
		}
		min=totalTimeMin;
		max=totalTimeMax+(totalTimeMax-totalTimeMin)*0.1; //on rajoute 10% pour faire une d�limitation
		//System.err.println("min="+min+", max="+max);
		it = f.listeUT.iterator();
		while(it.hasNext()){
			temp=it.next();
			if(temp.getTotalTime()>=f.minTotalTime && temp.getTotalTime()<=f.maxTotalTime &&
					temp.getRating(f.u) >= f.minRating && temp.getRating(f.u) <= f.maxRating &&
					temp.getSize() >= f.minSize && temp.getSize() <= f.maxSize &&
					temp.getBitRate() >= f.minBitRate && temp.getBitRate() <= f.maxBitRate &&
					temp.getSampleRate() >= f.minSampleRate && temp.getSampleRate() <= f.maxSampleRate &&
					temp.getPlayCount(f.u) >= f.minPlayCount && temp.getPlayCount(f.u) <= f.maxPlayCount
			){
				if(!temp.getName().equals("aucun")){
					tempAngle=temp.getTotalTime()-min;
					tempAngle=((tempAngle*2*Math.PI)/(max-min));
					mesEtiquettes.add(new Etiquette(temp.getRating(f.u),tempAngle,  temp));
				}
			}
		}

		//on ajoute les "ronds"
		drawRond(mesSegments, Color.BLACK, 0, 20);
		drawRond(mesSegments, Color.RED, 20, 40);
		drawRond(mesSegments, Color.YELLOW, 40, 60);
		drawRond(mesSegments, Color.ORANGE, 60, 80);
		drawRond(mesSegments, Color.GREEN, 80, 100);
		drawRond(mesSegments, Color.LIGHT_GRAY, 100, 100);
		
		for(int angle=0;angle<340;angle+=10){
			String toDraw=Integer.toString((int) ((min+angle*(max-min)/360)/1000));
			mesLegendes.add(new Legende(Math.PI*angle/180,toDraw));
		}
		
	}
	
	private void drawRond(LinkedList<Segment> segments, Color couleur, float rating, float ratingVertical){
		Segment tempEti;
		int segsize=15;
		for(int i=0;i<360;i+=segsize){
			/*tempEti=new Segment(
					(float) (Math.cos(i*Math.PI/180)*(100-rating)),
					(float) (Math.sin(i*Math.PI/180)*(100-rating)),
					(float) (Math.cos((i+30)*Math.PI/180)*(100-rating)),
					(float) (Math.sin((i+30)*Math.PI/180)*(100-rating)),
					couleur
					);*/
			tempEti=new Segment(rating, i*Math.PI/180, (i+segsize)*Math.PI/180, couleur);
			segments.add(tempEti);
			if(rating!=ratingVertical){
				tempEti=new Segment(rating, ratingVertical , i*Math.PI/180, Color.GRAY);
				segments.add(tempEti);
			}
		}
	}

	@Override
	public void changeCouronne(FiltresEvent f, 
			LinkedList<Etiquette> lesEtiquettes, 
			LinkedList<Segment> mesSegments, 
			LinkedList<Legende> mesLegendes) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	
}
