package filtres;

import java.util.EventListener;

import bislider.BiSlider;

//cours sur http://rom.developpez.com/java-listeners/

public interface FiltresListener extends EventListener {
	void filtresChanged(FiltresEvent e);
}
