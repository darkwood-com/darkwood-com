package filtres;

import interface1.Interface1;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButton;
import javax.swing.JSlider;

import sun.java2d.loops.DrawLine;
import visu.DateVizu;
import visu.Genre;
import visu.Kind;
import visu.Track;
import visu.TrackNumber;
import visu.User;
import visu.UserTrack;
import visu.Visu;

import bislider.*;

public class InterfaceFiltres extends JPanel implements ActionListener{
	protected ButtonGroup choixUtilisateur;
	protected JRadioButton utilisateur1, utilisateur2, aimerais1, aimerais2;
	protected JPanel panelGeneral,panelTemp,panelTemp2, panelLegendes;
	protected JLabel intitule, legende1, legende2, labelTemp;
	protected JButton reset = new JButton("reset"), ok = new JButton("ok");
	final BiSlider ratings = new BiSlider(BiSlider.RGB), playDateUTC= new BiSlider(BiSlider.RGB);
	final BiSlider duree = new BiSlider(BiSlider.RGB), taille = new BiSlider(BiSlider.RGB);
	final BiSlider bitRate = new BiSlider(BiSlider.RGB), dateAdded = new BiSlider(BiSlider.RGB);
	final BiSlider playcount = new BiSlider(BiSlider.RGB), sampleRate = new BiSlider(BiSlider.RGB);
	protected static float LineX=0f;
	
	private ArrayList<FiltresListener> filtres = new ArrayList<FiltresListener>();
	private ArrayList<BiSlider> bisliderActifs = new ArrayList<BiSlider>();
	
	public InterfaceFiltres() {
		Visu.getInstance(); //pour initialiser sinon ca bug
		initComponents();
		// Configuration g�n�rale :
		add(panelGeneral);
		//setTitle("Visionnage des Pr�f�rences");
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		//pack();
        setVisible(true);
	}
	
	private void initComponents() {		
		// On cr�� lees �l�ments g�n�raux :
		panelGeneral = new JPanel();
		intitule = new JLabel("FILTRES");
		legende1 = new JLabel();	legende1.setText("<html>" +"<span style='color: red;'>" + "Utilisateur1" + "</span>" + "</html>");
		legende2 = new JLabel();	legende2.setText("<html>" +"<span style='color: blue;'>" + "Utilisateur2" + "</span>" + "</html>");
	
		BoxLayout boxPourPanelGeneral = new BoxLayout(panelGeneral,BoxLayout.Y_AXIS);
		panelGeneral.setLayout(boxPourPanelGeneral);
		panelGeneral.add(intitule);  panelGeneral.add(new JLabel(" "));
		
		// Affichage des bisliders :
		configureBiSlider(ratings,"Note",UserTrack.getMinRating(), UserTrack.getMaxRating(),1);
		configureBiSlider(duree,"Dur�e",UserTrack.getMinTotalTime(),UserTrack.getMaxTotalTime(),5);
		configureBiSlider(taille,"Taille",UserTrack.getMinSize(),UserTrack.getMaxSize(),500000);
		configureBiSlider(bitRate,"Bit Rate",UserTrack.getMinBitRate(),UserTrack.getMaxBitRate(),32);
		configureBiSlider(sampleRate,"Sample Rate",UserTrack.getMinSampleRate(),UserTrack.getMaxSampleRate(),10000);
		configureBiSlider(playcount,"Playcount",0,500,10);
		//configureBiSlider(dateAdded,"Date d'ajout",48491000,new Long("1199194091000"),new Long("157766400000"));	
		
		// On affiche les l�gendes en ligne :
		panelLegendes = new JPanel();
		BoxLayout boxPourLegendes = new BoxLayout(panelLegendes,BoxLayout.Y_AXIS);
		panelLegendes.setLayout(boxPourLegendes);
		panelLegendes.add(legende1);  
		panelLegendes.add(legende2);  
		panelGeneral.add(panelLegendes);
		
		//Affichage des boutons :
		reset.addActionListener(this);  ok.addActionListener(this);
		
		// On cr�� le groupRadio pour le choix d'utilisateur :
		choixUtilisateur = new ButtonGroup();
		utilisateur1 = new JRadioButton(Visu.getInstance().getUser1().getNomFichier());
		utilisateur2 = new JRadioButton(Visu.getInstance().getUser2().getNomFichier());
		aimerais1 = new JRadioButton("Ce que "+Visu.getInstance().getUser1().getNomFichier()+" n'a pas ");
		aimerais2 = new JRadioButton("Ce que "+Visu.getInstance().getUser2().getNomFichier()+" n'a pas ");
		
		// On affecte les radioButtons au ButtonGroup :
		choixUtilisateur.add(utilisateur1);
		choixUtilisateur.add(utilisateur2);
		choixUtilisateur.add(aimerais1);
		choixUtilisateur.add(aimerais2);
		
		choixUtilisateur.setSelected(utilisateur1.getModel(), true);
		
		panelTemp = new JPanel();
		panelTemp2 = new JPanel();
		BoxLayout boxPourPanelTemp = new BoxLayout(panelTemp,BoxLayout.X_AXIS);
		panelTemp.setLayout(boxPourPanelTemp);
		BoxLayout boxPourPanelTemp2 = new BoxLayout(panelTemp2,BoxLayout.Y_AXIS);
		panelTemp2.setLayout(boxPourPanelTemp2);
		panelTemp2.add(utilisateur1); panelTemp2.add(utilisateur2);
		panelTemp2.add(aimerais1);panelTemp2.add(aimerais2);
		panelTemp.add(panelTemp2);
		panelTemp.add(reset); panelTemp.add(new JLabel("         "));  panelTemp.add(ok);
		panelGeneral.add(panelTemp);
	}

	public void configureBiSlider( BiSlider slider, final String name, long minimum, long maximum, long minor){
		    slider.setToolTipText("No line to highlight the ticks here");
		    slider.setMinimumValue(minimum);
		    slider.setMaximumValue(maximum);
		    slider.setSegmentSize(minor);
		    slider.setMinimumColor(Color.GREEN);
		    slider.setMaximumColor(Color.GREEN);
		    slider.setOpaque(true);
		    slider.setSliderBackground(new Color(152, 152, 192));
		    slider.setFont(new Font("SansSerif", Font.ITALIC|Font.BOLD, 12));
		    slider.setPrecise(true);
		    slider.setMinimumColoredValue(minimum);
		    slider.setMaximumColoredValue(maximum);
		    slider.addContentPainterListener(new ContentPainterListener(){
			  private ArrayList<Integer> vals, vals2;
			  private int max, max2;
		      
		      public void paint(ContentPainterEvent event){
		        Graphics2D Graphics2 = (Graphics2D)event.getGraphics();
		        Rectangle Rect1 = event.getRectangle();
		        Rectangle Rect2 = event.getBoundingRectangle();
		        
		        if (event.getColor()!=null) {
		          Graphics2.setColor(event.getColor());
		          Graphics2.setPaint(new GradientPaint(Rect1.x, Rect1.y, event.getColor(),
		            Rect1.x+(int)(LineX*Rect1.width), Rect1.y, event.getColor().brighter()));
		          Graphics2.fillRect(Rect1.x, Rect1.y, (int)(LineX*Rect1.width), Rect1.height);
	          
		          Graphics2.setPaint(new GradientPaint(Rect1.x+(int)(LineX*Rect1.width), Rect1.y, event.getColor().brighter(),
		            Rect1.x+Rect1.width, Rect1.y, event.getColor()));
		          Graphics2.fillRect(Rect1.x+(int)(LineX*Rect1.width), Rect1.y, Rect1.width-(int)(LineX*Rect1.width), Rect1.height);
		        }
		        //Graphics2.setColor(Color.RED);
		          
		          //cas premier: on calcule tout
		          if(event.getSegmentIndex()==0 ){
		        	  vals=new ArrayList<Integer>(((BiSlider)event.getSource()).getSegmentCount()+1);
		        	  vals2=new ArrayList<Integer>(((BiSlider)event.getSource()).getSegmentCount()+1);
		        	  double segSize=((BiSlider)event.getSource()).getSegmentSize();
		        	  double segSizeD2=segSize/2;
		        	  Iterator<UserTrack> it, itBis;
			          int nbMax=0, nbMax2=0;
			          max=1;
			          max2=1;
			          UserTrack utTemp;
		        	  // Pour chaque segment
		        	  for(int i=0; i<=((BiSlider)event.getSource()).getSegmentCount(); i++){
		        		   // Pour l'utilisateur 1 :
		        		   it= Visu.getInstance().getUser1().getPossede().iterator();
		        		   nbMax=0;
		        		   while(it.hasNext()){
		        			   	utTemp=it.next();
		        			   	// On diff�rencie les bisliders :
		        			   	if(name.equals("Note")) {
		        			   		if( utTemp.getRating(Visu.getInstance().getUser1()) >= (segSize*i - segSizeD2)*20 &&
						 		       		  utTemp.getRating(Visu.getInstance().getUser1()) < (segSize*i + segSizeD2)*20 ){
						 		      		  nbMax++;
	        			   			}
		        			   	} else if (name.equals("Dur�e")) {
		        			   		// On s�lectionne les userTracks dont la note est comprise entre les bornes 
		        			   		if(utTemp.getRating(Visu.getInstance().getUser1())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser1())/20 <= ratings.getMaximumColoredValue()){
			        			   		if( utTemp.getTotalTimeMinute() >= (segSize*i - segSizeD2) &&
							 		       		  utTemp.getTotalTimeMinute() < (segSize*i + segSizeD2) ){
							 		      		  nbMax++;
		        			   			}
		        			   		}
		        			   	} else if (name.equals("Taille")) {
		        			   		if(utTemp.getRating(Visu.getInstance().getUser1())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser1())/20 <= ratings.getMaximumColoredValue()
		        			   		   && utTemp.getTotalTimeMinute() >= duree.getMinimumColoredValue() && utTemp.getTotalTimeMinute() <= duree.getMaximumColoredValue() ){
			        			   		if( utTemp.getSize() >= (segSize*i - segSizeD2) &&
							 		       		  utTemp.getSize() < (segSize*i + segSizeD2) ){
							 		      		  nbMax++;
		        			   			}
		        			   		}
		        			   	} else if (name.equals("Bit Rate")) {
		        			   		if(utTemp.getRating(Visu.getInstance().getUser1())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser1())/20 <= ratings.getMaximumColoredValue()
				        			   && utTemp.getTotalTimeMinute() >= duree.getMinimumColoredValue() && utTemp.getTotalTimeMinute() <= duree.getMaximumColoredValue()
				        			   && utTemp.getSize() >= taille.getMinimumColoredValue() && utTemp.getSize() <= taille.getMaximumColoredValue()){
			        			   		if( utTemp.getBitRate() >= (segSize*i - segSizeD2) &&
							 		       		  utTemp.getBitRate() < (segSize*i + segSizeD2) ){
							 		      		  nbMax++;
		        			   			}
		        			   		}
		        			   	} else if (name.equals("Sample Rate")) {
		        			   		if(utTemp.getRating(Visu.getInstance().getUser1())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser1())/20 <= ratings.getMaximumColoredValue()
						        			   && utTemp.getTotalTimeMinute() >= duree.getMinimumColoredValue() && utTemp.getTotalTimeMinute() <= duree.getMaximumColoredValue()
						        			   && utTemp.getSize() >= taille.getMinimumColoredValue() && utTemp.getSize() <= taille.getMaximumColoredValue()
						        			   && utTemp.getBitRate() >= bitRate.getMinimumColoredValue() && utTemp.getBitRate()<= bitRate.getMaximumColoredValue()){
			        			   		if( utTemp.getSampleRate() >= (segSize*i - segSizeD2) &&
							 		       		  utTemp.getSampleRate() < (segSize*i + segSizeD2) ){
							 		      		  nbMax++;
		        			   			}
		        			   		}
		        			   	}
		        			    else if (name.equals("Playcount")) {
		        			    	if(utTemp.getRating(Visu.getInstance().getUser1())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser1())/20 <= ratings.getMaximumColoredValue()
		        		        			   && utTemp.getTotalTimeMinute() >= duree.getMinimumColoredValue() && utTemp.getTotalTimeMinute() <= duree.getMaximumColoredValue()
		        		        			   && utTemp.getSize() >= taille.getMinimumColoredValue() && utTemp.getSize() <= taille.getMaximumColoredValue()
		        		        			   && utTemp.getBitRate() >= bitRate.getMinimumColoredValue() && utTemp.getBitRate()<= bitRate.getMaximumColoredValue()
		        		        			   && utTemp.getSampleRate() >= sampleRate.getMinimumColoredValue() && utTemp.getSampleRate()<= sampleRate.getMaximumColoredValue()){
			        			   		if( utTemp.getPlayCount(Visu.getInstance().getUser1()) >= (segSize*i - segSizeD2) &&
							 		       		  utTemp.getPlayCount(Visu.getInstance().getUser1()) < (segSize*i + segSizeD2) ){
							 		      		  nbMax++;
		        			   			}
		        			    	}
		        			   	}
		        			   	else if (name.equals("Date d'ajout")) {
		        			   		if(utTemp.getRating(Visu.getInstance().getUser1())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser1())/20 <= ratings.getMaximumColoredValue()
		        		        			   && utTemp.getTotalTimeMinute() >= duree.getMinimumColoredValue() && utTemp.getTotalTimeMinute() <= duree.getMaximumColoredValue()
		        		        			   && utTemp.getSize() >= taille.getMinimumColoredValue() && utTemp.getSize() <= taille.getMaximumColoredValue()
		        		        			   && utTemp.getBitRate() >= bitRate.getMinimumColoredValue() && utTemp.getBitRate()<= bitRate.getMaximumColoredValue()
		        		        			   && utTemp.getSampleRate() >= sampleRate.getMinimumColoredValue() && utTemp.getSampleRate()<= sampleRate.getMaximumColoredValue()
		        		        			   && utTemp.getPlayCount(Visu.getInstance().getUser1()) >= playcount.getMinimumColoredValue() && utTemp.getPlayCount(Visu.getInstance().getUser1())<= playcount.getMaximumColoredValue()){
			        			   		if( ((DateVizu)utTemp.getDateAdded(Visu.getInstance().getUser1())).getDate().getTime() >= (segSize*i - segSizeD2) &&
			        			   				((DateVizu)utTemp.getDateAdded(Visu.getInstance().getUser1())).getDate().getTime() < (segSize*i + segSizeD2) ){
							 		      		  nbMax++;
		        			   			}
		        			   		}
		        			   	}
		        		   }
		        		   if(nbMax>max){ max=nbMax; }
		        		   vals.add(i, new Integer(Rect2.height*nbMax));
		        		   
		        		   // Pour l'utilisateur 2 :
		        		   nbMax2=0;
		        		   itBis= Visu.getInstance().getUser2().getPossede().iterator();
		        		   while(itBis.hasNext()){
		        			   	utTemp=itBis.next();
		        			   	// On diff�rencie les bisliders :
		        			   	if(name.equals("Note")) {
		        			   		if( utTemp.getRating(Visu.getInstance().getUser2()) >= (segSize*i - segSizeD2)*20 &&
		        		 		       		  utTemp.getRating(Visu.getInstance().getUser2()) < (segSize*i + segSizeD2)*20 ){
		        			   				nbMax2++;
		        		   			}
		        			   	} else if (name.equals("Duree")) {
		        			   		// On s�lectionne les userTracks dont la note est comprise entre les bornes 
		        			   		if(utTemp.getRating(Visu.getInstance().getUser2())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser2())/20 <= ratings.getMaximumColoredValue()){
		        				   		if( utTemp.getTotalTimeMinute() >= (segSize*i - segSizeD2) &&
		        			 		       		  utTemp.getTotalTimeMinute() < (segSize*i + segSizeD2) ){
		        				   				nbMax2++;
		        			   			}
		        			   		}
		        			   	} else if (name.equals("Taille")) {
		        			   		if(utTemp.getRating(Visu.getInstance().getUser2())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser2())/20 <= ratings.getMaximumColoredValue()
		        			   		   && utTemp.getTotalTimeMinute() >= duree.getMinimumColoredValue() && utTemp.getTotalTimeMinute() <= duree.getMaximumColoredValue() ){
		        				   		if( utTemp.getSize() >= (segSize*i - segSizeD2) &&
		        			 		       		  utTemp.getSize() < (segSize*i + segSizeD2) ){
		        				   				nbMax2++;
		        			   			}
		        			   		}
		        			   	} else if (name.equals("Bit Rate")) {
		        			   		if(utTemp.getRating(Visu.getInstance().getUser2())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser2())/20 <= ratings.getMaximumColoredValue()
		        	 			   && utTemp.getTotalTimeMinute() >= duree.getMinimumColoredValue() && utTemp.getTotalTimeMinute() <= duree.getMaximumColoredValue()
		        	 			   && utTemp.getSize() >= taille.getMinimumColoredValue() && utTemp.getSize() <= taille.getMaximumColoredValue()){
		        				   		if( utTemp.getBitRate() >= (segSize*i - segSizeD2) &&
		        			 		       		  utTemp.getBitRate() < (segSize*i + segSizeD2) ){
		        				   				nbMax2++;
		        			   			}
		        			   		}
		        			   	} else if (name.equals("Sample Rate")) {
		        			   		if(utTemp.getRating(Visu.getInstance().getUser2())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser2())/20 <= ratings.getMaximumColoredValue()
		        		        			   && utTemp.getTotalTimeMinute() >= duree.getMinimumColoredValue() && utTemp.getTotalTimeMinute() <= duree.getMaximumColoredValue()
		        		        			   && utTemp.getSize() >= taille.getMinimumColoredValue() && utTemp.getSize() <= taille.getMaximumColoredValue()
		        		        			   && utTemp.getBitRate() >= bitRate.getMinimumColoredValue() && utTemp.getBitRate()<= bitRate.getMaximumColoredValue()){
		        				   		if( utTemp.getSampleRate() >= (segSize*i - segSizeD2) &&
		        			 		       		  utTemp.getSampleRate() < (segSize*i + segSizeD2) ){
		        				   				nbMax2++;
		        			   			}
		        			   		}
		        			   	}
		        			    else if (name.equals("Playcount")) {
		        			    	if(utTemp.getRating(Visu.getInstance().getUser2())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser2())/20 <= ratings.getMaximumColoredValue()
		        		        			   && utTemp.getTotalTimeMinute() >= duree.getMinimumColoredValue() && utTemp.getTotalTimeMinute() <= duree.getMaximumColoredValue()
		        		        			   && utTemp.getSize() >= taille.getMinimumColoredValue() && utTemp.getSize() <= taille.getMaximumColoredValue()
		        		        			   && utTemp.getBitRate() >= bitRate.getMinimumColoredValue() && utTemp.getBitRate()<= bitRate.getMaximumColoredValue()
		        		        			   && utTemp.getSampleRate() >= sampleRate.getMinimumColoredValue() && utTemp.getSampleRate()<= sampleRate.getMaximumColoredValue()){
			        			   		if( utTemp.getPlayCount(Visu.getInstance().getUser2()) >= (segSize*i - segSizeD2) &&
							 		       		  utTemp.getPlayCount(Visu.getInstance().getUser2()) < (segSize*i + segSizeD2) ){
							 		      		  nbMax2++;
		        			   			}
		        			    	}
		        			   	}
		        			   	else if (name.equals("Date d'ajout")) {
		        			   		if(utTemp.getRating(Visu.getInstance().getUser2())/20 >= ratings.getMinimumColoredValue() && utTemp.getRating(Visu.getInstance().getUser2())/20 <= ratings.getMaximumColoredValue()
		        		        			   && utTemp.getTotalTimeMinute() >= duree.getMinimumColoredValue() && utTemp.getTotalTimeMinute() <= duree.getMaximumColoredValue()
	        		        				   && utTemp.getSize() >= taille.getMinimumColoredValue() && utTemp.getSize() <= taille.getMaximumColoredValue()
        		        					   && utTemp.getBitRate() >= bitRate.getMinimumColoredValue() && utTemp.getBitRate()<= bitRate.getMaximumColoredValue()
    		        			    		   && utTemp.getSampleRate() >= sampleRate.getMinimumColoredValue() && utTemp.getSampleRate()<= sampleRate.getMaximumColoredValue()
    		        			    		   && utTemp.getPlayCount(Visu.getInstance().getUser2()) >= playcount.getMinimumColoredValue() && utTemp.getPlayCount(Visu.getInstance().getUser2())<= playcount.getMaximumColoredValue()){
			        			   		if( ((DateVizu)utTemp.getDateAdded(Visu.getInstance().getUser2())).getDate().getTime() >= (segSize*i - segSizeD2) &&
			        			   				((DateVizu)utTemp.getDateAdded(Visu.getInstance().getUser2())).getDate().getTime() < (segSize*i + segSizeD2) ){
							 		      		  nbMax2++;
		        			   			}
		        			   		}
		        			   	}
		        		   }
		        		   if(nbMax2>max2){ max2=nbMax2; }
		        		   vals2.add(i, new Integer(Rect2.height*nbMax2));
		        	  }  
			      }	    
       		      Graphics2.setColor(Color.RED);	// Pour user1
				  Graphics2.drawLine(Rect2.x, Rect2.y+Rect2.height-vals.get(event.getSegmentIndex())/max, Rect2.x+Rect2.width, Rect2.y+Rect2.height-vals.get(event.getSegmentIndex()+1)/max);
       		   	  Graphics2.setColor(Color.BLUE);	// Pour user2
				  Graphics2.drawLine(Rect2.x, Rect2.y+Rect2.height-vals2.get(event.getSegmentIndex())/max2, Rect2.x+Rect2.width, Rect2.y+Rect2.height-vals2.get(event.getSegmentIndex()+1)/max2);
		      }
		    });
		    panelTemp = new JPanel(new GridLayout());
		    slider.setName(name);
		    panelTemp.add(new JLabel(name));
		    panelTemp.add(slider);
		    panelGeneral.add(panelTemp);
		    bisliderActifs.add(slider);
	}
	
	public void afficherTousLesSliders() {
		System.out.println("---------");
		afficherSliders(ratings);
		afficherSliders(duree);
		afficherSliders(taille);
		afficherSliders(bitRate);
		afficherSliders(dateAdded);
		afficherSliders(playcount);
		System.out.println("---------");
	}
	public void afficherSliders(BiSlider slider) {
		System.out.println(slider.getName() + " : ("
				+ slider.getMinimumColoredValue() + ","
				+ slider.getMaximumColoredValue() + ")");		
	}
	
	public void actionPerformed(ActionEvent e) {
			if(e.getSource()==ok){
				//System.out.println("on a appuy� sur ok");
				//afficherTousLesSliders();
				
				ArrayList<UserTrack> listeUT = null;
				User eU = null;
				
				ButtonModel bm = choixUtilisateur.getSelection();
				if(bm.equals(utilisateur1.getModel()))
				{
					listeUT = Visu.getInstance().getUser1().getPossede();
					eU = Visu.getInstance().getUser1();
				}
				else if(bm.equals(utilisateur2.getModel()))
				{
					listeUT = Visu.getInstance().getUser2().getPossede();
					eU = Visu.getInstance().getUser2();
				}
				else if(bm.equals(aimerais1.getModel()))
				{
					listeUT = Visu.getInstance().getUser1().getAimerais();
					eU = Visu.getInstance().getUser1();
				}
				else if(bm.equals(aimerais2.getModel()))
				{
					listeUT = Visu.getInstance().getUser2().getAimerais();
					eU = Visu.getInstance().getUser2();
				}
				
				FiltresEvent fE = new FiltresEvent(
				(float) ratings.getMinimumColoredValue()*20, (float) ratings.getMaximumColoredValue()*20, //Rating
				(float) duree.getMinimumColoredValue()*1000*60, (float) duree.getMaximumColoredValue()*1000*60, //TotalTime
				(float) taille.getMinimumColoredValue(), (float) taille.getMaximumColoredValue(), //Size
				(float) bitRate.getMinimumColoredValue(), (float) bitRate.getMaximumColoredValue(), //BitRate
				(float) sampleRate.getMinimumColoredValue(), (float) sampleRate.getMaximumColoredValue(),  //SampleRate
				(float) playcount.getMinimumColoredValue(), (float) playcount.getMaximumColoredValue(), //playcount
				listeUT, eU
				);
				
				Iterator<FiltresListener> itFiltres = filtres.iterator();
				FiltresListener fl;
				while(itFiltres.hasNext()) {
					fl = itFiltres.next();
					fl.filtresChanged(fE);
				}
			}
			if(e.getSource()==reset) {
				// On remet les valeurs du curseurs aux limites :
				ratings.setMinimumColoredValue(ratings.getMinimumValue());
			    ratings.setMaximumColoredValue(ratings.getMaximumValue());
			    duree.setMinimumColoredValue(duree.getMinimumValue());
			    duree.setMaximumColoredValue(duree.getMaximumValue());
			    taille.setMinimumColoredValue(taille.getMinimumValue());
			    taille.setMaximumColoredValue(taille.getMaximumValue());
			    bitRate.setMinimumColoredValue(bitRate.getMinimumValue());
			    bitRate.setMaximumColoredValue(bitRate.getMaximumValue());
			    sampleRate.setMinimumColoredValue(sampleRate.getMinimumValue());
			    sampleRate.setMaximumColoredValue(sampleRate.getMaximumValue());
			    playcount.setMinimumColoredValue(playcount.getMinimumValue());
			    playcount.setMaximumColoredValue(playcount.getMaximumValue());
			}
	}
	
	public void addFiltresListener(FiltresListener fl) {
		filtres.add(fl);
	}
	
	/*public static void main(String[] args) {
		ArrayList<UserTrack> tab= new ArrayList<UserTrack>();
		ArrayList<UserTrack> tabBis= new ArrayList<UserTrack>();
		
		User u=new User(1);
		User uBis=new User(2);
		
		Track t1=new Track("chanson 1");
		Track t2=new Track("chanson 2");
		Track t3=new Track("chanson 3");
		Track t4=new Track("chanson 4");
		
		Genre g=new Genre("genre");
		Kind k=new Kind("kind");
		TrackNumber tn=new TrackNumber(0);
		
		tab.add(new UserTrack(t1,g,k, 1097593,318458,tn,128,44100));
		tab.add(new UserTrack(t1,g,k, 3097593,3546897,tn,128,44100));
		tab.add(new UserTrack(t2,g,k, 4097593,523425,tn,128,30000));
		tab.add(new UserTrack(t3,g,k, 4097593,3546897,tn,256,44100));
		tab.add(new UserTrack(t4,g,k, 3097593,621546,tn,64,44100));
		tab.add(new UserTrack(t4,g,k, 2097593,121546,tn,256,50100));
		tab.add(new UserTrack(t4,g,k, 1097593,423546,tn,32,10100));
		
		tabBis.add(new UserTrack(t1,g,k, 1097593,821556,tn,256,44100));
		tabBis.add(new UserTrack(t1,g,k, 1097593,321546,tn,256,44100));
		tabBis.add(new UserTrack(t2,g,k, 3097593,821556,tn,128,30000));
		tabBis.add(new UserTrack(t3,g,k, 4097593,3546897,tn,256,44100));
		tabBis.add(new UserTrack(t4,g,k, 3097593,621546,tn,64,44100));
		tabBis.add(new UserTrack(t4,g,k, 1097593,821556,tn,256,50100));
		tabBis.add(new UserTrack(t4,g,k, 1097593,821556,tn,256,10100));
		
		DateVizu d;
		int playcount = 0;
		try {
			d = new DateVizu("2006-09-21T14:28:11Z");
			
			Random r=new Random();
			Iterator<UserTrack> it = tab.iterator();
			UserTrack tempUT;
			while(it.hasNext()){
				playcount+=50;
				long dateModifiee = d.getDate().getTime()+new Long("157766400000");
				d = new DateVizu(dateModifiee);
				tempUT=it.next();
				tempUT.setUserInfos(d, d, playcount, d, "qql part", u);
				tempUT.setRating(u, r.nextFloat()*100);
				u.getPossede().add(tempUT);
			}
		} catch (ParseException e) {
				e.printStackTrace();
		}
		
		try {
			d = new DateVizu("2006-09-21T14:28:11Z");

			Random r=new Random();
			Iterator<UserTrack> itBis = tabBis.iterator();
			UserTrack tempUT; playcount=20;
			while(itBis.hasNext()){
				playcount+=50;
				long dateModifiee = d.getDate().getTime()+new Long("157766400000");
				d = new DateVizu(dateModifiee);
				tempUT=itBis.next();
				tempUT.setUserInfos(d, d, playcount, d, "qql part", uBis);
				tempUT.setRating(uBis, r.nextFloat()*100);
				uBis.getPossede().add(tempUT);
			}
		} catch (ParseException e) {
				e.printStackTrace();
		}
		Visu.setVisu(u, uBis);
		new InterfaceFiltres();
	}*/
}