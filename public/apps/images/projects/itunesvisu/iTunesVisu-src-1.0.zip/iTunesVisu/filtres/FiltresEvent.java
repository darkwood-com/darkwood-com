package filtres;

import java.util.ArrayList;
import java.util.HashMap;

import visu.User;
import visu.UserTrack;

import bislider.BiSlider;

public class FiltresEvent {
	//on rend public afin de ne pas faire beaucoup de fonctions getter
	public float minRating, maxRating;
	public float minTotalTime, maxTotalTime;
	public float minSize, maxSize;
	public float minBitRate, maxBitRate;
	public float minSampleRate, maxSampleRate;
	public float minPlayCount, maxPlayCount;
	
	public ArrayList<UserTrack> listeUT; //utilisateur que l'on a selectionne
	public User u;
	
	public FiltresEvent(float minRating, float maxRating,
				float minTotalTime, float maxTotalTime,
				float minSize, float maxSize,
				float minBitRate, float maxBitRate,
				float minSampleRate, float maxSampleRate,
				float minPlayCount, float maxPlayCount,
				ArrayList<UserTrack> listeUT, User u) {
		this.minRating = minRating; this.maxRating = maxRating;
		this.minTotalTime = minTotalTime; this.maxTotalTime = maxTotalTime;
		this.minSize = minSize; this.maxSize = maxSize;
		this.minBitRate = minBitRate; this.maxBitRate = maxBitRate;
		this.minSampleRate = minSampleRate; this.maxSampleRate = maxSampleRate;
		this.minPlayCount = minPlayCount; this.maxPlayCount = maxPlayCount;
		this.listeUT = listeUT;
		this.u = u;
	}
	
	public String toString() {
		return minRating+", "+maxRating+", "+
		minTotalTime+", "+maxTotalTime+", "+
		minSize+", "+maxSize+", "+
		minBitRate+", "+maxBitRate+", "+
		minSampleRate+", "+maxSampleRate;
	}
}
