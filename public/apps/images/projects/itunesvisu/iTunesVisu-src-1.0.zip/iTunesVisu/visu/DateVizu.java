package visu;


import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DateVizu {
	private Date date;
	
	public DateVizu(String dateStr) throws ParseException
	{
		DateFormat dt =  new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
		date = dt.parse(dateStr);
		
		//System.out.println(date.toString());
	}
	
	public DateVizu(int date)
	{
		this.date = new Date(date);
	}
	
	public DateVizu(long date)
	{
		this.date = new Date(date);
	}

	public Date getDate() {
		return date;
	}
}
