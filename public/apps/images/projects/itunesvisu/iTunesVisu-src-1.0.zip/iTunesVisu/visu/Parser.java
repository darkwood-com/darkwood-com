package visu;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JProgressBar;

import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;

public class Parser {
	private User u1;
	private User u2;
	private JProgressBar barre;
	
	public Parser(File file1, File file2, JProgressBar bar) {
		try {
			barre=bar;
			ArrayList<UserTrack> uniqueTracks = new ArrayList<UserTrack>();
			u1 = new User(1); u1.setNomFichier(file1.getName());
			u2 = new User(2); u2.setNomFichier(file2.getName());
			barre.setValue( (int)(10) );
			barre.setString ("Progression: " + (int)(10) + "%, lecture de "+file1+".");
			parse(file1, u1, uniqueTracks);
			barre.setValue( (int)(40) );
			barre.setString ("Progression: " + (int)(40) + "%, lecture de "+file2+".");
			parse(file2, u2, uniqueTracks);
			barre.setValue( (int)(70) );
			u1.addnoOwnedUserTrack(uniqueTracks);
			barre.setValue( (int)(75) );
			u2.addnoOwnedUserTrack(uniqueTracks);
			barre.setValue( (int)(80) );
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			System.out.println("Erreur du parseur");
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Erreur du parseur");
			e.printStackTrace();
		}
	}
	
	public User getUser1() {
		return u1;
	}

	public User getUser2() {
		return u2;
	}
	
	public void parse(File file, User user, ArrayList<UserTrack> uniqueTracks)  throws SAXException, IOException {
		XMLReader saxReader = XMLReaderFactory.createXMLReader();
		saxReader.setContentHandler(new MusicContentHandler(user, uniqueTracks));
        saxReader.parse(file.getAbsolutePath());
	}
}
