package visu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Album {
	private String name; //nom de l'album [cle]
	
	private ArrayList<TrackNumber> trackNumbers; //cet album est contenu dans la liste des numeros de morceaux

	private HashMap<User,Float> rating; //rating de l'album de 0 a 100
	
	public static ArrayList<Album> ALBUMS=new ArrayList<Album>();
	
	Album(String name)
	{
		this.name = name;

		trackNumbers = new ArrayList<TrackNumber>();
		rating = new HashMap<User,Float>();
		
	}
	
	public Album merge(Album a)
	{
		if(this.name.equalsIgnoreCase(a.name))
			 return this;
		else return a;
	}
	
	public void updateBackReferences(TrackNumber tN)
	{
		boolean notFound = true;
		
		Iterator<TrackNumber> it = trackNumbers.iterator();
		while(it.hasNext())
		{
			if(it.next() == tN) notFound = false;
		}
		
//		on met a jour le liste des albums.
		if(!ALBUMS.contains(this)) ALBUMS.add(this);
		
		if(notFound) trackNumbers.add(tN);
	}

	public void setRating(User currentUser, float albumRating) {
		rating.put(currentUser, albumRating);
	}
	
	public Float getRating(User u){
		return rating.get(u);
	}
	
	public String getName() {
		return name;
	}
}
