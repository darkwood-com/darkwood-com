package visu;

import java.awt.BorderLayout;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileFilter;

public class Visu {
	
	static public Visu me=null;
	
	static public synchronized Visu getInstance(){
		if(me==null){
			JFileChooser chooser1=new JFileChooser("Choisissez le premier fichier xml:");
		    int returnVal = chooser1.showOpenDialog(null);
		    if(returnVal == JFileChooser.APPROVE_OPTION) {
	    			JFileChooser chooser2=new JFileChooser("Choisissez le deuxieme fichier xml:");
		   		    int returnVal2 = chooser2.showOpenDialog(null);
		   		    if(returnVal2 == JFileChooser.APPROVE_OPTION) {
		   		    		   me=new Visu(chooser1.getSelectedFile(),chooser2.getSelectedFile());
		   		    		  return me;
		   		    }
		    }
			System.exit(0);
		   
		}
		return me;
	}
	
	private User u1;
	private User u2;
	
	private Visu(String file1, String file2) {
		final JProgressBar maBarre = new JProgressBar(0,99);
		maBarre.setString("Lecture des bibliotheques");
		maBarre.setStringPainted(true);
		maBarre.addChangeListener(new ChangeListener(){
			public void stateChanged(ChangeEvent arg0) {
				maBarre.setString ("Progression: " + (int)(maBarre.getPercentComplete()*100) + "%");
			}
		});
		JFrame j=new JFrame();
		j.setLayout(new BorderLayout());
		j.add(maBarre,BorderLayout.CENTER);
		j.setSize(300,50); //On donne une taille a notre fenetre
		j.setLocationRelativeTo(null); //On centre la fenetre sur l'ecran
		j.setVisible(true);
		System.err.println("visu");
		Parser parser = new Parser(new File(file1), new File(file2), maBarre);
		
		u1 = parser.getUser1();
		u2 = parser.getUser2();
		
		u1.createRating();
		maBarre.setValue( (int)(90) );
		u2.createRating();
		maBarre.setValue( (int)(100) );

		u1.estimateMissingRating();
		u2.estimateMissingRating();
		
		j.dispose();
	}
	
	private Visu(File file1, File file2) {
			
	
		final JProgressBar maBarre = new JProgressBar(0,99);
		maBarre.setString("Lecture des bibliotheques");
		maBarre.setStringPainted(true);
		maBarre.addChangeListener(new ChangeListener(){
			public void stateChanged(ChangeEvent arg0) {
				maBarre.setString ("Progression: " + (int)(maBarre.getPercentComplete()*100) + "%");
			}
		});
		JFrame j=new JFrame();
		j.setLayout(new BorderLayout());
		j.add(maBarre,BorderLayout.CENTER);
		j.setSize(300,50); //On donne une taille a notre fenetre
		j.setLocationRelativeTo(null); //On centre la fenetre sur l'ecran
		j.setVisible(true);
		
		Parser parser = new Parser(file1, file2, maBarre);
		
		u1 = parser.getUser1();
		u2 = parser.getUser2();
		
		u1.createRating();
		maBarre.setValue( (int)(90) );
		u2.createRating();
		maBarre.setValue( (int)(100) );

		u1.estimateMissingRating();
		u2.estimateMissingRating();
		
		j.dispose();
	}
	
	public User getUser1() {
		return u1;
	}
	
	public User getUser2() {
		return u2;
	}

	//pour les tests
	static public void setVisu(User u1, User u2){
		me=new Visu(u1, u2);
	}
	
	private Visu(User u1, User u2) {
		this.u1=u1;
		this.u2=u2;
	}
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Visu.getInstance();
	}

}
