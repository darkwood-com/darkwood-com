/**
 * 
 */
package visu;

import java.awt.BorderLayout;
import java.awt.event.KeyEvent;

import filtres.InterfaceFiltres;
import interface1.Interface1;
import interface1.Outils;
import interface1.ThreadInterface1;
import interface1.Wheel;
import interface2.Interface2;

import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JTabbedPane;

/**
 * @author rdurand
 *
 */
public class JFrameAppliVisu extends JFrame {

	private InterfaceFiltres intf;
	private Interface1 i1;
	private Interface2 i2;
	
	
	JFrameAppliVisu(int width, int height) {
		setTitle("Comparaison de musitheque"); //On donne un titre a l'application
		setSize(width,height); //On donne une taille a notre fenetre
		setLocationRelativeTo(null); //On centre la fenetre sur l'ecran
		setResizable(true); //On autorise la redimensionnement de la fenetre
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); //On dit a l'application de se fermer lors du clic sur la cro
		setLayout(new BorderLayout());
		
		createComponents();
		
		setVisible(true);//On rend la roue visible
		
	}
	
	private void createComponents() {

		//creation interface des filtres
		intf=new InterfaceFiltres();
		
		//creation de l'interface 1
		Interface1 i1=new Interface1(400,400);
		i1.modifyUser(Visu.getInstance().getUser1(), Visu.getInstance().getUser1().getPossede());
		intf.addFiltresListener(i1);
		
		//thread pour animer l'affichage
		ThreadInterface1 TI = new ThreadInterface1(i1);
		TI.start();
		
		//creation de l'interface 2
		Interface2 i2=new Interface2(Visu.getInstance(), intf);
		
		JTabbedPane tabbedPane = new JTabbedPane();


		JComponent panel0 = intf;
		/*tabbedPane.addTab("Preferences", null, panel0,
		                  "Permet de s�lectionner de que l'on d�sire afficher.");
		tabbedPane.setMnemonicAt(0, KeyEvent.VK_1);*/
		
		JComponent panel1 = i1;
		tabbedPane.addTab("Visualisation Disque", null, panel1,
		                  "Permet de visualiser les musiques de ce qui est s�lectionn� dans les pr�f�rences.");
		tabbedPane.setMnemonicAt(0, KeyEvent.VK_1);

		JComponent panel2 = i2;
		tabbedPane.addTab("Visualisation Sphere", null, panel2,
		                  "Permet de visualiser les musiques de ce qui est s�lectionn� dans les pr�f�rences.");
		tabbedPane.setMnemonicAt(1, KeyEvent.VK_2);


		this.setLayout(new BorderLayout());
		this.add(tabbedPane, BorderLayout.CENTER);
		this.add(panel0, BorderLayout.WEST);
		
		//Couronne cou=new Couronne(data.getPossede(), data);
		
		//j.addMouseListener(cou);
		//j.addMouseMotionListener(cou);
		//cou.addMouseListener(cou);
		//cou.addMouseMotionListener(cou);
		//cou.addMouseWheelListener(cou);
		
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		JFrameAppliVisu j=new JFrameAppliVisu(1000,500);
	}

}
