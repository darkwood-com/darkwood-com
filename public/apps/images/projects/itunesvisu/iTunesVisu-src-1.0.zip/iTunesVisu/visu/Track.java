package visu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Track {
	private String name; //nom du morceau [cle]
	private Artist artist; //artiste qui a compose le morceau [cle]
	
	private ArrayList<UserTrack> userTracks; //ce morceau est contenu dans la liste des morceaux utilisateur

	private HashMap<User,Float> rating; //rating de la chanson de 0 a 100
	
	public Track(String name)
	{
		this.name = name;
		
		userTracks = new ArrayList<UserTrack>();
		rating=new HashMap<User,Float>();
	}
	
	public void setArtist(Artist artist)
	{
		this.artist = artist;
	}
	
	public Track merge(Track t)
	{
		t.artist = artist.merge(t.artist);
		
		if(this.name.equalsIgnoreCase(t.name) &&
		   this.artist == t.artist)
			 return this;
		else return t;
	}
	
	public void updateBackReferences(UserTrack uT)
	{
		artist.updateBackReferences(this);
		
		boolean notFound = true;
		
		Iterator<UserTrack> it = userTracks.iterator();
		while(it.hasNext())
		{
			if(it.next() == uT) notFound = false;
		}
		
		if(notFound) userTracks.add(uT);
	}
	
	public String getName(){
		return name;
	}
	
	public Artist getArtiste(){
		return artist;
	}

	public ArrayList<UserTrack> getUserTracks() {
		return userTracks;
	}

	public void setRating(User user, float f) {
		rating.put(user, f);
	}
	
	public Float getRating(User u){
		return rating.get(u);
	}
	
}
