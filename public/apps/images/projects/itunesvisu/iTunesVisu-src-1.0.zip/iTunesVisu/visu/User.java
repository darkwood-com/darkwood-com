package visu;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class User {
	private int userNumber; //utilisateur 1 ou 2
	//l'utilisateur possede une liste de tracks
	private ArrayList<UserTrack> possede;
	//l'utilisateur aimerais avoir une liste de tracks pour rejoindre la bibliotheque de l'autre utilisateur
	private ArrayList<UserTrack> aimerais;
	
	private String nomFichier="";
	
	public String getNomFichier() {
		return nomFichier;
	}

	public void setNomFichier(String nomFichier) {
		this.nomFichier = nomFichier;
	}

	public User(int userNumber)
	{
		this.userNumber = userNumber;
		
		this.possede = new ArrayList<UserTrack>();
		this.aimerais = new ArrayList<UserTrack>();
	}

	public ArrayList<UserTrack> getAimerais() {
		return aimerais;
	}

	public ArrayList<UserTrack> getPossede() {
		return possede;
	}
	
	public void addUserTrack(UserTrack uT)
	{
		possede.add(uT);
	}
	
	public void addnoOwnedUserTrack(Collection<UserTrack> tab ){
		UserTrack temp;
		Iterator<UserTrack> it = tab.iterator();
		while(it.hasNext()){
			temp=it.next();
			if(!possede.contains(temp)){
				aimerais.add(temp);
			}
		}
	}

	public Integer getNum() {
		return userNumber;
	}
	
	/**
	 * permet de faire remonter les preferences g�n�rales issues des notes des morceaux dans les autres classes.
	 *
	 */
	public void createRating(){
		
		float somme, sommeTemp;
		int nombre, nombreTemp;
		Genre leGenre;
		UserTrack leMorceau;
		Artist lArtiste;
		Track leTrack;
		Kind leKind;
		
		//les genres de musiques
		nombre=0;
		somme=0;
		Iterator<Genre> itGenre = Genre.GENRES.iterator();
		while(itGenre.hasNext()){
			//pour chaque genre
			leGenre = itGenre.next();
			//pour chaque morceau de ce genre
			Iterator<UserTrack> itMorceau = leGenre.getUserTracks().iterator();
			while(itMorceau.hasNext()){
				leMorceau = itMorceau.next();
				//si on le possede
				if(leMorceau.isOwner(this)){
					//on additionne 
					somme+=leMorceau.getRating(this);
					//on compte
					nombre++;
				}
				
			}
			//on met le rating du genre a jour
			if(nombre==0){
				leGenre.setRating(this, 0f);
			}else{
				leGenre.setRating(this, somme/nombre);
			}
		}
		
		//les artistes et chansons
		nombre=0;
		somme=0;
		//pour chaque artiste
		Iterator<Artist> itArtiste = Artist.ARTISTES.iterator();
		while(itArtiste.hasNext()){
			lArtiste=itArtiste.next();
			//pour chaque morceau
			Iterator<Track> itTrack = lArtiste.getTracks().iterator();
			while(itTrack.hasNext()){
				leTrack=itTrack.next();
				nombreTemp=0;
				sommeTemp=0;
				
				//pour chaque userTrack
				Iterator<UserTrack> itMorceau = leTrack.getUserTracks().iterator();
				while(itMorceau.hasNext()){
					leMorceau=itMorceau.next();
					
					//si on le possede
					if(leMorceau.isOwner(this)){
						//on additionne 
						sommeTemp+=leMorceau.getRating(this);
						//on compte
						nombreTemp++;
					}
				}
				//on met le rating dans le track
				if(nombreTemp==0){
					leTrack.setRating(this, 0f);
				}else{
					leTrack.setRating(this, sommeTemp/nombreTemp);
				}
				somme+=sommeTemp;
				nombre+=nombreTemp;
				
			}
//			on met le rating dans l'artiste
			if(nombre==0){
				lArtiste.setRating(this, 0f);
			}else{
				lArtiste.setRating(this, somme/nombre);
			}
			
		}
		
		//avec les kinds
		nombre=0;
		somme=0;
		Iterator<Kind> itKind = Kind.KINDS.iterator();
		while(itKind.hasNext()){
			//pour chaque genre
			leKind = itKind.next();
			//pour chaque morceau de ce genre
			Iterator<UserTrack> itMorceau = leKind.getUserTracks().iterator();
			while(itMorceau.hasNext()){
				leMorceau = itMorceau.next();
				//si on le possede
				if(leMorceau.isOwner(this)){
					//on additionne 
					somme+=leMorceau.getRating(this);
					//on compte
					nombre++;
				}
				
			}
			//on met le rating du genre a jour
			if(nombre==0){
				leKind.setRating(this, 0f);
			}else{
				leKind.setRating(this, somme/nombre);
			}
		}
		
	}
	
	/**
	 * calcule les preferences des usersTracks que l'on ne poss�de pas.
	 *
	 */
	public void estimateMissingRating(){
		Iterator<UserTrack> itUT = aimerais.iterator();
		UserTrack utCourant;
		while(itUT.hasNext()){
			utCourant=itUT.next();
			utCourant.setRating(this, utCourant);
			utCourant.setPlayCount(this, 0);
		}
	}
	
}
