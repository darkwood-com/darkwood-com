package visu;

import java.util.ArrayList;
import java.util.Iterator;

public class TrackNumber {
	private int trackNumber; //numero du morceau dans l'album [user]
	private Album album; //nom de l'album dans lequl est contenu ce numero de morceau [cle]
	
	private ArrayList<UserTrack> userTracks; //numero du morceau est contenu dans la liste des morceaux utilisateur
	
	public TrackNumber(int trackNumber)
	{
		this.trackNumber = trackNumber;
		
		userTracks = new ArrayList<UserTrack>();
	}
	
	public void setAlbum(Album album)
	{
		this.album = album;
	}
	
	public TrackNumber merge(TrackNumber t)
	{
		t.album = album.merge(t.album);
		
		if(//this.trackNumber == t.trackNumber &&
		   this.album == t.album)
			 return this;
		else return t;
	}
	
	public void updateBackReferences(UserTrack uT)
	{
		album.updateBackReferences(this);
		
		boolean notFound = true;
		
		Iterator<UserTrack> it = userTracks.iterator();
		while(it.hasNext())
		{
			if(it.next() == uT) notFound = false;
		}
		
		if(notFound) userTracks.add(uT);
	}

	public Album getAlbum() {
		return album;
	}
}
