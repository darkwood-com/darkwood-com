package visu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Genre {
	private String name; //nom du genre [cle]
	
	private ArrayList<UserTrack> userTracks; //ce genre est contenu dans la liste des morceaux utilisateur

	private HashMap<User,Float> rating; //rating du genre de 0 a 100
	
	public static ArrayList<Genre> GENRES=new ArrayList<Genre>();//la liste des genres
	
	public Genre(String name)
	{
		this.name = name;
		
		userTracks = new ArrayList<UserTrack>();
		rating=new HashMap<User,Float>();
	}
	
	public Genre merge(Genre g)
	{
		if(this.name.equalsIgnoreCase(g.name))
			 return this;
		else return g;
	}
	
	public void updateBackReferences(UserTrack uT)
	{
		boolean notFound = true;
		
		Iterator<UserTrack> it = userTracks.iterator();
		while(it.hasNext())
		{
			if(it.next() == uT) notFound = false;
		}
		
		//on met a jour le liste des genres.
		if(!GENRES.contains(this)) GENRES.add(this);
		
		if(notFound) userTracks.add(uT);
	}

	public ArrayList<UserTrack> getUserTracks() {
		return userTracks;
	}
	
	public void setRating(User u, Float rate){
		rating.put(u, rate);
	}
	
	public Float getRating(User u){
		return rating.get(u);
	}
	
	public String getName(){
		return name;
	}
}
