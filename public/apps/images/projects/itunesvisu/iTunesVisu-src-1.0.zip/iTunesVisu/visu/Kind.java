package visu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Kind {
	private String name; //nom du format de fichier [cle]
	
	private ArrayList<UserTrack> userTracks; //ce format de fichier est contenu dans la liste des morceaux utilisateur

	private HashMap<User,Float> rating; //rating du codec (peu prit en compte) de 0 a 100
	
	public static ArrayList<Kind> KINDS=new ArrayList<Kind>();
	
	public Kind(String name)
	{
		this.name = name;
		
		userTracks = new ArrayList<UserTrack>();
		rating=new HashMap<User,Float>();
	}
	
	public Kind merge(Kind k)
	{
		if(this.name.equalsIgnoreCase(k.name))
			 return this;
		else return k;
	}
	
	public void updateBackReferences(UserTrack uT)
	{
		boolean notFound = true;
		
		Iterator<UserTrack> it = userTracks.iterator();
		while(it.hasNext())
		{
			if(it.next() == uT) notFound = false;
		}
		
//		on met a jour le liste des codecs.
		if(!KINDS.contains(this)) KINDS.add(this);
		
		if(notFound) userTracks.add(uT);
	}
	
	public String getName(){
		return name;
	}

	public float getRating(User u) {
		return rating.get(u);
	}

	public void setRating(User u, float rate) {
		this.rating.put(u, rate);
	}

	public ArrayList<UserTrack> getUserTracks() {
		return userTracks;
	}
}
