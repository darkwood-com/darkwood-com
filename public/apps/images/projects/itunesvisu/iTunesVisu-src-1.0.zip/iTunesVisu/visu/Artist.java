package visu;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

public class Artist {
	private String name; //nom de l'artiste [cle]
	
	private ArrayList<Track> tracks; //morceaux composes par l'artiste
	private HashMap<User,Float> rating;
	
	public static ArrayList<Artist> ARTISTES=new ArrayList<Artist>();
	
	Artist(String name)
	{
		this.name = name;
		
		tracks = new ArrayList<Track>();
		rating=new HashMap<User,Float>();
	}
	
	public Artist merge(Artist a)
	{
		if(this.name.equalsIgnoreCase(a.name))
			return this;
		else return a;
	}
	
	public void updateBackReferences(Track t)
	{
		boolean notFound = true;
		
		Iterator<Track> it = tracks.iterator();
		while(it.hasNext())
		{
			if(it.next() == t) notFound = false;
		}
		
//		on met a jour le liste des artistes.
		if(!ARTISTES.contains(this)) ARTISTES.add(this);
		
		if(notFound) tracks.add(t);
	}

	public ArrayList<Track> getTracks() {
		return tracks;
	}

	public void setRating(User u, Float rate) {
		this.rating.put(u, rate);
	}

	public String getName(){
		return name;
	}
	
	public Float getRating(User u){
		return rating.get(u);
	}
	
	
}
