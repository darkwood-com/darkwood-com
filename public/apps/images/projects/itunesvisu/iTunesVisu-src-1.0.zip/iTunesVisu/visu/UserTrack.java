package visu;

import java.util.HashMap;
import java.util.ArrayList;

import filtres.FiltresEvent;

public class UserTrack {
	private Track track; //morceau	[cle]
	private Genre genre; //genre	[cle]
	private Kind kind; //type de format de fichier	[cle]
	private int size; //taille du morceau en Bits	[cle] [fitre]
	private int totalTime; //temps total du morceau	[cle] [fitre]
	private TrackNumber trackNumber; //numero du morceau de l'album (permet d'acceder a album)	[cle]
	private HashMap<User,DateVizu> dateModified; //date de modification du fichier	[user]
	private HashMap<User,DateVizu> dateAdded; //date d'ajout du fichier	[user] [fitre]
	private int bitRate; //birate de l'encodage	[cle] [fitre]
	private int sampleRate; //sampleRate du morceau	[cle] [fitre]
	private HashMap<User,Integer> playCount; //nombre de fois que le morceau a ete ecoute	[user] [fitre]
	private HashMap<User,DateVizu> playDateUTC; //derniere ecoute	[user] [fitre]
	private HashMap<User,Float> rating; //rating du morceau de 0 a 100	[user] [fitre]
	//private int albumRating; //rating de l'album de 0 a 100
	private HashMap<User,String> location; //chemin absolu vers le fichier	[user]
	
	//valeurs minimales et maximales utiles pour des bisliders
	static float minRating = Float.MAX_VALUE, maxRating = Float.MIN_VALUE; //sur 100
	static float minTotalTime = Float.MAX_VALUE, maxTotalTime = Float.MIN_VALUE; //en ms
	static float minSize = Float.MAX_VALUE, maxSize = Float.MIN_VALUE;
	static float minBitRate = Float.MAX_VALUE, maxBitRate = Float.MIN_VALUE;
	static float minSampleRate = Float.MAX_VALUE, maxSampleRate = Float.MIN_VALUE;
	
	static public int getMaxRating() {
		return (int) (maxRating / 20);
	}
	
	static public int getMinRating() {
		return (int) (minRating / 20);
	}
	
	static public int getMinTotalTime() {
		return (int)(minTotalTime / (1000 * 60));
	}
	
	static public int getMaxTotalTime() {
		return (int)(maxTotalTime / (1000 * 60));
	}
	
	static public int getMinSize() {
		return (int) minSize;
	}
	
	static public int getMaxSize() {
		return (int) maxSize;
	}
	
	static public int getMinBitRate() {
		return (int) minBitRate;
	}
	
	static public int getMaxBitRate() {
		return (int) maxBitRate;
	}
	
	static public int getMinSampleRate() {
		return (int) minSampleRate;
	}
	
	static public int getMaxSampleRate() {
		return (int) maxSampleRate;
	}
	
	//ici, le track est possede par l'utilisateur 1 et/ou l'utilisateur 2
	//private User u1Possede;
	//private User u2Possede;
	private HashMap<Integer,User> uPossede;
	
	//ici, le track serai aime par l'utilisateur 1 ou l'utilisateur 2
	//pour avoir la meme bibliotheque que l'utilisateur 2 respectivement l'utilisateur 1
	//private User u1Aimerais;
	//private User u2Aimerais;
	
	public static ArrayList<UserTrack> USERTRACKS=new ArrayList<UserTrack>();
	
	public UserTrack(Track track,
			 Genre genre,
			 Kind kind,
			 int size,
			 int totalTime,
			 TrackNumber trackNumber,
			 //Date dateModified,
			 //Date dateAdded,
			 int bitRate,
			 int sampleRate
			 //int playCount,
			 //Date playDateUTC,
			 //String location,
			 //User user
			 )
	{
		this.track = track;
		this.genre = genre;
		this.kind = kind;
		
		if(minSize > size) minSize = size;
		if(maxSize < size) maxSize = size;
		this.size = size;
		
		if(minTotalTime > totalTime) minTotalTime = totalTime;
		if(maxTotalTime < totalTime) maxTotalTime = totalTime;
		this.totalTime = totalTime;
		this.trackNumber = trackNumber;
		//this.dateModified = dateModified;
		//this.dateAdded = dateAdded;
		
		if(minBitRate > bitRate) minBitRate = bitRate;
		if(maxBitRate < bitRate) maxBitRate = bitRate;
		this.bitRate = bitRate;
		
		if(minSampleRate > sampleRate) minSampleRate = sampleRate;
		if(maxSampleRate < sampleRate) maxSampleRate = sampleRate;
		this.sampleRate = sampleRate;
		//this.playCount = playCount;
		//this.playDateUTC = playDateUTC;
		//this.location = location;
		
		dateModified=new HashMap<User,DateVizu>();
		dateAdded=new HashMap<User,DateVizu>();
		playDateUTC=new HashMap<User,DateVizu>();
		playCount=new HashMap<User,Integer>();
		rating=new HashMap<User,Float>();
		location=new HashMap<User,String>();
		uPossede=new HashMap<Integer,User>();
		
	}
	
	public void setUserInfos(
			 //TrackNumber trackNumber,
			 DateVizu dateModified,
			 DateVizu dateAdded,
			 int playCount,
			 DateVizu playDateUTC,
			 String location,
			 User user)
	{
		//this.trackNumber.put(user, trackNumber);
		this.dateModified.put(user, dateModified);
		this.dateAdded.put(user, dateAdded);
		this.playCount.put(user, new Integer(playCount));
		this.playDateUTC.put(user, playDateUTC);
		this.location.put(user, location);
		this.uPossede.put(user.getNum(), user);
		
	}
	
	public UserTrack merge(UserTrack u)
	{
		u.track = track.merge(u.track);
		u.genre = genre.merge(u.genre);
		u.kind = kind.merge(u.kind);
		u.trackNumber = trackNumber.merge(u.trackNumber);
		
		if(this.track.equals(u.track) &&
		   this.genre.equals(u.genre) &&
		   this.kind.equals(u.kind) &&
		   this.size == u.size &&
		   this.totalTime == u.totalTime &&
		   this.bitRate == u.bitRate &&
		   this.trackNumber.equals(u.trackNumber) &&
		   this.sampleRate == u.sampleRate
		   )
			
		/* 
		   this.playCount == u.playCount &&
		   this.playDateUTC == u.playDateUTC &&
		   this.trackNumber == u.trackNumber &&
		   this.dateModified == u.dateModified &&
		   this.dateAdded == u.dateAdded &&
		   champs variables par user
		   this.rating == u.rating &&
		   this.albumRating == u.albumRating
		 */
			 return this;
		else return u;
	}
	
	public void updateBackReferences(User u)
	{
		track.updateBackReferences(this);
		genre.updateBackReferences(this);
		kind.updateBackReferences(this);
		trackNumber.updateBackReferences(this);
	}

	/*public void setUser1(User currentUser) {
		u1Possede = currentUser;
	}
	
	public void setUser2(User currentUser) {
		u2Possede = currentUser;
	}*/
	
	public void setRating(User user, UserTrack utCourant){
		float calcul=0;
		float nb=0;
		Float temp;
		temp=utCourant.getRating(utCourant.getOwners().get(user.getNum()==1?2:1));
		if(temp!=null){ calcul+=(temp.floatValue()*5); nb+=5; }
		temp=utCourant.getGenre().getRating(user);
		if(temp!=null){ calcul+=(temp.floatValue()*2); nb+=2; }
		temp=utCourant.getArtiste().getRating(user);
		if(temp!=null){ calcul+=temp.floatValue(); nb+=1; }
		temp=utCourant.getAlbum().getRating(user);
		if(temp!=null){ calcul+=temp.floatValue(); nb+=1; }
		temp=utCourant.getKind().getRating(user);
		if(temp!=null){ calcul+=(temp.floatValue()/5); nb+=0.2f; }
		
		setRating(user, calcul/nb);
	}
	
	public void setRating(User user, float rating){
		if(minRating > rating) minRating = rating;
		if(maxRating < rating) maxRating = rating;
		
		this.rating.put(user, new Float(rating));
	}

	public float getRating(User u) {
		return rating.get(u);
	}

	public HashMap<Integer, User> getOwners() {
		return uPossede;
	}

	public boolean isOwner(User u) {
		return uPossede.containsValue(u);
	}

	public boolean isOwner(int u) {
		return uPossede.containsKey(u);
	}
	
	public Album getAlbum(){
		return this.trackNumber.getAlbum();
	}
	
	public String getName(){
		return track.getName();
	}
	
	public Genre getGenre(){
		return genre;
	}
	
	public Kind getKind(){
		return kind;
	}	
	
	public Artist getArtiste(){
		return track.getArtiste();
	}
	
	public int getTotalTimeMinute() {
		return totalTime/(1000*60);
	}

	public Track getTrack() {
		return track;
	}

	public int getSize() {
		return size;
	}

	public int getTotalTime() {
		return totalTime;
	}

	public TrackNumber getTrackNumber() {
		return trackNumber;
	}

	public DateVizu getDateModified(User u) {
		return dateModified.get(u);
	}

	public DateVizu getDateAdded(User u) {
		return dateAdded.get(u);
	}

	public int getBitRate() {
		return bitRate;
	}

	public int getSampleRate() {
		return sampleRate;
	}

	public int getPlayCount(User u) {
		return playCount.get(u);
	}
	
	public void setPlayCount(User u, int val) {
		playCount.put(u, new Integer(val));
	}

	public DateVizu getPlayDateUTC(User u) {
		return playDateUTC.get(u);
	}

	public String getLocation(User u) {
		return location.get(u);
	}

	//on verifie si l'UserTrack fait partit du filtre f
	public boolean isInFiltre(FiltresEvent f, User u) {
		boolean filtre = true;
		
		//System.out.println("-----------");

		//rating
		float val = rating.get(u);
		filtre = filtre && f.minRating <= val && val <= f.maxRating;
		//System.out.println(filtre);
		
		//totalTime
		val = totalTime;
		filtre = filtre && f.minTotalTime <= val && val <= f.maxTotalTime;
		//System.out.println(val +" et "+ f.minTotalTime + " et "+f.maxTotalTime);
		
		//size
		val = size;
		filtre = filtre && f.minSize <= val && val <= f.maxSize;
		//System.out.println(val +" et "+ f.minSize + " et "+f.maxSize);
		
		//bitrate
		val = bitRate;
		filtre = filtre && f.minBitRate <= val && val <= f.maxBitRate;
		//System.out.println(val +" et "+ f.minBitRate + " et "+f.maxBitRate);
		
		//bitrate
		val = sampleRate;
		filtre = filtre && f.minSampleRate <= val && val <= f.maxSampleRate;
		//System.out.println(val +" et "+ f.minSampleRate + " et "+f.maxSampleRate);
		
		if(playCount.get(u) != null)
		{
			val = playCount.get(u);
			filtre = filtre && f.minPlayCount <= val && val <= f.maxPlayCount;
		}
		//System.out.println(val +" et "+ f.minPlayCount + " et "+f.maxPlayCount);
		//System.out.println();
		return filtre;
	}
	
	public String toString(){
		return this.getName();
	}
}
