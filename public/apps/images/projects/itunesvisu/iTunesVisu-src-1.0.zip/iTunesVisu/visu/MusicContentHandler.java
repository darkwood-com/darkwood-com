package visu;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;

import org.xml.sax.*;
import org.xml.sax.helpers.LocatorImpl;

/**
 * @author smeric
 *
 * Exemple d'implementation extremement simplifiee d'un SAX XML ContentHandler. Le but de cet exemple
 * est purement pedagogique.
 * Very simple implementation sample for XML SAX ContentHandler.
 */
public class MusicContentHandler implements ContentHandler {
	
	private int dictLvl;
	private boolean isKey;
	private String key;
	private boolean isValue;
	
	//variable d'un track en cours de parsage
	private Track track; //morceau
	private Artist artist; //artiste qui a compose le morceau
	private Genre genre; //genre
	private Kind kind; //type de format de fichier
	private int size; //taille du morceau en Bits
	private int totalTime; //temps total du morceau
	private TrackNumber trackNumber; //numero du morceau de l'album
	private Album album; //nom de l'album dans lequl est contenu ce numero de morceau
	private DateVizu dateModified; //date de modification du fichier
	private DateVizu dateAdded; //date d'ajout du fichier
	private int bitRate; //birate de l'encodage
	private int sampleRate; //sampleRate du morceau
	private int playCount; //nombre de fois que le morceau a ete ecoute
	private DateVizu playDateUTC; //derniere ecoute
	private int rating; //rating du morceau de 0 a 100
	private int albumRating; //rating de l'album de 0 a 100
	private String location; //chemin absolu vers le fichier
	
	//listes uniques des tracks parses
	private ArrayList<UserTrack> uniqueTracks;
	private User currentUser;
	
    /**
     * Constructeur par defaut. 
     */
    public MusicContentHandler(User user, ArrayList<UserTrack> uniqueTracks) {
            super();
            // On definit le locator par defaut.
            locator = new LocatorImpl();
            
            this.uniqueTracks = uniqueTracks;
            this.currentUser = user;
    }

    /**
     * Definition du locator qui permet a tout moment pendant l'analyse, de localiser
     * le traitement dans le flux. Le locator par defaut indique, par exemple, le numero
     * de ligne et le numero de caractere sur la ligne.
     * @author smeric
     * @param value le locator a utiliser.
     * @see org.xml.sax.ContentHandler#setDocumentLocator(org.xml.sax.Locator)
     */
    public void setDocumentLocator(Locator value) {
            locator =  value;
    }

    /**
     * Evenement envoye au demarrage du parse du flux xml.
     * @throws SAXException en cas de probleme quelquonque ne permettant pas de
     * se lancer dans l'analyse du document.
     * @see org.xml.sax.ContentHandler#startDocument()
     */
    public void startDocument() throws SAXException {
            System.out.println("Debut de l'analyse du document");
            
            dictLvl = 0;
            isKey = false;
            isValue = false;
    }

    /**
     * Evenement envoye a la fin de l'analyse du flux xml.
     * @throws SAXException en cas de probleme quelquonque ne permettant pas de
     * considerer l'analyse du document comme etant complete.
     * @see org.xml.sax.ContentHandler#endDocument()
     */
    public void endDocument() throws SAXException {
            System.out.println("Fin de l'analyse du document" );
    }

    /**
     * Debut de traitement dans un espace de nommage.
     * @param prefixe utilise pour cet espace de nommage dans cette partie de l'arborescence.
     * @param URI de l'espace de nommage.
     * @see org.xml.sax.ContentHandler#startPrefixMapping(java.lang.String, java.lang.String)
     */
    public void startPrefixMapping(String prefix, String URI) throws SAXException {
            System.out.println("Traitement de l'espace de nommage : " + URI + ", prefixe choisi : " + prefix);
    }

    /**
     * Fin de traitement de l'espace de nommage.
     * @param prefixe le prefixe choisi a l'ouverture du traitement de l'espace nommage.
     * @see org.xml.sax.ContentHandler#endPrefixMapping(java.lang.String)
     */
    public void endPrefixMapping(String prefix) throws SAXException {
            System.out.println("Fin de traitement de l'espace de nommage : " + prefix);
    }

    /**
     * Evenement recu a chaque fois que l'analyseur rencontre une balise xml ouvrante.
     * @param nameSpaceURI l'url de l'espace de nommage.
     * @param localName le nom local de la balise.
     * @param rawName nom de la balise en version 1.0 <code>nameSpaceURI + ":" + localName</code>
     * @throws SAXException si la balise ne correspond pas a ce qui est attendu,
     * comme par exemple non respect d'une dtd.
     * @see org.xml.sax.ContentHandler#startElement(java.lang.String, java.lang.String, java.lang.String, org.xml.sax.Attributes)
     */
    public void startElement(String nameSpaceURI, String localName, String rawName, Attributes attributs) throws SAXException {
    	if(localName.equals("dict")) dictLvl++;
    	else if(localName.equals("key")) isKey = true;
    	else if(localName.equals("string") || localName.equals("integer") || localName.equals("date")) isValue = true;
    }

    /**
     * Evenement recu a chaque fermeture de balise.
     * @see org.xml.sax.ContentHandler#endElement(java.lang.String, java.lang.String, java.lang.String)
     */
    public void endElement(String nameSpaceURI, String localName, String rawName) throws SAXException {
    	if(localName.equals("dict")) dictLvl--;
    	else if(localName.equals("key")) isKey = false;
    	else if(localName.equals("string") || localName.equals("integer") || localName.equals("date")) isValue = false;
    }

    /**
     * Evenement recu a chaque fois que l'analyseur rencontre des caracteres (entre
     * deux balises).
     * @param ch les caracteres proprement dits.
     * @param start le rang du premier caractere a traiter effectivement.
     * @param end le rang du dernier caractere a traiter effectivement
     * @see org.xml.sax.ContentHandler#characters(char[], int, int)
     */
    public void characters(char[] ch, int start, int end) throws SAXException {
            //System.out.println("#PCDATA : " + new String(ch, start, end));
    		String s = new String(ch, start, end);
    		if(dictLvl == 2)
    		{
    			//creation du track courant
    			if(artist == null)
    			{
    				artist = new Artist("Aucun");
    			}
    			if(track == null)
    			{
    				track = new Track("Aucun");
    			}
    			track.setArtist(artist);
    			
    			if(genre == null)
    			{
    				genre = new Genre("Aucun");
    			}
    			if(kind == null)
    			{
    				kind = new Kind("Aucun");
    			}
    			
    			if(album == null)
    			{
    				album = new Album("Aucun");
    			}
    			
    			if(trackNumber == null)
    			{
    				trackNumber = new TrackNumber(-1);
    			}
    			trackNumber.setAlbum(album);
    			
    			if(dateModified == null)
    			{
    				dateModified = new DateVizu(-1);
    			}
    			if(dateAdded == null)
    			{
    				dateAdded = new DateVizu(-1);
    			}
    			if(playDateUTC == null)
    			{
    				playDateUTC = new DateVizu(-1);
    			}
    			
    			UserTrack uT = new UserTrack(track,
    										 genre,
    										 kind,
    										 size,
    										 totalTime,
    										 trackNumber,
    										 //dateModified,
    										 //dateAdded,
    										 bitRate,
    										 sampleRate
    										 //playCount,
    										 //playDateUTC,
    										 //rating,
    										 //albumRating,
    										 //location,
    										 //currentUser
    										 );
    			UserTrack oldUT = uT;
    			
    			//on fusionne le track avec les tracks deja existants
    			//ce qui efface les doublons et laisse les instances qui n'existaient pas encore
    			Iterator<UserTrack> it = uniqueTracks.iterator();
    			UserTrack itUserTrack;
    			while(it.hasNext())
    			{
    				itUserTrack = it.next();
    				uT = itUserTrack.merge(uT);
    			}
    			
    			//si la reference est la meme, alors le UserTrack est nouveau et doit etre ajoute a la liste
    			if(oldUT == uT)
    			{
    				//on ajoute le ut au user
    				currentUser.addUserTrack(uT);
    				//et le user au ut
    				uT.setUserInfos(dateModified, dateAdded, playCount, playDateUTC, location, currentUser);
    				uT.setRating(currentUser, rating);
    				//on met a jour les listes de reference qui pointent vers cet objet
        			uT.updateBackReferences(currentUser);
        			uT.getAlbum().setRating(currentUser, albumRating);
        			//on ajoute le ut a la liste
    				uniqueTracks.add(uT);
    			}
    			
    			//preparation du track suivant
    			artist = null; //artiste qui a compose le morceau
    			track = null; //morceau
    			genre = null; //genre
    			kind = null; //type de format de fichier
    			size = -1; //taille du morceau en Bits
    			totalTime = -1; //temps total du morceau
    			album = null; //nom de l'album dans lequl est contenu ce numero de morceau
    			trackNumber = null; //numero du morceau de l'album
    			dateModified = null; //date de modification du fichier
    			dateAdded = null; //date d'ajout du fichier
    			bitRate = -1; //birate de l'encodage
    			sampleRate = -1; //sampleRate du morceau
    			playCount = -1; //nombre de fois que le morceau a ete ecoute
    			playDateUTC = null; //derniere ecoute
    			rating = -1; //rating du morceau de 0 a 100
    			albumRating = -1; //rating de l'album de 0 a 100
    			location = null; //chemin absolu vers le fichier
    		}
    		if(dictLvl == 3)
    		{
    			if(isKey) key = s;
    			if(isValue)
    			{
        			if(key.equals("Artist")) artist = new Artist(StrToNormalizedStr(s));
    				else if(key.equals("Name")) track = new Track(StrToNormalizedStr(s));
    				else if(key.equals("Genre")) genre = new Genre(StrToNormalizedStr(s));
    				else if(key.equals("Kind")) kind = new Kind(StrToNormalizedStr(s));
    				else if(key.equals("Size")) size = StrToInt(s);
    				else if(key.equals("Total Time")) totalTime = StrToInt(s);
    				else if(key.equals("Album")) album = new Album(StrToNormalizedStr(s));
    				else if(key.equals("Track Number")) trackNumber = new TrackNumber(StrToInt(s));
    				else if(key.equals("Date Modified")) dateModified = StrToDate(s);
    				else if(key.equals("Date Added")) dateAdded = StrToDate(s);
    				else if(key.equals("Bit Rate")) bitRate = StrToInt(s);
    				else if(key.equals("Sample Rate")) sampleRate = StrToInt(s);
    				else if(key.equals("Play Count")) playCount = StrToInt(s);
    				else if(key.equals("Play Date UTC")) playDateUTC = StrToDate(s);
    				else if(key.equals("Rating")) rating = StrToInt(s);
    				else if(key.equals("Album Rating")) albumRating = StrToInt(s);
    				else if(key.equals("Location")) location = s;
    			}
    		}
    		
    		
    }

    private int StrToInt(String s)
    {
    	return Integer.parseInt(s);
    }
    
    private DateVizu StrToDate(String s)
    {
    	try {
			return new DateVizu(s);
		} catch (ParseException e) {
			return null;
		}
    }

    private String StrToNormalizedStr(String s)
    {
    	return s;
    }
    /**
     * Recu chaque fois que des caracteres d'espacement peuvent etre ignores au sens de
     * XML. C'est a dire que cet evenement est envoye pour plusieurs espaces se succedant,
     * les tabulations, et les retours chariot se succedants ainsi que toute combinaison de ces
     * trois types d'occurrence.
     * @param ch les caracteres proprement dits.
     * @param start le rang du premier caractere a traiter effectivement.
     * @param end le rang du dernier caractere a traiter effectivement
     * @see org.xml.sax.ContentHandler#ignorableWhitespace(char[], int, int)
     */
    public void ignorableWhitespace(char[] ch, int start, int end) throws SAXException {
            //System.out.println("espaces inutiles rencontres : ..." + new String(ch, start, end) +  "...");
    }

    /**
     * Rencontre une instruction de fonctionnement.
     * @param target la cible de l'instruction de fonctionnement.
     * @param data les valeurs associees a cette cible. En general, elle se presente sous la forme 
     * d'une serie de paires nom/valeur.
     * @see org.xml.sax.ContentHandler#processingInstruction(java.lang.String, java.lang.String)
     */
    public void processingInstruction(String target, String data) throws SAXException {
            System.out.println("Instruction de fonctionnement : " + target);
            System.out.println("  dont les arguments sont : " + data);
    }

    /**
     * Recu a chaque fois qu'une balise est evitee dans le traitement a cause d'un
     * probleme non bloque par le parser. Pour ma part je ne pense pas que vous
     * en ayez besoin dans vos traitements.
     * @see org.xml.sax.ContentHandler#skippedEntity(java.lang.String)
     */
    public void skippedEntity(String arg0) throws SAXException {
            // Je ne fais rien, ce qui se passe n'est pas franchement normal.
            // Pour eviter cet evenement, le mieux est quand meme de specifier une dtd pour vos
            // documents xml et de les faire valider par votre parser.              
    }

    private Locator locator;

}
