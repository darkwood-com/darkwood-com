package visu;

import java.awt.Color;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class VisuTrack extends JFrame {
	public JPanel panelGeneral = new JPanel();
	public JLabel intitule = new JLabel("Liste des morceaux :");
	
	public VisuTrack(ArrayList<UserTrack> arrayUserTrack) {
		// On affiche tout en ligne :
		BoxLayout boxPourPanelGeneral = new BoxLayout(panelGeneral,BoxLayout.Y_AXIS);
		panelGeneral.setLayout(boxPourPanelGeneral);
		
		// Affichage des morceaux :
		panelGeneral.add(intitule);  panelGeneral.add(new JLabel("-----------"));	
		
		Iterator itUT = arrayUserTrack.iterator();
		while( itUT.hasNext() ) {
			UserTrack userTrackTemp = (UserTrack)itUT.next();
			afficherTrack(userTrackTemp);
		}
		
		// Configuration g�n�rale :
		add(panelGeneral);
		setTitle("Visionnage des morceaux");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); 
		pack();
        setVisible(true);
	}
	
	// M�thode pour afficher un UserTrack :
	public void afficherTrack(UserTrack userTrack) {
		JPanel panelTrack1 = new JPanel();
		JLabel track1 = new JLabel("Track :" + userTrack.getName()),
			   artiste1 = new JLabel("Artiste :" + userTrack.getArtiste()),
			   genre1 = new JLabel("Genre :" + userTrack.getGenre()),
			   kind1 = new JLabel("Kind :" + userTrack.getKind());
		JLabel espace1 = new JLabel("-----------");
		
		BoxLayout boxPourPanelTrack1 = new BoxLayout(panelTrack1,BoxLayout.Y_AXIS);
		panelTrack1.setLayout(boxPourPanelTrack1);
		panelTrack1.add(track1);  panelTrack1.add(artiste1);  panelTrack1.add(genre1);  panelTrack1.add(kind1);
		panelTrack1.add(espace1);
		
		// Pour modifier la couleur de fond :
		//panelTrack1.setBackground(Color.black);
		
		panelGeneral.add(panelTrack1);
	}
	
	public static void main(String[] args) {
		// Donn�es : /!\ ne marche pas car trop ancien /!\
		Track track1 = new Track("Rapper's Delight (1980)");
		Artist artiste1 = new Artist("The Sugarhill Gang");
		track1.setArtist(artiste1);
		Genre genre1 = new Genre("Rap");
		Kind kind1 = new Kind("Fichier audio MPEG");
		UserTrack userTrack1 = new UserTrack(track1,genre1,kind1,7299353,456071,null, 128,44100);
		
		Track track2 = new Track("House of the Rising Sun");
		Artist artiste2 = new Artist("Animals");
		track2.setArtist(artiste2);
		Genre genre2 = new Genre("Rock");
		Kind kind2 = new Kind("Fichier audio MPEG");
		UserTrack userTrack2 = new UserTrack(track2,genre2,kind2,4096,271098,null, 128,44100);
		
		Track track3 = new Track("Mambo no 5");
		Artist artiste3 = new Artist("Lou bega");
		track3.setArtist(artiste3);
		Genre genre3 = new Genre("Pop");
		Kind kind3 = new Kind("Fichier audio MPEG");
		UserTrack userTrack3 = new UserTrack(track3,genre3,kind3,3585695,223973,null, 128,44100);
		
		ArrayList<UserTrack> arrayUserTrack = new ArrayList<UserTrack>();
		arrayUserTrack.add(userTrack1);  arrayUserTrack.add(userTrack2);  arrayUserTrack.add(userTrack3);
		
		// Affichage des UserTracks :
		VisuTrack visuT = new VisuTrack(arrayUserTrack);
	}
	
}