/**
 * 
 */
package Tablut;

import Partie.Partie;

/**
 * @author math
 *
 */
public class JoueurProjetIA implements IJoueur {
	Partie partie;
	
	/* (non-Javadoc)
	 * @see Tablut.IJoueur#initJoueur(int)
	 */
	public void initJoueur(int mycolour) {
		partie = new Partie();
		partie.jouerPartieReseau(mycolour-1);
	}

	/* (non-Javadoc)
	 * @see Tablut.IJoueur#choixMouvement()
	 */
	public String choixMouvement() {
		return partie.jouerCoupReseau();
	}

	/* (non-Javadoc)
	 * @see Tablut.IJoueur#declareLeVainqueur(int)
	 */
	public void declareLeVainqueur(int colour) {
		partie.finPartie(colour-1);
	}

	/* (non-Javadoc)
	 * @see Tablut.IJoueur#mouvementEnnemi(int, int, int, int)
	 */
	public void mouvementEnnemi(int startRow, int startCol, int finishRow, int finishCol) {
		partie.recevoirCoupReseau(startRow, startCol, finishRow, finishCol);
	}

	/* (non-Javadoc)
	 * @see Tablut.IJoueur#quadriName()
	 */
	public String quadriName() {
		return "MRJM";
	}

}
