package Tablut;

import java.net.*;
import java.io.*;
import java.util.Date;

public class ServeurJeu {
	
	public static boolean listening = true;
	
	public static boolean appletGraphique = true;
	
	public static void main(String[] args) throws IOException {
		ServerSocket serverSocket = null;
		Date startDate = new Date();
		System.out.println("Serveur Demarre le " + startDate);
		
		if(args.length < 1) {
				System.err.println("Usage : ServeurJeu PortNumber [1|0] [FILEOUT]");
				System.err.println("[1|0] 1 si vous voulez une applet graphique (ou non)");
				System.err.println("[FILEOUT] est un nom de fichier de sortie du jeu (a finir)");
				System.exit(1);
		}

		int portNum = Integer.parseInt(args[0]);
		
		// On configure pour l'applet permettant de visualiser le match...
		if (args.length>1) {
			int intapplet = (appletGraphique?1:0);
			try {
			  intapplet = Integer.parseInt(args[1]);
			} catch (NumberFormatException e) {
				System.err.println("[ARBITRE] Erreur dans le second argument (" + args[1] + ")");
				System.exit(1);
			}
		    if ( (intapplet != 0) && (intapplet != 1) ) {
				System.err.println("[ARBITRE] Erreur de format (0 ou 1) dans le second argument (" + args[1] + ")");
				System.exit(1);
		    }
		    appletGraphique = (intapplet == 1);
			System.out.println("[ARBITRE] Applet Graphique configuree a " + appletGraphique);
		}

		// On configure un printstream supplementaire, eventuellement....
		PrintStream streamOut = null;
		if (args.length>2) {
			String fileoutname = args[2];
			System.out.println("[ARBITRE] Sortie des mouvements dans le fichier " + fileoutname);
			try {
				streamOut = new PrintStream("fileoutname");
			} catch (Exception e) {
				System.err.println("[WARINING] Exception " + e + " sur l'ouverture de " + fileoutname);
				streamOut = null;
			}
		}
		
		// Ouverture de la socket pour ecouter....
		try {
			serverSocket = new ServerSocket(portNum);
		} catch (IOException e) {
			System.err.println("[ERREUR] Le serveur ne peut pas ecouter le port " + portNum);
			System.exit(1);
		}
		// On attend que 30 secondes pour les deux clients...
		serverSocket.setSoTimeout(30*1000);
		
		try{
		while (listening) {
			System.out.println("[INFO] Serveur OK. Ecoute sur le port "+ portNum);
			System.out.println("[INFO] Le serveur attend les deux joueurs pour commencer.");
			Socket client1 = serverSocket.accept();
			// recuperation de l'identifiant du premier joueur
			String s1 = (new BufferedReader(new InputStreamReader(client1.getInputStream()))).readLine();
			System.out.println("[ARBITRE] JOUEUR 1 " + s1 + " OK\n[INFO] Le serveur attend le second joueur");
			Socket client2 = serverSocket.accept();
			String s2 = (new BufferedReader(new InputStreamReader(client2.getInputStream()))).readLine();
			System.out.println("[ARBITRE] JOUEUR 2 " + s2 + " OK\n[INFO] Les deux joueurs sont prets. Le serveur lance la partie!");
			ServeurJeuThread newGameThread = new ServeurJeuThread(client1, client2, streamOut, appletGraphique);
			newGameThread.start();
			listening = false;
			newGameThread = null;
		}	
		} catch (SocketTimeoutException e) {
			System.err.println("[ARBITRE] SOCKETTIMEOUT : attente 30 secondes pour les deux clients en vain.");
			System.exit(1);
		}
		

		serverSocket.close();
	}
}
