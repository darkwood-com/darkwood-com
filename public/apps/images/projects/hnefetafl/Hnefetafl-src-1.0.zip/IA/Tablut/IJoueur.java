package Tablut;

/**
 * Voici l'interface abstraite qu'il suffit d'implanter pour jouer.
 * Ensuite, vous devez utiliser ClientJeu en lui donnant le nom de votre classe
 * pour qu'il la charge et se connecte au serveur.
 * 
 * Vous pouvez utiliser le RandomPlayer pour tester.
 * 
 * @author L. Simon (Univ. Paris-Sud)- 2006
 *
 */

public interface IJoueur {
	
	static final int TAILLE = 9; // Taille du plateau. Pas la peine de la changer !
	static final int NOIR = 2;   // Vous pouvez changer cela en interne si vous le souhaitez
	static final int BLANC = 1;  // Mais pas lors de la conversation avec l'arbitre
	
	/**
	 * L'arbitre vient de lancer votre joueur. Il lui informe par cette methode
	 * que vous devez jouer dans cette couleur. Vous pouvez utiliser cette methode
	 * abstraite, ou la methode constructeur de votre classe, pour initialiser
	 * vos structures.
	 * @param mycolour La couleur dans laquelle vous allez jouer (1=BLANC, 2=NOIR)
	 */
	public void initJoueur(int mycolour);

	/**
	 * C'est ici que vous devez faire appel a votre IA pour trouver le meilleur coup a jouer
	 * sur le plateau courant.
	 * 
	 * @return une chaine decrivant le mouvement. Cette chaine doit etre decrite exactement comme sur l'exemple :
	 * String msg = "" + lignePiece + " " + colonnePiece + " " + ligneDestination + " " + colonneDestination + '\0';
	 * System.out.println("Voici mon mouvement : " + msg);
	 */
	public String choixMouvement();	

	
	/**
	 * Methode appelee par l'arbitre pour designer le vainqueur. Vous pouvez en profiter pour
	 * imprimer une banniere de joie... Si vous gagnez... 
	 * 
	 * @param colour La couleur du gagnant (BLANC=1, NOIR=2).
	 */
	public void declareLeVainqueur(int colour);
	
	
	/**
	 * On suppose que l'arbitre a verifie que le mouvement ennemi etait bien legal. Il vous informe
	 * la du mouvement ennemi. A vous de repercuter ce mouvement dans vos structures. Comme
	 * par exemple eliminer les pions que ennemi vient de vous prendre par ce mouvement.
	 * Il n'est pas necessaire de reflechir deja a votre prochain coup a jouer : pour cela
	 * l'arbitre appelera ensuite choixMouvement().
	 * 
	 * @param startRow Ligne de depart du mouvement (entre 0 et TAILLE-1), 
	 *                 commencant en haut=0 a bas=(TAILLE-1)
	 * @param startCol Colonne de depart du mouvement (entre 0 et TAILLE-1), 
	 *                 commencant a gauche=0 a droite=(TAILLE-1)
	 * @param finishRow Ligne d'arrivee du mouvement (entre 0 et TAILLE-1),
	 *                  commencant en haut=0 a bas=(TAILLE-1)
	 * @param finishCol Colonne d'arrivee du mouvement (entre 0 et TAILLE-1),
	 * 	                commencant a gauche=0 a droite=(TAILLE-1)
	 */
	public void mouvementEnnemi(int startRow, int startCol, int finishRow, int finishCol);

	/**
	 * @return Le nom de votre quadrinome
	 */
	public String quadriName();

	
}


