package Jeu;

public class CaseNormale extends Case {

	public CaseNormale(int i, int j) {
		super(i, j);
	}

	/**
	 * afficher la case N (Case Normale)
	 * @param seePion booleen qui indique si on veut afficher le pion par dessu la case
	 */
	public void afficherCase(boolean seePion){
		if(seePion && monPion != null) afficherPionCase();
		else System.out.print("N");
	}
	
	/**
	 * indique le type de la case : "Mur" ou "Normale" ou "Sortie" ou "Trone"
	 * @return retourne le type de la case "Normale"
	 */
	public String getTypeCase(){
		return "Normale";
	}
}
