package Jeu;

public class Plateau {
	
	final public int nbCases = 9; //9 cases du plateau
	final public int nbCasesTotal = nbCases + 2; //9 cases + 2 pour les cases mur
	private Case[][] cases; //Les cases du tableau sont rangees par coordonnees
	
	/**
	 * on initialise le plateau
	 *
	 */
	Plateau()
	{
		int i, j;
		cases = new Case[nbCasesTotal][nbCasesTotal];
		for(i = 0; i<nbCasesTotal; i++)
		{
			for(j = 0; j<nbCasesTotal; j++)
			{
				if(i == 0 || j == 0 || i == (nbCasesTotal - 1) || j == (nbCasesTotal - 1) ||
                  (i == 1 && j == 1) || (i == 9 && j == 1) || (i == 1 && j == 9) || (i == 9 && j == 9))
				{
					cases[i][j] = new CaseMur(i,j);
				}
				else if(i == 5 && j == 5)
				{
					cases[i][j] = new CaseTrone(i,j);
				}
				else if((i == 4 && j == 1) || (i == 5 && j == 1) || (i == 6 && j == 1) ||
						(i == 4 && j == 9) || (i == 5 && j == 9) || (i == 6 && j == 9) ||
						(i == 1 && j == 4) || (i == 1 && j == 5) || (i == 1 && j == 6) ||
						(i == 9 && j == 4) || (i == 9 && j == 5) || (i == 9 && j == 6))
				{
					cases[i][j] = new CaseSortie(i,j);
				}
				else
				{
					cases[i][j] = new CaseNormale(i,j);
				}
			}
		}
	}
	
	/**
	 * on recupere la case a la coordonnee (i,j)
	 * @param i coordonnee x de la case
	 * @param j coordonnee y de la case
	 * @return retourne la case de coordonnee (i,j)
	 */
	public Case getCase(int i, int j){
		return cases[i][j];
	}

	/**
	 * affiche le plateau en ligne de commande selon plusieurs niveau :<br>
	 * i = 0 > affiche le plateau de taille 9x9 avec les pions<br>
	 * i = 1 > affiche le plateau de taille 9x9 avec les pions et leur dMax respectif.<br>
	 * i = 2 > affiche le plateau de taille 11x11 sans les pions et les caracteristiques des cases<br>
	 * i = 3 > affiche le plateau de taille 11x11 avec les pions et les caracteristiques des cases<br>
	 * i = 4 > affiche le plateau de taille 9x9 avec les pions et les coordonnee des cases<br>
	 * @param n niveau d'affichage du plateau a afficher
	 */
	public void afficherPlateau(int n) {
		int i,j;
		switch(n)
		{
		case 4:
			for(j=0; j<=nbCases+1; j++)
			{
				System.out.print(j%10);
			}
			System.out.println();
			for(j=1; j<=nbCases; j++)
			{
				for(i=0; i<=nbCases+1; i++)
				{
					if(i%10 == 0) System.out.print(j);
					else cases[i][j].afficherPionCase();
				}
				System.out.println();
			}
			
			for(j=0; j<=nbCases+1; j++)
			{
				System.out.print(j%10);
			}
			System.out.println();
			break;
		case 3:
			for(j=0; j<nbCasesTotal; j++)
			{
				for(i=0; i<nbCasesTotal; i++)
				{
					cases[i][j].afficherCase(true);
				}
				System.out.println();
			}
			break;
		case 2:
			for(j=0; j<nbCasesTotal; j++)
			{
				for(i=0; i<nbCasesTotal; i++)
				{
					cases[i][j].afficherCase(false);
				}
				System.out.println();
			}
			break;
		case 1:
			for(j=1; j<=nbCases; j++)
			{
				for(i=1; i<=nbCases; i++)
				{
					System.out.print(" ");
					cases[i][j].afficherPionCase(0);
					System.out.print(" ");
				}
				System.out.println();
				for(i=1; i<=nbCases; i++)
				{
					cases[i][j].afficherPionCase(3);
					cases[i][j].afficherPionCase();
					cases[i][j].afficherPionCase(1);
				}
				System.out.println();
				for(i=1; i<=nbCases; i++)
				{
					System.out.print(" ");
					cases[i][j].afficherPionCase(2);
					System.out.print(" ");
				}
				System.out.println();
			}
			break;
		case 0:
		default:
			for(j=1; j<=nbCases; j++)
			{
				for(i=1; i<=nbCases; i++)
				{
					cases[i][j].afficherPionCase();
				}
				System.out.println();
			}
			break;
		}
	}
}
