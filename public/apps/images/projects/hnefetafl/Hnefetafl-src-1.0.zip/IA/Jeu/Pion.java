package Jeu;

public class Pion {
	/**
	 * dMax[i] >= 0
	 * dMax[0] = distance maximum vers le haut
	 * dMax[1] = distance maximum vers la droite
	 * dMax[2] = distance maximum vers le bas
	 * dMax[3] = distance maximum vers la gauche
	 */
	
	int[] dMax;
	Case maCase; //le pion est sur une case du plateau (ne peut pas �tre une CaseMur)
	Joueur monJoueur; //le pion appartien a quel joueur
	
	Case caseMorte; //case sur laquelle va le pion lorsqu'il est tue
	
	/**
	 * On cree un nouveau pion sur le plateau p aux coordonnee (x,y). Le pion ajuste automatiquement ses distances maximum (dMax)
	 * @param x coordonnee x du pion
	 * @param y coordonnee y du pion
	 * @param p plateau p sur lequel va etre pose le pion
	 * @param j le pion appartient au joueur j
	 */
	public Pion(int x, int y, Plateau p, Joueur j) {
		dMax = new int[4];
		
		//on dit que le joueur j possede ce pion
		monJoueur = j;
		
		//on dit a la case de coordonnee (x,y) qu'elle recoit ce pion
		p.getCase(x,y).setPion(this);
		
		//le pion definit ses distances maximum qu'il peut prendre
		for(int i=0; i<4; i++)
		{
			dMax[i] = calculDistanceMax(i, maCase.getCase(i,1,p), p, 0);
		}
		
		caseMorte = new CaseMorte(1,1);
	}
	
	/**
	 * calcul recursif de la distance maximal (dMax[i]) que peut atteindre le pion sur le plateau p depuis la case c.<br>
	 * - Si c'est un mur, alors on retourne le nombre nb<br>
	 * - Si c'est un pion p2, alors on commence par modifier la nouvelle distance maximal du pion p2 et on retourne nb.
	 * - Sinon on applique la recursivite sur la case suivante selon la direction i
	 * @param i indice de la distance consernee : i=0 > haut, i=1 > droite, i=2 > bas, i=3 > gauche 
	 * @param c case sur laquelle on se situe
	 * @param p plateau sur lequel on va examiner la distance
	 * @param nb nombre de cases parcourues
	 * @return retourne le nombre maximal (dMax[i]) de cases que peut parcourir le pion
	 */
	private int calculDistanceMax(int i, Case c, Plateau p, int nb) {
		Pion pionCase = c.getPion();
		
		//si on a parcouru les cases et on est arrive a un pion
		if(pionCase != null)
		{
			//on commence par modifier la distance maximal du pion
			pionCase.setDMax(getIndiceDMaxOpose(i), nb);
			//on retourne alors la valeur maximal jusqu'a ce pion
			return nb;
		}
		
		//si on a parcouru toutes les cases et on est arrive a un mur
		if(c.getTypeCase().equals("Mur")) return nb;
		
		//on applique la recursivite sur la case suivante
		Case caseSuivante = c.getCase(i,1,p);
		return calculDistanceMax(i, caseSuivante, p, nb + 1);
	}

	/**
	 * on definit la distance maximale du pion p selon la direction i
	 * @param i direction de la distance maximale (haut, droite, bas, gauche)
	 * @param max nouvelle valeur maximale que l'on va definir
	 */
	private void setDMax(int i, int max) {
		dMax[i] = max;
	}
	
	/**
	 * On indique le dMax[i] du pion
	 * @param i indice du dMax[i]
	 * @return on retourne le dMax[i] du pion
	 */
	public int getDMax(int i) {
		return dMax[i];
	}

	/**
	 * on retourne l'indice j qui sera le cote oppose au cote du pion d'indice i
	 * @param i indice du cote du pion dont on veut avoir l'oppose
	 * @return on retourne l'indice j qui sera le cote oppose au cote du pion d'indice i
	 */
	private int getIndiceDMaxOpose(int i) {
		return (i+2)%4;
	}
	
	/**
	 * on retourne l'indice j qui sera le cote de droite au cote du pion d'indice i
	 * @param i indice du cote du pion dont on veut avoir le cote de droite
	 * @return on retourne l'indice j qui sera le cote de droite au cote du pion d'indice i
	 */
	private int getIndiceDMaxDroite(int i) {
		return (i+1)%4;
	}
	
	/**
	 * on retourne l'indice j qui sera le cote de gauche au cote du pion d'indice i
	 * @param i indice du cote du pion dont on veut avoir le cote de gauche
	 * @return on retourne l'indice j qui sera le cote de gauche au cote du pion d'indice i
	 */
	private int getIndiceDMaxGauche(int i) {
		return (i+3)%4;
	}
	
	/**
	 * on recupere la case sur laquelle est le pion
	 * @return on recupere la case sur laquelle est le pion
	 */
	public Case getCase() {
		return maCase;
	}
	
	/**
	 * on dit au pion qu'il est maintenant sur la case c
	 * @param c c est la case sur laquelle le pion se situe
	 */
	public void setCase(Case c) {
		maCase = c;
	}
	
	/**
	 * precondition : le pion est sur une case<br>
	 * @return on retourne la coordonnee x de la case sur laquelle est posee le pion
	 */
	public int getX(){
		return maCase.getX();
	}
	
	/**
	 * precondition : le pion est sur une case<br>
	 * @return on retourne la coordonnee y de la case sur laquelle est posee le pion
	 */
	public int getY(){
		return maCase.getY();
	}
	
	/**
	 * retourne le type de la piece
	 * @return retourne "Pion"
	 */
	public String getTypePion(){
		return "Pion";
	}
	
	/**
	 * on regarde si le pion est bloque ou pas (s'il peut encore bouger), c'est a dire si la somme des dMax[i] est nulle ou pas
	 * @return on dit si le pion est bloque ou pas
	 */
	public boolean estBloque(){
		int sommeDMax = dMax[0] + dMax[1] + dMax[2] + dMax[3];
		
		if(sommeDMax == 0)  return true;
		else 				return false;
	}
	
	/**
	 * on regarde si le pion est mort ou pas (il est sur une case morte)
	 * @return on dit si le pion est mort ou pas
	 */
	public boolean estMort(){
		if(maCase.getTypeCase().equals("Morte")) return true;
		else return false;
	}

	/**
	 * on regarde si le pion est capture ou pas sur le plateau p
	 * @return on dit si le pion est capture ou pas
	 */
	public boolean estCapture(Plateau p){
		//on regarde si le pion est entoure par deux pions
		if((dMax[0] + dMax[2]) == 0)
		{
			//on regarde si les pions verticaux sont ennemis
			if((getStatut(0,1,p) == 2) && (getStatut(2,1,p) == 2)) return true;
		}
		
		if((dMax[1] + dMax[3]) == 0)
		{
			//on regarde si les pions horizontaux sont ennemis
			if((getStatut(1,1,p) == 2) && (getStatut(3,1,p) == 2)) return true;
		}
		
		return false;
	}
	
	/**
	 * on regarde si le pion potentiel qui se situe dans la direction dir est un ami = 0, neutre = 1, ennemi = 2<br>
	 * si c'est juste la case trone qui fait office de pion distant, on peut considrer que c'est un ami<br>
	 * si c'est un case vide, c'est une case neutre
	 * @param dir direction dans laquelle on veut connaitre le pion distant
	 * @return on dit si le pion potentiel est un ami = 0, neutre = 1, ennemi = 2
	 */
	public int getStatut(int dir, int pas, Plateau p){
		Case caseDistante = maCase.getCase(dir, pas, p);
		
		//si la case est le trone, c'est un ami (pour n'importe qui)
		if(caseDistante.getTypeCase().equals("Trone")) return 0;
		
		//si il n'y a pas de pion, c'est une case neutre
		if(caseDistante.getPion() == null) return 1;
		else
		{
			String couleurPionDistant = caseDistante.getPion().monJoueur.getCouleur();
			//on compare les couleurs des deux pions
			if(couleurPionDistant.equals(monJoueur.getCouleur())) return 0;
			else return 2;
		}
	}
	
	/**
	 * affiche la couleur du pion sous forme de chaine de caractere
	 */
	public String afficherPion()
	{
		if(monJoueur.getCouleur().equals("Blanc")) 	return "O";
		else 										return "X";
	}

	/**
	 * preconditions :<br>
	 * - deplacement > 0 (si une piece est deplacee, on la bouge forcement)<br>
	 * - direction : 0 = haut, 1 = droite, 2 = bas, 3 = gauche<br>
	 * - p = Le pion que le joueur qui possede le pion veut deplacer<br>
	 * - le deplacement du pion doit etre valide : il doit respecter les limites fixees par les variables dMax du pion<br>
	 * <br>
	 * postconditions :<br>
	 * - Le pion p avance a la case voulue<br>
	 * - L'ancienne case se voit attribuer 0 pions et la nouvelle case contient le pion p<br>
	 * - les parametres dMax du pion p changent<br>
	 * - On change les parametres dMax des quatres pions potentiels qui seraient situes en haut, a droite, en bas, en haut de l'ancienne position du pion p<br>
	 * - On change les parametres dMax des quatres pions potentiels qui seraient situes en haut, a droite, en bas, en haut de la nouvelle position du pion p<br>
	 * 
	 * @param dir (0 = haut, 1 = droite, 2 = bas, 3 = gauche) : la direction dans laquelle le jeu veut deplacer le pion
	 * @param pas deplacement (> 0) qui est le nombre de cases pour lequel le joueur va deplacer son pion
	 * @param p plateau sur lequel on va deplacer le pion p
	 */
	public void deplacerPion(int dir, int pas, Plateau p) {
		//on change les dMax des pions potentiels qui se situent perpendiculairement a la direction du deplacement du pion
		int toDir;
		
		toDir = getIndiceDMaxDroite(dir);
		updateDMaxPionDistant(toDir, getDMax(getIndiceDMaxOpose(toDir)) + 1, p);
		toDir = getIndiceDMaxGauche(dir);
		updateDMaxPionDistant(toDir, getDMax(getIndiceDMaxOpose(toDir)) + 1, p);
		
		//on change les dMax des pions potentiels qui se situent dans direction du deplacement du pion
		toDir = dir;
		updateDMaxPionDistant(toDir, -pas, p);
		toDir = getIndiceDMaxOpose(dir);
		updateDMaxPionDistant(toDir, pas, p);
		
		//on dit au pion de se deplacer de case
		translatePion(dir, pas, p);
		
		//on change les dMax du pion dans la direction dir
		toDir = dir;
		updateDMaxPion(toDir, -pas);
		toDir = getIndiceDMaxOpose(dir);
		updateDMaxPion(toDir, pas);
		
		//on cherche et met a jour les dMax du pion et du pion distant qui sont selon la direction perpendiculaire au deplacement du pion
		toDir = getIndiceDMaxDroite(dir);
		setDMax(toDir, calculDistanceMax(toDir, maCase.getCase(toDir,1,p), p, 0));
		toDir = getIndiceDMaxGauche(dir);
		setDMax(toDir, calculDistanceMax(toDir, maCase.getCase(toDir,1,p), p, 0));
	}
	
	/**
	 * on fait varier dMax[dir] de deltaMax
	 * @param dir direction que l'on va faire varier
	 * @param deltaMax valeur de la variation
	 */
	private void updateDMaxPion(int dir, int deltaMax) {
		setDMax(dir, getDMax(dir) + deltaMax);
	}

	/**
	 * on met a jour la valeur dMax du pion potentiel qui se trouve dans la direction dir
	 * @param dir direction vers laquelle on veut mettre a jour la valeur du pion
	 * @param max nouvelle valeur que l'on va mettre sur le pion dans la direction dir
	 * @param p plateau sur lequel on va deplacer le pion p
	 */
	private void updateDMaxPionDistant(int dir, int delatMax, Plateau p) {
		//on recupere l'instance du pion
		Pion pionDistant = maCase.getCase(dir,dMax[dir]+1,p).getPion();
		
		//on regarde si il y a un pion a cette case, sinon on ne change rien
		if(pionDistant != null)
		{
			//on calcul la variation de la valeur maximale du pion distant selon la direction opposee
			int newMax = pionDistant.getDMax(getIndiceDMaxOpose(dir)) + delatMax;
			//on defini la nouvelle valeur maximal au pion distant dans la direction opposee
			pionDistant.setDMax(getIndiceDMaxOpose(dir), newMax);
		}
	}

	/**
	 * preconditions :<br>
	 * - il n'y a pas deja un pion sur la case ou on veut le deplacer<br>
	 * - le deplacement doit etre possible<br>
	 * postconditions :<br>
	 * - on dit au pion de se deplacer de case dans la direction dir et d'un deplacement de pas<br>
	 * @param dir direction : 0 = haut, 1 = droite, 2 = bas, 3 = gauche
	 * @param pas deplacement (> 0) qui est le nombre de cases pour lequel le joueur va deplacer son pion
	 * @param p plateau sur lequel on va deplacer le pion p
	 */
	private void translatePion(int dir, int pas, Plateau p) {
		//on cherche la nouvelle case
		Case newCase = maCase.getCase(dir,pas,p);
		//on dit a l'ancienne case qu'elle n'a plus de pion
		maCase.removePion();
		//on dit a la nouvelle case qu'elle a maintenant ce pion
		newCase.setPion(this);
	}
	
	/**
	 * le pion capture les pions qui sont dans sa direction si c'est possible (devant, a droite, a gauche)
	 * @param dir direction vers laquelle le pion capture
	 * @param p plateau sur lequel on va capturer les pions
	 * @return on retourne le tableau de pion qui a ete potentiellement tue
	 */
	public Pion[] capturerPions(int dir, Plateau p) {
		//indique quels ont ete les pions tues par ce pion lors d'un deplacement (au maximum 3 pions)
		Pion[] pionsTues = new Pion[3];
		
		capturerPion(dir,p,0,pionsTues); //on regarde si il y a une capture dans la direction
		capturerPion(getIndiceDMaxDroite(dir),p,1,pionsTues); //on regarde si il y a une capture a droite
		capturerPion(getIndiceDMaxGauche(dir),p,2,pionsTues); //on regarde si il y a une capture a gauche
		
		return pionsTues;
	}
	
	/**
	 * le pion capture le pion potentiel qui est dans la direction dir
	 * @param dir direction vers laquelle le pion capture
	 * @param p plateau sur lequel on va capturer les pions
	 * @param posPionTue indique la position du pion qui est tue dans le tableau pionsTues
	 */
	private void capturerPion(int dir, Plateau p, int posPionTue, Pion[] pionsTues) {
		pionsTues[posPionTue] = null;
		
		//on regarde si le pion potentiel distant est a cote
		if(getDMax(dir) == 0)
		{
			if(getStatut(dir,1,p) == 2) //si le pion a cote est un ennemi
			{
				//on regarde si deux cases plus loin, on a une case amie
				if(getStatut(dir,2,p) == 0)
				{
					//on recupere la case et on regarde si c'est un pion ou un roi
					Pion pionDistant = maCase.getCase(dir, 1, p).getPion();
					if(pionDistant != null)
					{
						if(pionDistant.getTypePion().equals("Pion"))
						{
							//on sauvegarde le pion qui a ete tue dans le tableau
							pionsTues[posPionTue] = pionDistant;
							
							//ici : le pionDistant est un pion enemi qui est capture, maintenant on le kill
							pionDistant.tuerPion(p);
						}
						//si le pion etait le roi, les conditions de victoire sur le roi se font a chaque tour
					}
				}
			}
		}
	}

	/**
	 * On tue, on retire le pion du plateau
	 * @param p plateau sur lequel on va tuer le pion
	 */
	private void tuerPion(Plateau p) {
		int x, y;
		
		//on peut indiquer un message que le pion a ete tue
		//System.out.println("Pion tue en "+maCase.afficherCoordonneeCase());

		//on change les dMax des pions qui seraient dans les direction du pion qui va etre tue
		for(int toDir = 0; toDir < 4; toDir++)
		{
			updateDMaxPionDistant(toDir, getDMax(getIndiceDMaxOpose(toDir)) + 1, p);
		}
		
		//on sauvegarde les coordonnees du pion
		x = maCase.getX();
		y = maCase.getY();
		
		//on dit a la case du plateau qu'elle n'a plus de pion
		maCase.removePion();
		
		//mais on dit au pion qu'il est maintenant sur une case morte qui enregistre ses coordonnees
		caseMorte.setPion(this);
		caseMorte.setCoordonnee(x,y);
	}

	/**
	 * On fait revivre un pion (faire l'inverse que ce que l'on a fait quand on l'a tue)
	 * @param p plateau sur lequel on va reprendre le mouvement
	 */
	public void revivrePion(Plateau p) {
		int x, y;
		
		//on sauvegarde les coordonnees du pion
		x = maCase.getX();
		y = maCase.getY();
		
		//on dit a la case morte qu'elle n'a plus de pion
		maCase.removePion();
		
		//mais on dit au pion qu'il est maintenant revenu sur le plateau
		p.getCase(x,y).setPion(this);
		
		//on change les dMax des pions qui seraient dans les direction du pion qui va revivre
		for(int toDir = 0; toDir < 4; toDir++)
		{
			updateDMaxPionDistant(toDir, -(getDMax(getIndiceDMaxOpose(toDir)) + 1), p);
		}
	}

	/**
	 * on dit avec une direction dir et un pas donn�, si le mouvement du pion sera vers le trone
	 * @param dir direction du mouvement
	 * @param pas pas du mouvement
	 * @param p plateau du jeu
	 * @return retourne si le mouvement du pion sera vers le trone
	 */
	public boolean mouvVersTrone(int dir, int pas, Plateau p) {
		if(maCase.getCase(dir, pas, p).getTypeCase().equals("Trone")) return true;
		else return false;
	}
}
