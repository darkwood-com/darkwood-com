package Jeu;

public class CaseTrone extends Case {

	public CaseTrone(int i, int j) {
		super(i, j);
	}

	/**
	 * afficher la case T (Case Trone)
	 * @param seePion booleen qui indique si on veut afficher le pion par dessu la case
	 */
	public void afficherCase(boolean seePion){
		if(seePion && monPion != null) afficherPionCase();
		else System.out.print("T");
	}
	
	/**
	 * indique le type de la case : "Mur" ou "Normale" ou "Sortie" ou "Trone"
	 * @return retourne le type de la case "Trone"
	 */
	public String getTypeCase(){
		return "Trone";
	}
}
