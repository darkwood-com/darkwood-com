package Jeu;

public class Jeu {

	private Joueur[] j; //j[0] = joueur 1, j[1] = joueur 2
	private int joueurCourant; //le joueur qui est en train de jouer
	private Plateau plateau;
	private int niveauAffichageCourrant = 0;
	private Memo lastMemo; //on a directement le dernier memo des deplacements dans le temps
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Jeu jeu = new Jeu();
		//on choisi le niveau d'affichage du plateau pour tout le jeu
		jeu.setNiveauAffichageCourrant(1);
		
		System.out.println("debut du jeu");
		jeu.afficherPlateau();
		
		Pion pionABouger = jeu.j[0].getMesPions().get(0);
		
		System.out.println("deplacement de pion");
		jeu.deplacerPion(pionABouger, 1, 3);
		jeu.afficherPlateau();
	}
	
	/**
	 * initialisation du plateau et des joueurs
	 *
	 */
	public Jeu() {
		plateau = new Plateau();
		j = new Joueur[2];
		j[0] = new Joueur("Blanc", plateau);
		j[1] = new Joueur("Noir", plateau);
		joueurCourant = 0;
	}
	
	/**
	 * preconditions :<br>
	 * - deplacement > 0 (si une piece est deplacee, on la bouge forcement)<br>
	 * - direction : 0 = haut, 1 = droite, 2 = bas, 3 = gauche<br>
	 * - p = Le pion que le joueur qui possede le pion veut deplacer<br>
	 * - le deplacement du pion doit etre valide : il doit respecter les limites fixees par les variables dMax du pion<br>
	 * <br>
	 * postconditions :<br>
	 * - Le pion p avance a la case voulue<br>
	 * - L'ancienne case se voit attribuer 0 pions et la nouvelle case contient le pion p<br>
	 * - les parametres dMax du pion p changent<br>
	 * - On change les parametres dMax des quatres pions potentiels qui seraient situes en haut, a droite, en bas, en haut de l'ancienne position du pion p<br>
	 * - On change les parametres dMax des quatres pions potentiels qui seraient situes en haut, a droite, en bas, en haut de la nouvelle position du pion p<br>
	 * 
	 * @param p Le pion que le joueur qui possede le pion veut deplacer
	 * @param dir (0 = haut, 1 = droite, 2 = bas, 3 = gauche) : la direction dans laquelle le jeu veut deplacer le pion
	 * @param pas deplacement (> 0) qui est le nombre de cases pour lequel le joueur va deplacer son pion
	 */
	public void deplacerPion(Pion p, int dir, int pas){
		p.deplacerPion(dir, pas, plateau);
	}
	
	/**
	 * le pion p capture les pions qui sont dans sa direction si c'est possible (devant, a droite, a gauche)
	 * @param p pion qui capture les autres
	 * @param dir direction vers laquelle le pion capture
	 * @return on retourne le tableau de pion qui a ete potentiellement tue
	 */
	public Pion[] capturerPions(Pion p, int dir) {
		return p.capturerPions(dir, plateau);
	}
	
	/**
	 * on defini le nombre de coup que l'on a envie de memoriser
	 * @param cache nombre de coup que l'on a envie de memoriser
	 */
	public void memoSetCache(int cache){
		lastMemo = new Memo(cache, null);
	}
	
	
	/**
	 * le mouvement de deplacement puis des captures du pion est memorise et on met a jour le lastMemo
	 * @see Jeu.Jeu#deplacerPion(Pion,int,int)
	 * @see Jeu.Jeu#capturerPions(Pion,int)
	 * @param p Le pion que le joueur qui possede le pion veut deplacer
	 * @param dir (0 = haut, 1 = droite, 2 = bas, 3 = gauche) : la direction dans laquelle le jeu veut deplacer le pion
	 * @param pas deplacement (> 0) qui est le nombre de cases pour lequel le joueur va deplacer son pion
	 */
	public void memoDepCapPion(Pion p, int dir, int pas) {
		Pion[] pionsTue;
		
		//on deplace le pion et on fait les captures
		deplacerPion(p, dir, pas);
		pionsTue = capturerPions(p, dir);
		
		//on memorise le mouvement
		lastMemo = lastMemo.memoriserMouvement(p, dir, pas, pionsTue);
	}
	
	/**
	 * le mouvement de deplacement puis des captures du pion sont defaits et on met a jour le lastMemo
	 */
	public void memoDefaireDepCapPion() {
		//on met en memoire le mouvement precedent
		lastMemo = lastMemo.reprendreMouvement(plateau);
	}
	
	/**
	 * affiche le plateau en ligne de commande selon plusieurs niveau :<br>
	 * i = -1 > on affiche pas le plateau
	 * i = 0 > affiche le plateau de taille 9x9 avec les pions<br>
	 * i = 1 > affiche le plateau de taille 9x9 avec les pions et leur dMax respectif<br>
	 * i = 2 > affiche le plateau de taille 11x11 sans les pions et les caracteristiques des cases<br>
	 * i = 3 > affiche le plateau de taille 11x11 avec les pions et les caracteristiques des cases<br>
	 * i = 4 > affiche le plateau de taille 9x9 avec les pions et les coordonnee des cases<br>
	 * @param n niveau d'affichage du plateau a afficher
	 */
	public void afficherPlateau(int n){
		if(n != -1) plateau.afficherPlateau(n);
	}
	
	/**
	 * affiche le plateau en ligne de commande selon l'affichage courrant
	 */
	public void afficherPlateau(){
		afficherPlateau(niveauAffichageCourrant);
	}
	
	/**
	 * on regle le niveau d'affichage courrant
	 * @param n nouveau niveau d'affichage courrant
	 */
	public void setNiveauAffichageCourrant(int n){
		niveauAffichageCourrant = n;
	}
	
	/**
	 * on retourne le joueur blanc
	 * @return on retourne le joueur blanc
	 */
	public Joueur getJoueurBlanc(){
		return j[0];
	}
	
	/**
	 * on retourne le joueur noir
	 * @return on retourne le joueur noir
	 */
	public Joueur getJoueurNoir(){
		return j[1];
	}
	
	/**
	 * on retourne le joueur courrant qui doit jouer au format Joueur
	 * @return on retourne le joueur qui doit jouer au format Joueur
	 */
	public Joueur getJoueur(){
		return j[joueurCourant];
	}
	
	/**
	 * on retourne le joueur courrant qui doit jouer au format int
	 * @return on retourne le joueur qui doit jouer au format int
	 */
	public int getJoueurInt(){
		return joueurCourant;
	}

	/**
	 * on retourne le plateau de jeu
	 * @return on retourne le plateau de jeu
	 */
	public Plateau getPlateau(){
		return plateau;
	}
	
	/**
	 * on retourne le joueur suivant et il est maintenant le joueur qui doit jouer
	 * @return on retourne le joueur suivant
	 */
	public Joueur joueurSuivant() {
		joueurCourant = (joueurCourant + 1)%2;
		return j[joueurCourant];
	}
	
	/**
	 * on retourne la piece roi du jeu
	 * @return on retourne la piece roi du jeu
	 */
	public Roi getRoi(){
		return j[0].getRoi();
	}
}
