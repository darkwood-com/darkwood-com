package Jeu;

abstract public class Case {
	//coordonnees de la case
	int x; //coordonnee horizontale
	int y; //coordonnee verticale
	
	Pion monPion; //indique si la case contient un pion ou pas
	
	public Case(int i, int j) {
		x = i;
		y = j;
		
		monPion = null; //par defaut, il n'y a pas de pion sur la case
	}

	/**
	 * la case contient maintenant le pion p. On dit alors que le pion p est sur cette case
	 * @param p p est le pion qui est sur cette case
	 */
	public void setPion(Pion p) {
		monPion = p;
		p.setCase(this);
	}
	
	/**
	 * precondition : un pion est pose sur cette case <br>
	 * la case retire le pion et dit au pion qu'il n'est plus sur cette case
	 *
	 */
	public void removePion() {
		monPion.setCase(null);
		monPion = null;
	}
	
	/**
	 * on regarde si il y a ou pas un pion sur la case
	 * @return on retourne le pion qui est sur la case, null s'il n'y a pas de pion sur cette case
	 */
	public Pion getPion() {
		return monPion;
	}

	/**
	 * @return on retourne la coordonnee x de la case
	 */
	public int getX() {
		return x;
	}
	
	/**
	 * @return on retourne la coordonnee y de la case
	 */
	public int getY() {
		return y;
	}
	
	/**
	 * on enregistre manuellement les coordonnes de la case
	 * @param x coordonnee x de la case
	 * @param y coordonnee y de la case
	 */
	public void setCoordonnee(int x, int y){
		this.x = x;
		this.y = y;
	}

	/**
	 * preconditions :<br>
	 * - la case demandee doit exister<br>
	 * posconditions :<br>
	 * on retourne la case selon la direction dir et le pas<br>
	 * dir = 0 > case du haut par rapport au plateau p<br>
	 * dir = 1 > case de droite par rapport au plateau p<br>
	 * dir = 2 > case du bas par rapport au plateau p<br>
	 * dir = 3 > case de gauche par rapport au plateau p
	 * @param dir direction vers laquelle on veut aller
	 * @param pas nombre de deplacements pour atteindre la case
	 * @param p
	 * @return on retourne la case suivante selon i
	 */
	public Case getCase(int dir, int pas, Plateau p) {
		switch(dir)
		{
		case 0: return p.getCase(x,y-pas);
		case 1: return p.getCase(x+pas,y);
		case 2: return p.getCase(x,y+pas);
		case 3: return p.getCase(x-pas,y);
		}
		
		return null;
	}

	/**
	 * Afficher le pion qui est sur la case
	 */
	public void afficherPionCase() {
		if(monPion == null) System.out.print(" ");
		//else System.err.print(monPion.afficherPion());
		else System.out.print(monPion.afficherPion());
	}

	/**
	 * Afficher le dMax[i] du pion qui est sur la case
	 * @param i indice du dMax[i]
	 */
	public void afficherPionCase(int i) {
		if(monPion == null) System.out.print(" ");
		else System.out.print(monPion.getDMax(i));
	}
	
	/**
	 * afficher la case sous le format (ligne,colonne)
	 * @return retourne les coordonnees de la case en String  sous le format (ligne,colonne)
	 */
	public String afficherCoordonneeCase(){
		return "("+x+","+y+")";
	}
	
	/**
	 * afficher la case sous le format "ligne colonne" pour le reseau
	 * @return retourne les coordonnees de la case en String  sous le format "ligne colonne" pour le reseau
	 */
	public String afficherLigneColonneCaseReseau() {
		return (x-1)+" "+(y-1);
	}
	
	/**
	 * afficher la case
	 * @param seePion booleen qui indique si on veut afficher le pion par dessu la case
	 */
	abstract public void afficherCase(boolean seePion);

	/**
	 * indique le type de la case : "Mur" ou "Normale" ou "Sortie" ou "Trone"
	 * @return retourne le type de la case ("Mur", "Normale", "Sortie", "Trone")
	 */
	abstract public String getTypeCase();
}
