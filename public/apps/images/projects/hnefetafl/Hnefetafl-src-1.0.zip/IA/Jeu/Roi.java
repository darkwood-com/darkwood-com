package Jeu;

public class Roi extends Pion {

	/**
	 * On cree un nouveau pion sur le plateau p aux coordonnee (x,y). Le pion ajuste automatiquement ses distances maximum (dMax)
	 * @param x coordonnee x du pion
	 * @param y coordonnee y du pion
	 * @param p plateau p sur lequel va etre pose le pion
	 * @param j le pion appartient au joueur j
	 */
	public Roi(int x, int y, Plateau p, Joueur j) {
		super(x, y, p, j);
	}
	
	/**
	 * affiche la couleur du pion sous forme de chaine de caractere
	 */
	public String afficherPion()
	{
		return "R";
	}
	
	/**
	 * retourne le type de la piece
	 * @return retourne "Roi"
	 */
	public String getTypePion(){
		return "Roi";
	}
	
	/**
	 * on regarde si le roi est capture ou pas sur le plateau p
	 * @param p plateau sur lequel on regarde
	 * @return on dit si le pion est capture ou pas
	 */
	public boolean estCapture(Plateau p){
		if(estBloque())
		{
			//on regarde si les pions sont tous des ennemis
			if((getStatut(0,1,p) == 2) &&
			   (getStatut(1,1,p) == 2) &&
			   (getStatut(2,1,p) == 2) &&
			   (getStatut(3,1,p) == 2)) return true;
		}
		return false;
	}
	
	/**
	 * on regarde si le roi est sur une case sortie ou pas
	 * @return on dit si le roi est sur une case sortie ou pas
	 */
	public boolean estSortit(){
		if(getCase().getTypeCase().equals("Sortie")) return true;
		return false;
	}
}
