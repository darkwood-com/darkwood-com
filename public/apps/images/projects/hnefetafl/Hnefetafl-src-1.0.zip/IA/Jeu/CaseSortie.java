package Jeu;

public class CaseSortie extends Case {

	public CaseSortie(int i, int j) {
		super(i, j);
	}

	/**
	 * afficher la case S (Case Sortie)
	 * @param seePion booleen qui indique si on veut afficher le pion par dessu la case
	 */
	public void afficherCase(boolean seePion){
		if(seePion && monPion != null) afficherPionCase();
		else System.out.print("S");
	}
	
	/**
	 * indique le type de la case : "Mur" ou "Normale" ou "Sortie" ou "Trone"
	 * @return retourne le type de la case "Sortie"
	 */
	public String getTypeCase(){
		return "Sortie";
	}
}
