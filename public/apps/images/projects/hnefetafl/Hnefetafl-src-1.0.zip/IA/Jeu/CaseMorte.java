/**
 * 
 */
package Jeu;

/**
 * @author math
 *
 */
public class CaseMorte extends Case {

	public CaseMorte(int i, int j) {
		super(i, j);
	}

	/* (non-Javadoc)
	 * @see Jeu.Case#afficherCase(boolean)
	 */
	public void afficherCase(boolean seePion) {
		afficherPionCase();
	}

	/* (non-Javadoc)
	 * @see Jeu.Case#getTypeCase()
	 */
	public String getTypeCase() {
		return "Morte";
	}

}
