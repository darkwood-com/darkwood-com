package Jeu;

public class CaseMur extends Case {

	public CaseMur(int i, int j) {
		super(i, j);
	}

	/**
	 * on retourne la case suivante selon i<br>
	 * i = 0 > case du haut par rapport au plateau p<br>
	 * i = 1 > case de droite par rapport au plateau p<br>
	 * i = 2 > case du bas par rapport au plateau p<br>
	 * i = 3 > case de gauche par rapport au plateau p<br><br>
	 * note : puisque c'est une case mur, on n'a pas de case suivante aux extremites
	 * @param i
	 * @param p
	 * @return on retourne la case suivante selon i
	 */
	public Case getCaseSuivante(int i, Plateau p) {
		switch(i)
		{
		case 0: 
			if(y == 0) return null;
			return p.getCase(x,y-1);
		case 1:  
			if(x == (p.nbCasesTotal - 1)) return null;
			return p.getCase(x+1,y);
		case 2:  
			if(y == (p.nbCasesTotal - 1)) return null;
			return p.getCase(x,y+1);
		case 3:  
			if(x == 0) return null;
			return p.getCase(x-1,y);
		}
		
		return null;
	}
	
	/**
	 * afficher la case M (Case Mur)
	 * @param seePion booleen qui indique si on veut afficher le pion par dessu la case
	 */
	public void afficherCase(boolean seePion){
		if(seePion && monPion != null) afficherPionCase();
		else System.out.print("M");
	}
	
	/**
	 * indique le type de la case : "Mur" ou "Normale" ou "Sortie" ou "Trone"
	 * @return retourne le type de la case "Mur"
	 */
	public String getTypeCase(){
		return "Mur";
	}
}
