package Jeu;

import java.util.ArrayList;

public class Joueur {
	String couleur; //Blanc ou Noir
	ArrayList<Pion> mesPions; //les pions du joueur
	Roi roi; //on sauvegarde le roi du joueur blanc
	
	/**
	 * Cree un nouveau joueur de couleur 'Blanc' ou 'Noir' et place ses Pions sur le plateau p
	 * @param couleur couleur du joueur (Blanc ou Noir)
	 * @param p plateau sur lequel, le joueur va poser ses pieces
	 */
	public Joueur(String couleur, Plateau p) {
		this.couleur = couleur;
		this.mesPions = new ArrayList();
		this.roi = null;
		
		if(couleur.equals("Blanc")) //si le joueur est blanc
		{
			roi = new Roi (5, 5, p, this);
			
			mesPions.add(new Pion(5, 3, p, this));
			mesPions.add(new Pion(5, 4, p, this));
			mesPions.add(new Pion(3, 5, p, this));
			mesPions.add(new Pion(4, 5, p, this));
			mesPions.add(roi);
			mesPions.add(new Pion(6, 5, p, this));
			mesPions.add(new Pion(7, 5, p, this));
			mesPions.add(new Pion(5, 6, p, this));
			mesPions.add(new Pion(5, 7, p, this));
		}
		else //si le joueur est noir
		{
			mesPions.add(new Pion(4, 1, p, this));
			mesPions.add(new Pion(5, 1, p, this));
			mesPions.add(new Pion(6, 1, p, this));
			mesPions.add(new Pion(5, 2, p, this));
			
			mesPions.add(new Pion(1, 4, p, this));
			mesPions.add(new Pion(1, 5, p, this));
			mesPions.add(new Pion(1, 6, p, this));
			mesPions.add(new Pion(2, 5, p, this));

			mesPions.add(new Pion(9, 4, p, this));
			mesPions.add(new Pion(9, 5, p, this));
			mesPions.add(new Pion(9, 6, p, this));
			mesPions.add(new Pion(8, 5, p, this));
			
			mesPions.add(new Pion(4, 9, p, this));
			mesPions.add(new Pion(5, 9, p, this));
			mesPions.add(new Pion(6, 9, p, this));
			mesPions.add(new Pion(5, 8, p, this));
		}
	}
	
	/**
	 * Connaitre la couleur du joueur
	 * @return retourne la couleur du joueur (Blanc ou Noir)
	 */
	public String getCouleur(){
		return couleur;
	}
	
	/**
	 * le joueur donne sa liste de pion
	 * @return on revoie la liste des pions du joueur
	 */
	public ArrayList<Pion> getMesPions()
	{
		return mesPions;
	}

	/**
	 * on retourne le roi du joueur blanc, null sinon
	 * @return on retourne le roi du joueur blanc, null sinon
	 */
	public Roi getRoi() {
		return roi;
	}
}