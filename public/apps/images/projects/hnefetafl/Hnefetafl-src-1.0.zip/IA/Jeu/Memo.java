package Jeu;

public class Memo {
	//memo suivants et precedents
	Memo suivant;
	Memo precedent;
	
	//sauvegarde des mouvements du pion
	Pion p;
	int dir;
	int pas;
	
	//sauvegarde des pions tues apres son deplacement
	Pion[] pTues;

	/**
	 * on cree l'historique et est definit par le cache que l'on lui attribue
	 * @param cache cache que l'on lui attribue a l'historique
	 */
	public Memo(int cache, Memo predent) {
		p = null;
		dir = 0;
		pas = 0;
		pTues = null;
		
		precedent = predent;
		
		if(cache != 0) 	suivant = new Memo(cache - 1, this);
		else 			suivant = null;
	}

	/**
	 * on memorise le mouvement
	 * @param p pion que l'on a deplace
	 * @param dir direction dans laquelle le pion a ete deplace
	 * @param pas nombre de deplacements que le pion a effectue
	 * @param pionsTue liste des pions qui ont ete tues apres le mouvement
	 * @return on retourne le memo suivant
	 */
	public Memo memoriserMouvement(Pion p, int dir, int pas, Pion[] pionsTue) {
		this.p = p;
		this.dir = dir;
		this.pas = pas;
		this.pTues = pionsTue;
		
		return suivant;
	}

	/**
	 * on met en memoire le mouvement precedent et on retourne le memo precedent
	 * @param p plateau sur lequel on va reprendre le mouvement
	 * @return memo precedent
	 */
	public Memo reprendreMouvement(Plateau p) {
		return precedent.faireMouvementMemo(p);
	}

	/**
	 * on met en memoire le mouvement precedent et on retourne le memo
	 * @param p plateau sur lequel on va reprendre le mouvement
	 * @return le memo this
	 */
	private Memo faireMouvementMemo(Plateau plateau) {
		int posPionTue;
		
		//on fait revivre les pions potentiels qui etaient morts
		for(posPionTue = 2; posPionTue >= 0; posPionTue --)
		{
			if(pTues[posPionTue] != null) pTues[posPionTue].revivrePion(plateau);
		}
		
		//on defait le mouvement qui avait ete memorise dans la direction oppose avec le meme pas
		p.deplacerPion((dir+2)%4, pas, plateau);

		return this;
	}
}
