package Partie;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

import IO.ExceptionMsg;
import Jeu.Case;
import Jeu.Jeu;
import Jeu.Pion;

public class Coup {
	Jeu jeu; //jeu sur lequel on va jouer
	Pion p; //le pion qui va etre utilise pour le coup
	int dir; //la direction dans laquelle on veut bouger le pion
	int pas; //le nombre de deplacement que l'on va faire pour bouger le pion
	
	private int[] posX, posY; //coups sauvegarde temporairement
	private Pion[] pionsTue; //liste des pions que l'on a tue apres un coup
	
	Coup(Jeu jeu)
	{
		this.jeu = jeu;
		posX = new int[2];
		posY = new int[2];
	}
	
	/**
	 * on retourne le jeu dans lequel on joue le coup
	 * @return on retourne le jeu dans lequel on joue le coup
	 */
	public Jeu getJeu()
	{
		return jeu;
	}
	
	/**
	 * afficher un coup apres qu'il a ete joue
	 * @param intelligenceJ Intelligence du joueur
	 */
	public void afficherCoupJoue(AlgoJeu intelligenceJ){
		Case casePionArr = p.getCase();
		Case casePionDep = casePionArr.getCase((dir+2)%4,pas,jeu.getPlateau());
		
		String coordonneePionArr = casePionArr.afficherCoordonneeCase();
		String coordonneePionDep = casePionDep.afficherCoordonneeCase();
		
		System.out.println("["+intelligenceJ.afficherAlgo()+"] "+jeu.getJoueur().getCouleur()+" joue "+coordonneePionDep+" -> "+coordonneePionArr);
	}

	/**
	 * on affiche le coup joue sous forme de caractere transmis pour le reseau
	 * @return chaine de caractere representant le coup joue
	 */
	public String afficherCoupJoueReseau() {
		Case casePionArr = p.getCase();
		Case casePionDep = casePionArr.getCase((dir+2)%4,pas,jeu.getPlateau());
		
		String ligneColonnePionArr = casePionArr.afficherLigneColonneCaseReseau();
		String ligneColonnePionDep = casePionDep.afficherLigneColonneCaseReseau();
		
		return ligneColonnePionDep + " " + ligneColonnePionArr + '\0';
	}
	
	/**
	 * Verifie qu'un coup est bien possible<br>
	 * si le coup est valide, les parametres du coups sont mis a jour
	 * @param pionsJoueur pions que le joueur possede
	 * @return true si le coup est possible pour le joueur j sur le plateau
	 */
	public boolean estValide(ArrayList<Pion> pionsJoueur){
		//on commence par regarder la direction et le pas dans lequel le joueur veut jouer
		
		if(posX[0] == posX[1]) //on se deplace a la verticale
		{
			if(posY[0] > posY[1]) //on se deplace vers le haut
			{
				dir = 0;
				pas = Math.abs(posY[0] - posY[1]);
			}
			else if(posY[0] < posY[1]) //on se deplace vers le bas
			{
				dir = 2;
				pas = Math.abs(posY[0] - posY[1]);
			}
			else return false; //on ne se deplace pas
		}
		else if(posY[0] == posY[1]) //on se deplace a l'horizontal
		{
			if(posX[0] > posX[1]) //on se deplace vers la gauche
			{
				dir = 3;
				pas = Math.abs(posX[0] - posX[1]);
			}
			else if(posX[0] < posX[1]) //on se deplace vers la droite
			{
				dir = 1;
				pas = Math.abs(posX[0] - posX[1]);
			}
			else return false; //on ne se deplace pas
		}
		else return false; //pas de direction
		
		//on verifie maintenant que le joueur dispose du pion qu'il veut bouger
		Iterator<Pion> it = pionsJoueur.iterator();
		p = null;
		
		boolean trouve = false;
		
		while(it.hasNext() && !trouve)
		{
			p = it.next();
			if(p.getX() == posX[0] &&
			   p.getY() == posY[0]) trouve = true;
		}
		
		if(trouve == false) return false;
		
		//on verifie que le pion a le droit de se deplacer
		if(pas > p.getDMax(dir)) return false;
		
		return true;
	}

	/**
	 * Joue le coup (le coup est suppose etre valide)
	 */
	public void joue(){
		jeu.deplacerPion(p, dir, pas);
	}
	
	
	/**
	 * Capture les pions apres avoir joue le coup
	 */
	public void capture() {
		pionsTue = jeu.capturerPions(p, dir);
	}
	
	/**
	 * on affiche quels ont ete les pions qui ont ete capture apres le coup joue
	 * @param intelligenceJ Intelligence du joueur
	 */
	public void afficherCapture(AlgoJeu intelligenceJ) {
		for(int i = 0; i<3 ; i++)
		{
			if(pionsTue[i] != null)
			{
				Case casePionTue = pionsTue[i].getCase();
				String coordonneePionTue = casePionTue.afficherCoordonneeCase();
				System.out.println("["+intelligenceJ.afficherAlgo()+"] "+jeu.getJoueur().getCouleur()+" tue le pion en "+coordonneePionTue);
			}
		}
	}
	
	/**
	 * permet de lire un Coup depuis une chaine de caractere
	 * @param input chaine de caractere passe en entree
	 * @param mode mode dans lequel on va enregistrer les entrees
	 * @return true si la chaine est correcte
	 */
	public boolean fromString(String input, String mode){
		StringTokenizer coupTokenizer = new StringTokenizer(input);
		String tockenLu;
		char[] tockenChar;
		int ligne, colonne;
		
		 try {
			 tockenLu = coupTokenizer.nextToken();
			 tockenChar = tockenLu.toCharArray();			 
			 ligne	=  Integer.parseInt(String.valueOf(tockenChar[0]));
			 colonne = Integer.parseInt(String.valueOf(tockenChar[1]));
		 }
		 catch (Exception NumberFormatException) {
			 ligne = 0; colonne = 0;
			 return false;
		 }
		 if ((ligne < 1) || (ligne > 9) ||
			 (colonne < 1) || (colonne > 9))
			 return false;
		 
		 if(mode.equals("Prendre"))
		 {
			 posX[0] = ligne;
			 posY[0] = colonne;
		 }
		 else
		 {
			 posX[1] = ligne;
			 posY[1] = colonne;
		 }

		 return true;
	}
	
	/**
	 * On cree un nouveau coup exact par rapport a des variables
	 * @param p le pion qui va etre utilise pour le coup
	 * @param dir la direction dans laquelle on veut bouger le pion
	 * @param pas le nombre de deplacement que l'on va faire pour bouger le pion
	 */
	public void fromVar(Pion p, int dir, int pas){
		this.p = p;
		this.dir = dir;
		this.pas = pas;
	}

	/**
	 * On recoit un coup du reseau<br>
	 * On suppose que l'arbitre a verifie que le mouvement ennemi etait bien legal.
	 * @param startRow Ligne de depart du mouvement (entre 0 et TAILLE-1), 
	 *                 commencant en haut=0 a bas=(TAILLE-1)
	 * @param startCol Colonne de depart du mouvement (entre 0 et TAILLE-1), 
	 *                 commencant a gauche=0 a droite=(TAILLE-1)
	 * @param finishRow Ligne d'arrivee du mouvement (entre 0 et TAILLE-1),
	 *                  commencant en haut=0 a bas=(TAILLE-1)
	 * @param finishCol Colonne d'arrivee du mouvement (entre 0 et TAILLE-1),
	 * 	                commencant a gauche=0 a droite=(TAILLE-1)
	 */
	public void fromReseau(int startRow, int startCol, int finishRow, int finishCol) {
		posX[0] = startRow  + 1;
		posY[0] = startCol  + 1;
		posX[1] = finishRow + 1;
		posY[1] = finishCol + 1;
		
		//on doit recupere le pion correspondant a la case choisie, sinon ya un probleme
		try
		{
			this.p = jeu.getPlateau().getCase(posX[0], posY[0]).getPion();
		}
		catch(NullPointerException e)
		{
			System.out.println("Le reseau n'a pas envoye les bonnnes coordonnee de la cas, ou bien il n'y a pas de pion sur la case demandee");
		}
		
		try
		{
			if(posX[0] == posX[1]) //on se deplace a la verticale
			{
				if(posY[0] > posY[1]) //on se deplace vers le haut
				{
					dir = 0;
					pas = Math.abs(posY[0] - posY[1]);
				}
				else if(posY[0] < posY[1]) //on se deplace vers le bas
				{
					dir = 2;
					pas = Math.abs(posY[0] - posY[1]);
				}
				else //on ne se deplace pas
				{
					dir = 0;
					pas = 0;
				}
			}
			else if(posY[0] == posY[1]) //on se deplace a l'horizontal
			{
				if(posX[0] > posX[1]) //on se deplace vers la gauche
				{
					dir = 3;
					pas = Math.abs(posX[0] - posX[1]);
				}
				else if(posX[0] < posX[1]) //on se deplace vers la droite
				{
					dir = 1;
					pas = Math.abs(posX[0] - posX[1]);
				}
				else //on ne se deplace pas
				{
					dir = 0;
					pas = 0;
				}
			}
			else throw new ExceptionMsg("le reseau envoye donne un mauvais coup"); //le coup n'est pas possible
		}
		catch(ExceptionMsg e) {
			e.afficherMsg();
		}
	}
	
	/**
	 * on cree le meilleur coup que le joueur numeroJoueur va jouer
	 * @param intelligenceJ on donne l'intelligence qui va jouer le coup
	 */
	public void meilleurCoup(AlgoJeu intelligenceJ) {
		intelligenceJ.meilleurCoup(this);
	}
}
