/**
 * 
 */
package Partie;

import java.util.ArrayList;
import java.util.Iterator;

import Jeu.Jeu;
import Jeu.Pion;

/**
 * @author math
 *
 */
public class AlgoAlphaBeta implements AlgoJeu {
	private int pronfondeurMaxCourant = 0; //on enregistre la profondeur max courante
	
	/**
	 * implementation de Iterative Deepening
	 * @param i pronfondeur jusqu'a laquelle on veut aller
	 * @param coup le coup a jouer
	 */
	private void iterativeDeepening(int i, Coup coup) {
		for(int j = 1; j <= i; j++)
		{
			pronfondeurMaxCourant = j;
			negAB(coup, -1000000000, +1000000000, j);
		}
	}
	
	/**
	 * Implementation de neg-AlphaBeta qui met a jour le meilleur coup a jouer
	 * @param jeu jeu a evaluer
	 * @param A alpha
	 * @param B beta
	 * @param profondeur profondeur jusqu'a laquelle on veut faire negAB
	 * @return l'evaluation du plateau par rapport au jeu
	 */
	private int negAB(Coup coup, int A, int B, int profondeur)
	{
		Jeu jeu = coup.getJeu();
		
		if(estFeuille(jeu))
		{
			//System.out.println("FeuilleValue = "+evalueMax(jeu, profondeur)+" Profondeur="+profondeur);
			return evalueMax(jeu, profondeur);
			
		} //si c'est une feuille, retourne la valeur maximale
		if(profondeur == 0) return evalue(jeu); //si la profondeur est atteinte, on retourne l'heuristique
		
		//on regarde tous les successeurs de cet etat
		ArrayList<Pion> pionsJoueurC = jeu.getJoueur().getMesPions();
		Iterator<Pion> pionItC = pionsJoueurC.iterator();
		
		Pion pionC = null;
		int dirC = 0;
		int pasC = 0;
		
		int val = 0;
		
		//on prend tous les pions du joueur qui doit jouer
		while(pionItC.hasNext()) {
			pionC = pionItC.next();
			//on ne prend pas un pion mort
			if(pionC.estMort()) continue;
			
			//on fait toutes les directions possible pour le pion choisit
			for(dirC = 0; dirC < 4; dirC ++) {
				//on fait tous les pas (>0) possibles du pion dans la direction donnee
				for(pasC = 1; pasC <= pionC.getDMax(dirC); pasC ++) {
					//on ne prend pas les mouvements d'un pion vers le trone
					if(pionC.mouvVersTrone(dirC, pasC, jeu.getPlateau())) continue;
					
					//on fait le mouvement pour passer a l'etat suivant
					jeu.memoDepCapPion(pionC, dirC, pasC);
					//on passe la main au joueur suivant
					jeu.joueurSuivant();
					
					//on fait la recursivite
					val = -negAB(coup, -B, -A, profondeur - 1);

					//on revient au joueur courant
					jeu.joueurSuivant();
					//on defait le mouvement pour revenir a l'etat precedent
					jeu.memoDefaireDepCapPion();
					
					/*if((pronfondeurMaxCourant == profondeur)  || (pronfondeurMaxCourant - 1 == profondeur)) {
						System.out.println("eValue="+val+" Profondeur="+profondeur+" Pion="+pionC.getCase().afficherCoordonneeCase()+" Dir="+dirC+" Pas="+pasC);
					}*/
					
					if(val > A)
					{
						//on enregistre ce coup qui est le meilleur a jouer (seulement pour le prochain coup)
						if(pronfondeurMaxCourant == profondeur) coup.fromVar(pionC, dirC, pasC);
						
						A = val;
						
						if(A >= B)
						{
							return A;
						}
					}
				}
			}
		}
		
		return A;
	}
	
	/**
	 * on dit si le jeu courrant est une feuille ou pas
	 * @param jeu jeu a evlauer
	 * @return return si le jeu courrant est une feuille ou pas
	 */
	private boolean estFeuille(Jeu jeu) {
		if(	jeu.getRoi().estCapture(jeu.getPlateau()) || jeu.getRoi().estSortit()) return true;
		else return false;
	}

	/**
	 * on donne une heuristique maximale du plateau si c'est une feuille
	 * @param jeu si le jeu courrant
	 * @return on retourne un entier representant l'heuristique maximale du plateau
	 */
	private int evalueMax(Jeu jeu, int profondeur) {
		int valMax = 100 * (profondeur + 1);
		
		//si le roi est sorti est que c'est le joueur blanc on retourne valMax
		if(jeu.getRoi().estSortit() && (jeu.getJoueurInt() == 0)) return valMax;
		//si le roi est sorti est que c'est le joueur noir on retourne valMax
		else if(jeu.getRoi().estSortit() && (jeu.getJoueurInt() == 1))  return -valMax;
		//si le roi est capture est que c'est le joueur noir on retourne valMax
		else if(jeu.getRoi().estCapture(jeu.getPlateau()) && (jeu.getJoueurInt() == 1))  return valMax;
		//si le roi est capture est que c'est le joueur blanc on retourne valMax
		else if(jeu.getRoi().estCapture(jeu.getPlateau()) && (jeu.getJoueurInt() == 0)) return -valMax;
		
		return 0;
	}
	
	/**
	 * on donne une heuristique au jeu courant
	 * @param jeu si le jeu courrant est une feuille ou pas
	 * @return on retourne un entier representant une heuristique au jeu courant
	 */
	private int evalue(Jeu jeu) {
		int heuristique = 0;
		
		//heuristique qui est en fonction du nombre de pions vivants
		ArrayList<Pion> pionsJoueurC = null;
		Iterator<Pion> pionItC = null;
		Pion pionC = null;
		
		//on recupere les pions amis
		pionsJoueurC = jeu.getJoueur().getMesPions();
		
		pionItC = pionsJoueurC.iterator();
		
		while(pionItC.hasNext()) {
			pionC = pionItC.next();
			
			if(!pionC.getCase().getTypeCase().equals("Morte")) heuristique ++;
		}

		//on recupere les pions ennemis
		jeu.joueurSuivant();
		pionsJoueurC = jeu.getJoueur().getMesPions();
		jeu.joueurSuivant();

		pionItC = pionsJoueurC.iterator();

		while(pionItC.hasNext()) {
			pionC = pionItC.next();
			
			if(!pionC.getCase().getTypeCase().equals("Morte")) heuristique --;
		}
		
		return heuristique;
	}

	/* (non-Javadoc)
	 * @see Partie.AlgoJeu#meilleurCoup(Partie.Coup)
	 */
	public void meilleurCoup(Coup coup) {
		iterativeDeepening(2, coup);
		//iterativeDeepening(4, coup);
	}

	/* (non-Javadoc)
	 * @see Partie.AlgoJeu#afficherAlgo()
	 */
	public String afficherAlgo() {
		return "IA Alpha Beta";
	}

}
