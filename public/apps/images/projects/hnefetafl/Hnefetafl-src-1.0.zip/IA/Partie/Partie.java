package Partie;

import IO.InputKeyboard;
import Partie.AlgoJeu;
import Jeu.Jeu;
import Jeu.Roi;

public class Partie {
	private Jeu jeu;
	private InputKeyboard keyIn;
	private AlgoJeu[] intelligenceJ; //les deux intelligence qui vont jouer
	private Coup coupJ; //coup qui est joue
	
	/**
	 * on cree une nouvelle partie deja initialisee
	 *
	 */
	public Partie()
	{
		keyIn = new InputKeyboard();
		nouvellePartie();
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		boolean rejouer = false;
		
		do
		{
			Partie partie = new Partie();
			partie.jouerPartieLocale();
			rejouer = partie.rejouerPartie();
		} while(rejouer);//on rejoue a une nouvelle partie
	}
	
	/**
	 * on cree une nouvelle partie deja initialisee
	 *
	 */
	public void nouvellePartie(){
		jeu = new Jeu();
		coupJ = new Coup(jeu);
	}
	
	/**
	 * on joue a la partie en local (sur ce meme programme)
	 *
	 */
	public void jouerPartieLocale(){
		intelligenceJ = new AlgoJeu[2];
		
		intelligenceJ[0] = new AlgoAlphaBeta();
		intelligenceJ[1] = new AlgoAleatoire();
		
		/*intelligenceJ[0] = new AlgoAlphaBeta();
		intelligenceJ[1] = new AlgoAlphaBeta();*/
		
		/*intelligenceJ[0] = new AlgoAleatoire();
		intelligenceJ[1] = new AlgoAleatoire();*/
		
		/*intelligenceJ[0] = new AlgoChoixHumain();
		intelligenceJ[1] = new AlgoChoixHumain();*/
		
		//on defini le cache de memoire
		jeu.memoSetCache(20);
		
		//on choisi le niveau d'affichage du plateau pour tout le jeu
		jeu.setNiveauAffichageCourrant(1);
		System.out.println("debut du jeu");
		
		do
		{
			jouerCoup();
		} while(!estFinPartie());
			
		finPartie(-1);
	}
	
	/**
	 * on joue a la partie en reseau
	 * @param myColor couleur du joueur que l'on est dans la partie
	 *
	 */
	public void jouerPartieReseau(int myColor){
		int hisColor = (myColor+1)%2;
		
		intelligenceJ = new AlgoJeu[2];
		intelligenceJ[myColor] = new AlgoAlphaBeta();
		intelligenceJ[hisColor] = new AlgoReseau();
		
		//on defini le cache de memoire (pour AlphaBeta)
		jeu.memoSetCache(20);
		
		//on choisi le niveau d'affichage du plateau pour tout le jeu
		jeu.setNiveauAffichageCourrant(1);
		System.out.println("debut du jeu");
	}
	
	/**
	 * indique la fin de la partie et le joueur qui gagne
	 * @param colour indique le gagnant s'il es precise en clair -1 si l'rodi toi le deduire
	 *
	 */
	public void finPartie(int colour) {
		if(colour == -1)
		{
			//on cherche le gagant
			String joueurGagnant = gagnantPartie();
			System.out.println(joueurGagnant+" a gagne la partie");
		}
		else
		{
			//sinon on le precise directement
			String joueurGagnant = null;
			if(colour == 0) joueurGagnant = jeu.getJoueurBlanc().getCouleur();
			else 			joueurGagnant = jeu.getJoueurNoir().getCouleur();
			System.out.println(joueurGagnant+" a gagne la partie");
		}
	}
	
	/**
	 * on demande si on veut rejouer a la partie
	 * @return renvoie oui si on veut rejouer, non sinon
	 */
	private boolean rejouerPartie() {
		return keyIn.prompt("Voulez vous rejouer une autre partie?");
	}
	
	/**
	 * On dit si la partie est finie ou pas
	 * @return On dit si la partie est finie ou pas
	 */
	private boolean estFinPartie() {
		Roi roi = jeu.getRoi();
		
		//on regarde si le roi est sur une case de sortie
		if(roi.getCase().getTypeCase().equals("Sortie")) return true;
		//on regarde si le roi est encercle par des enemis
		if(roi.estCapture(jeu.getPlateau())) return true;
		
		return false;
	}
	
	private String gagnantPartie(){
		Roi roi = jeu.getRoi();
		
		if(roi.getCase().getTypeCase().equals("Sortie"))
			 return jeu.getJoueurBlanc().getCouleur();
		else return jeu.getJoueurNoir().getCouleur();
	}
	
	/**
	 * le joueur joue son coup
	 *
	 */
	private void jouerCoup() {
		//on recupere l'intelligence du coup courrant qui doit jouer
		AlgoJeu intelligenceCoupCourant = intelligenceJ[jeu.getJoueurInt()];
		
		//jeu.afficherPlateau(0);
		
		//le joueur courrant joue son coup
		coupJ.meilleurCoup(intelligenceCoupCourant);
		coupJ.joue();
		coupJ.afficherCoupJoue(intelligenceCoupCourant);
		coupJ.capture();
		coupJ.afficherCapture(intelligenceCoupCourant);
		
		//on passe au joueur suivant
		jeu.joueurSuivant();
	}

	/**
	 * on joue un coup en local et on renvoie la chaine de caractere coorespondant pour le reseau
	 * @return chaine de catactere representant le coup joue
	 */
	public String jouerCoupReseau() {
		jouerCoup();
		return coupJ.afficherCoupJoueReseau();
	}

	/**
	 * On recoit un coup du reseau<br>
	 * On suppose que l'arbitre a verifie que le mouvement ennemi etait bien legal.
	  @param startRow Ligne de depart du mouvement (entre 0 et TAILLE-1), 
	 *                 commencant en haut=0 a bas=(TAILLE-1)
	 * @param startCol Colonne de depart du mouvement (entre 0 et TAILLE-1), 
	 *                 commencant a gauche=0 a droite=(TAILLE-1)
	 * @param finishRow Ligne d'arrivee du mouvement (entre 0 et TAILLE-1),
	 *                  commencant en haut=0 a bas=(TAILLE-1)
	 * @param finishCol Colonne d'arrivee du mouvement (entre 0 et TAILLE-1),
	 * 	                commencant a gauche=0 a droite=(TAILLE-1)
	 */
	public void recevoirCoupReseau(int startRow, int startCol, int finishRow, int finishCol) {
		coupJ.fromReseau(startRow, startCol, finishRow, finishCol);
		jouerCoup();
	}
}
