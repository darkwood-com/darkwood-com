/**
 * 
 */
package Partie;

import java.util.ArrayList;
import java.util.Random;

import Partie.AlgoJeu;
import Jeu.Pion;

/**
 * @author math
 *
 */
public class AlgoAleatoire implements AlgoJeu {
	Random randGen;
	
	AlgoAleatoire(){
		randGen = new Random();
	}
	
	/* (non-Javadoc)
	 * @see Interfaces.AlgoJeu#meilleurCoup(Jeu.Jeu)
	 */
	public void meilleurCoup(Coup coup) {
		boolean coupValide = false;
		ArrayList<Pion> pionsJoueur = coup.getJeu().getJoueur().getMesPions();
		int nombrePionsJoueur = pionsJoueur.size();
		int pasAleatoireMax = 0;
		
		Pion pionAleatoire = null;
		int dirAleatoire = 0;
		int pasAleatoire = 0;
		
		int iterationsAleatoire = 0;
		int cotaIterationAleatoireMax = 1000;
		
		if(nombrePionsJoueur == 0)
		{
			System.out.println(afficherAlgo()+" n'a plus de pions");
			coup.getJeu().getPlateau().afficherPlateau(4);
			System.exit(1);
		}
		
		do
		{
			//choisir un pion du joueur aleatoirement
			pionAleatoire = pionsJoueur.get(randGen.nextInt(nombrePionsJoueur));
			
			//si c'est un pion sur un case morte (donc tue), on continue
			if(pionAleatoire.getCase().getTypeCase().equals("Morte")) continue;
			
			//direction aleatoire de 0 a 3
			dirAleatoire = randGen.nextInt(4);
			//pas aleatoire de 0 a dMax
			pasAleatoireMax = pionAleatoire.getDMax(dirAleatoire);
			if(pasAleatoireMax > 0)
			{
				pasAleatoire = randGen.nextInt(pasAleatoireMax) + 1;//renvoie 1 a dMax
				
				//il faut que le deplacement soit force pour que le choix soit valide
				if(pasAleatoire > 0) coupValide = true;
			}
			
			iterationsAleatoire ++;
			if(iterationsAleatoire > cotaIterationAleatoireMax)
			{
				System.out.println("Cota "+afficherAlgo()+" depasse");
				System.out.println("Pion aleatoire "+pionAleatoire.getCase().afficherCoordonneeCase());
				System.out.println("Direction aleatoire "+dirAleatoire);
				System.out.println("Pas aleatoire "+pasAleatoire);
				coup.getJeu().getPlateau().afficherPlateau(4);
				System.exit(1);
			}
		} while(!coupValide); //on boucle tant que le coup n'est pas possible
		
		//on met a jour le coup valide
		coup.fromVar(pionAleatoire, dirAleatoire, pasAleatoire);
	}

	/* (non-Javadoc)
	 * @see Interfaces.AlgoJeu#afficherAlgo()
	 */
	public String afficherAlgo() {
		return "Ordinateur Aleatoire";
	}

}
