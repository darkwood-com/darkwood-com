package Partie;

import java.util.ArrayList;

import IO.InputKeyboard;
import Partie.AlgoJeu;
import Jeu.Pion;

/**
 * @author math
 *
 */
public class AlgoChoixHumain implements AlgoJeu {
	private InputKeyboard keyIn;
	
	AlgoChoixHumain(){
		keyIn = new InputKeyboard();
	}
	
	/* (non-Javadoc)
	 * @see Interfaces.AlgoJeu#meilleurCoup(Jeu.Jeu)
	 */
	public void meilleurCoup(Coup coup) {
		boolean entreeValide = false;
		boolean coupValide = false;
		String inputString = null;
		String joueur = coup.getJeu().getJoueur().getCouleur();
		ArrayList<Pion> pionsJoueur = coup.getJeu().getJoueur().getMesPions();
		
		do
		{
			//piece a jouer
			entreeValide = false;
			do
			{
				inputString = keyIn.ask(joueur+" : Choisissez la piece a deplacer");
				entreeValide = coup.fromString(inputString, "Prendre");
			} while(!entreeValide); //on boucle tant que l'on a pas rentrer une chaine valide
			
			//deplacer la piece
			entreeValide = false;
			do
			{
				inputString = keyIn.ask(joueur+" : Choisissez sa nouvelle position");
				entreeValide = coup.fromString(inputString, "Deplacer");
			} while(!entreeValide); //on boucle tant que l'on a pas rentrer une chaine valide
			
			
			coupValide = coup.estValide(pionsJoueur);
		} while(!coupValide); //on boucle tant que le coup n'est pas possible
	}

	/* (non-Javadoc)
	 * @see Interfaces.AlgoJeu#afficherAlgo()
	 */
	public String afficherAlgo() {
		return "Humain au clavier";
	}

}
