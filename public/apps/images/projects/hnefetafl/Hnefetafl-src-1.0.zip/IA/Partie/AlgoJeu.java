package Partie;

import Partie.Coup;

public interface AlgoJeu {
	/**
	 * Methode de base pour appeler l'algorithme de recherche
	 * du meilleur coup (Minimax, Alpha-Beta, ID-Alpha-Beta, SSS*...)
	 * 
	 * @param coup coup dans lequel on va faire son meilleur coup
	 */
	public void meilleurCoup(Coup coup);
	
	/**
	 * Permet de savoir et d'imprimer le nom de l'algorithme utilise.
	 * @return Une chaine decrivant l'algorithme
	 */
	public String afficherAlgo();
}
