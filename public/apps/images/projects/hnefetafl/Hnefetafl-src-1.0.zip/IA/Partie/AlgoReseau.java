/**
 * 
 */
package Partie;

import Partie.AlgoJeu;

/**
 * @author math
 *
 */
public class AlgoReseau implements AlgoJeu {
	
	AlgoReseau(){}
	
	/* (non-Javadoc)
	 * @see Interfaces.AlgoJeu#meilleurCoup(Jeu.Jeu)
	 */
	public void meilleurCoup(Coup coup) {
		//le meilleur coup a deja ete donne pas le reseau.
		//Il n'y a donc pas d'intelligence ici, on ne fait rien du tout
	}

	/* (non-Javadoc)
	 * @see Interfaces.AlgoJeu#afficherAlgo()
	 */
	public String afficherAlgo() {
		return "Joueur Reseau";
	}

}
