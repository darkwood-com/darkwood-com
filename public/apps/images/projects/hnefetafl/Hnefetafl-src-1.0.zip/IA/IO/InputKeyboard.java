package IO;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * On recupere toutes les entrees du clavier
 * @author math
 *
 */
public class InputKeyboard {
	BufferedReader inKey;
	
	public InputKeyboard(){
		inKey = new BufferedReader(new InputStreamReader(System.in));
	}
	
	/**
	 * on lit la ligne rentree sur le clavier et on la retourne
	 * @return on retourne la ligne entree sur le clavier
	 */
	private String getLineInput()
	{
		String inputString = null;
		try {
			inputString = inKey.readLine();
		}
		catch (Exception e) {
			System.out.println(e);
		}
		
		return inputString;
	}
	

	/**
	 * On affiche un message on retourne la reponse texte donne par l'utilisateur
	 * @param msg message auquel on doit repondre
	 * @return resultat de la reponse
	 */
	public String ask(String msg)
	{
		String inputString = null;
		
		System.out.println(msg);
		inputString = getLineInput();
		
		return inputString;
	}
	
	/**
	 * On affiche un message et on demande de repondre par oui ou par non
	 * @param msg message auquel on doit repondre
	 * @return resultat de la reponse
	 */
	public boolean prompt(String msg)
	{
		boolean reponseIncorrecte = true;
		String inputString = null;
		
		do
		{
			System.out.println(msg+" (y/n)");
			inputString = getLineInput();
			if(inputString.equals("y") || inputString.equals("n")) reponseIncorrecte = false;
		} while(reponseIncorrecte);
		
		//on regarde si la response est vraie ou fausse
		if(inputString.equals("y")) return true;
		else 						return false;
	}
}
