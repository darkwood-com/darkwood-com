package IO;

public class ExceptionMsg extends Exception {
	String msg;
	
	public ExceptionMsg(String msg) {
		this.msg = msg;
	}
	
	public void afficherMsg() {
		System.out.println(msg);
	}
}
