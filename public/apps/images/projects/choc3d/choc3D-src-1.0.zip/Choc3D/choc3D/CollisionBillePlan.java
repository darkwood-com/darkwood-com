package choc3D;

public class CollisionBillePlan extends Collision {

	private Bille bille;
	private Plan pl;
	
	public CollisionBillePlan(Bille bille, Plan pl)
	{
		this.bille = bille;
		this.pl = pl;
	}
	
	public void collide()
	{
		bille.collide(pl);
	}

}
