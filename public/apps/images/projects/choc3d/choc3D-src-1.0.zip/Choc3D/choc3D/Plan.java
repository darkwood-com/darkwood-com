package choc3D;

import javax.vecmath.Vector3d;

public class Plan {
	private Vector3d pointPlan; //Point qui se situe sur le plan
	private Vector3d normale;  //Normale au plan
	
	Plan(Vector3d pointPlan, Vector3d normale)
	{
		this.pointPlan = pointPlan;
		this.normale = normale;
		
		this.normale.normalize();
	}
	
	public Vector3d getPointPlan()
	{
		return pointPlan;
	}
	
	public Vector3d getNormale()
	{
		return normale;
	}
}
