package choc3D;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.Iterator;

public class Anim implements Runnable
{
	private boolean alive;
	private double period;
	private Physics phys;
	
	public static Anim anim = null;

	public Anim(Physics phys)
	{
		this.setAlive(true);
		
		//on veut une animation pour 24 images par secondes : 1/24 ~= 41 ms
		this.setPeriod(41);
		this.phys = phys;
		
		(new Thread(this)).start();
	}

	public boolean isAlive()
	{
		return this.alive;
	}

	public void setAlive(boolean alive)
	{
		this.alive = alive;
	}

	public double getPeriod()
	{
		return this.period;
	}

	public void setPeriod(double period)
	{
		this.period = period;
	}
	
	public void stop()
	{
		this.setAlive(false);
	}
	
	public void run()
	{
		GregorianCalendar currentTime = new GregorianCalendar();
		double timeLast, timeToSleep;
		try
		{
			while (this.isAlive())
			{
				//debut de la periode
				
				timeLast = currentTime.getTimeInMillis();
				phys.Simulation(this.getPeriod());
				timeLast = currentTime.getTimeInMillis() - timeLast;
				
				//on attend exactement la periode si les calculs ont �t�s rapides
				timeToSleep = this.getPeriod() - timeLast;
				if(timeToSleep > 0) Thread.sleep((long) timeToSleep);
				
				//on met a jour l'affichage de la position des billes apr�s une periode
				ArrayList<Bille> billes = Bille.getBilles();
				Iterator<Bille> it = billes.iterator();
				while(it.hasNext()) it.next().updatePos();
				
				//fin de la periode
			}
		}
		catch (Exception e) {}
	}
}
