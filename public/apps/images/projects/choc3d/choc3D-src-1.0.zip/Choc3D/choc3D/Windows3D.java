package choc3D;

import java.awt.BorderLayout;

import javax.media.j3d.Background;
import javax.media.j3d.BoundingBox;
import javax.media.j3d.BoundingSphere;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Canvas3D;
import javax.media.j3d.DirectionalLight;
import javax.media.j3d.Group;
import javax.media.j3d.LineArray;
import javax.media.j3d.Shape3D;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.swing.JPanel;
import javax.vecmath.Color3f;
import javax.vecmath.Point3d;
import javax.vecmath.Vector3d;
import javax.vecmath.Vector3f;

import com.sun.j3d.utils.behaviors.mouse.MouseRotate;
import com.sun.j3d.utils.behaviors.mouse.MouseTranslate;
import com.sun.j3d.utils.behaviors.mouse.MouseZoom;
import com.sun.j3d.utils.universe.SimpleUniverse;

public class Windows3D extends JPanel {
	static public float coteCube = 1; // longueur du cote du cube en metre
	static public Group mainGroup = null; //le transform group principal
	
	private WindowsUser windowsUser;
	private Physics phys;
	private Anim animation;
	
	public Windows3D()
	{
		super();
		
		//on initialise la 3D
		setLayout(new BorderLayout());
		Canvas3D canvas3D = new Canvas3D(SimpleUniverse.getPreferredConfiguration());
		add("Center", canvas3D);

		SimpleUniverse simpleU = new SimpleUniverse(canvas3D);
		BranchGroup scene = createSceneGraph();
		
		simpleU.getViewingPlatform().setNominalViewingTransform();
		simpleU.addBranchGraph(scene);
		
		//on initialise la physique du jeu
		phys = new Physics();
		
		//on demarre l'animation
		startAnim();
	}
	
	//on lie les interfaces
	public void link(WindowsUser windowsUser) {
		phys.link(windowsUser);
	}
	
	//on demarre l'animation
	public void startAnim()
	{
		animation = new Anim(phys);
	}
	
	//on arrete l'animation
	public void stopAnim()
	{
		animation.stop();
	}

	private void createBackgroundColor(Group parentG)
	{
		Background background = new Background (0.4f, 0.6f, 0.8f);
	    background.setApplicationBounds (new BoundingBox ());
	    parentG.addChild (background);
	}
	
	private void createLight(Group parentG)
	{
		BoundingSphere largeBounds = new BoundingSphere(new Point3d(0.0,0.0,0.0), 100);
		Vector3f ldir = new Vector3f(1.0f,1.0f,-1.0f);
		Color3f lcouldl = new Color3f(1.0f,1.0f,1.0f);
		DirectionalLight dl = new DirectionalLight(lcouldl,ldir);
		dl.setInfluencingBounds(largeBounds);
		parentG.addChild(dl);
	}
	
	private TransformGroup createMouseBehavior()
	{
		//on permet les mouvements du cube par la souris
		TransformGroup tgMouse = new TransformGroup();
		
		tgMouse.setCapability(TransformGroup.ALLOW_TRANSFORM_READ);
		tgMouse.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		
		BoundingSphere bounds = new BoundingSphere(new Point3d(0.0,0.0,0.0),100.0);
		
		MouseRotate behaviorR = new MouseRotate(tgMouse);
		tgMouse.addChild(behaviorR);
		behaviorR.setSchedulingBounds(bounds);
		
		MouseTranslate behaviorT = new MouseTranslate(tgMouse);
		tgMouse.addChild(behaviorT);
		behaviorT.setSchedulingBounds(bounds);
		
		MouseZoom behaviorZ = new MouseZoom(tgMouse);
		tgMouse.addChild(behaviorZ);
		behaviorZ.setSchedulingBounds(bounds);
		
		return tgMouse;
	}
	
	private TransformGroup createTranslationScene(Group parentG)
	{
		//on centre la scene au milieu du cube
		TransformGroup tgCube = new TransformGroup();
		
		Transform3D trCube = new Transform3D();
		trCube.setTranslation(new Vector3d(-coteCube/2, -coteCube/2, -coteCube/2));
		tgCube.setTransform(trCube);
		
		parentG.addChild(tgCube);
		
		return tgCube;
	}
	
	private void addLineShape(Shape3D obj, Point3d pt1, Point3d pt2)
	{
		Color3f color[] = new Color3f[2];
		Point3d points[] = new Point3d[2];
		
		pt1.scale(Windows3D.coteCube);
		pt2.scale(Windows3D.coteCube);
		
		points[0] = pt1;
		points[1] = pt2;
		color[0] = new Color3f(0,0,1);
		color[1] = new Color3f(0,0,1);
		
		LineArray line = new LineArray(24, LineArray.COORDINATES|LineArray.COLOR_3);
		line.setCoordinates(0, points);
		line.setColors(0, color);
		
		obj.addGeometry(line);
	}
	
	private void createWiredCube(Group parentG)
	{
		Shape3D wiredCube = new Shape3D();
		
		addLineShape(wiredCube, new Point3d(0,0,0), new Point3d(0,0,1));
		addLineShape(wiredCube, new Point3d(0,0,0), new Point3d(0,1,0));
		addLineShape(wiredCube, new Point3d(0,0,0), new Point3d(1,0,0));
		addLineShape(wiredCube, new Point3d(0,1,0), new Point3d(1,1,0));
		addLineShape(wiredCube, new Point3d(0,1,0), new Point3d(0,1,1));
		addLineShape(wiredCube, new Point3d(1,1,0), new Point3d(1,0,0));
		addLineShape(wiredCube, new Point3d(0,1,1), new Point3d(0,0,1));
		addLineShape(wiredCube, new Point3d(1,0,0), new Point3d(1,0,1));
		addLineShape(wiredCube, new Point3d(0,0,1), new Point3d(1,0,1));
		addLineShape(wiredCube, new Point3d(0,1,1), new Point3d(1,1,1));
		addLineShape(wiredCube, new Point3d(1,0,1), new Point3d(1,1,1));
		addLineShape(wiredCube, new Point3d(1,1,0), new Point3d(1,1,1));
		
		parentG.addChild(wiredCube);
	}
	
	private BranchGroup createSceneGraph()
	{
		BranchGroup objRoot = new BranchGroup();
		
		//on cr�e un fond color�
		createBackgroundColor(objRoot);
	    
		//on cree une lumiere
		createLight(objRoot);
		
		//on fait les transformations par la souris
		TransformGroup tgMouse = createMouseBehavior();
		
		//on translate le cube au centre de la scene
		TransformGroup tgCube = createTranslationScene(tgMouse);
		
		//on cree un branchgroup contenant le bg du cube et le bg les billes
		BranchGroup bgRoot = new BranchGroup();
		
		//on cree un branchgroup contenant le cube
		BranchGroup cubeRoot = new BranchGroup();
		
		//on cree un branchgroup contenant les billes
		BranchGroup billesRoot = new BranchGroup();
		
		billesRoot.setCapability(BranchGroup.ALLOW_CHILDREN_WRITE);
		billesRoot.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
		billesRoot.setCapability(BranchGroup.ALLOW_DETACH);
		
		mainGroup = billesRoot;
		
		//on cree le cube
		createWiredCube(cubeRoot);
		
		//on cree les billes
		for(int i=0; i<10; i++)
		{
			Bille.ajouterBilleAleatoirement(billesRoot);
		}
		
		//on cree l'arbre de scene
		bgRoot.addChild(cubeRoot);
		bgRoot.addChild(billesRoot);
		tgCube.addChild(bgRoot);
		objRoot.addChild(tgMouse);
		
		return objRoot;
	}
}
