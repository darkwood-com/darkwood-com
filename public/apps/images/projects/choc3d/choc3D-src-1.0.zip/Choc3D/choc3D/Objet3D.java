package choc3D;

import javax.media.j3d.Group;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Vector3d;


public class Objet3D
{
	protected double masse; // kg
	
	protected Vector3d position; // m 
	protected Vector3d vitesse;  // m/s
	
	protected Group obj;
	protected TransformGroup tg;
	
	public Objet3D()
	{
		masse = 0;
		position = new Vector3d();
		vitesse = new Vector3d();
		
		tg = null;
		this.obj = null;
	}
	
	public Vector3d getPosition()
	{
		return position;
	}
}
