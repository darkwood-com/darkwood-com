package choc3D;

import java.util.ArrayList;
import java.util.Iterator;

import javax.vecmath.Vector3d;

public class Physics
{
	//les calculs ne seront pas pr�cis ou peuvent �tre trop grand, alors on utilise une valeur tres petite devant 1
	static public final double EPSILON = Math.pow(10,-13);
	static public  final double ZERO = EPSILON;
	static public final double HIGH_NUM = 10000; //on prend un nombre tr�s grand
	private WindowsUser windowsUser;
	private Collision collision = null;
	
	private Plan[] planCube; //6 plans du cube
	
	public Physics()
	{
		//on cree les 6 plans du cube
		planCube = new Plan[6];
		planCube[0] = new Plan(new Vector3d(0, 0, 0), new Vector3d(1, 0, 0));
		planCube[1] = new Plan(new Vector3d(0, 0, 0), new Vector3d(0, 1, 0));
		planCube[2] = new Plan(new Vector3d(0, 0, 0), new Vector3d(0, 0, 1));
		planCube[3] = new Plan(new Vector3d(Windows3D.coteCube, Windows3D.coteCube, Windows3D.coteCube), new Vector3d(-1, 0, 0));
		planCube[4] = new Plan(new Vector3d(Windows3D.coteCube, Windows3D.coteCube, Windows3D.coteCube), new Vector3d(0, -1, 0));
		planCube[5] = new Plan(new Vector3d(Windows3D.coteCube, Windows3D.coteCube, Windows3D.coteCube), new Vector3d(0, 0, -1));
	}
	
	//on lie les interfaces
	public void link(WindowsUser windowsUser) {
		this.windowsUser = windowsUser;
	}
	
	public void Simulation(double period) {
		double restTime = period;
		double[] lambda = new double[3]; //lambda[0] = minimum, lambda[1] = temporaire, lambda[2] = minimum precedent
		double[] lastLambda = new double[2];
		lastLambda[0] = HIGH_NUM; //lambda minimum precedent lambda[0]
		lastLambda[1] = HIGH_NUM; //lambda minimum precedent lastLambda[0]
		
		//Variable pour le debuger
		//int occurenceSameLambda = 0; //lambda minimum precedent
		
		ArrayList<Bille> billes;
		Iterator<Bille> it;
		Bille billeCour;
		
		//tant que le temps restant n'est pas �coul� enti�rement
		while(restTime > ZERO)
		{
			lambda[0] = HIGH_NUM;  //on prend un nombre tr�s grand

			billes = Bille.getBilles();
			it = billes.iterator();
			
			//Collision Plan-Bille
			while(it.hasNext())
			{
				billeCour =  it.next();
				
				testCollisionPlan(billeCour, 0, lambda, restTime);
				testCollisionPlan(billeCour, 1, lambda, restTime);
				testCollisionPlan(billeCour, 2, lambda, restTime);
				testCollisionPlan(billeCour, 3, lambda, restTime);
				testCollisionPlan(billeCour, 4, lambda, restTime);
				testCollisionPlan(billeCour, 5, lambda, restTime);
			}
			
			//Collision Bille-Bille
			testCollisionBilles(lambda, restTime);
			
			//on bouge les billes + celle qui a eu une collision (s'il y a collision)
			if(lambda[0] != HIGH_NUM)
			{
				/*-----DEBUG-----
				 * Ce debuger est a decommenter si on supprime la ligne importante dans Bille.testCollisionBille()
				 */
				//on debug les collisions qui bloquerait le programme en changeant lambda
				/*if(lambda[0] == lastLambda[0] || lambda[0] == lastLambda[1])
				{
					lambda[0] += ZERO;
					occurenceSameLambda ++;
					lambda[0] *= occurenceSameLambda;
				}
				else
				{
					lastLambda[1] = lastLambda[0];
					lastLambda[0] = lambda[0];
				}*/
				//-----FIN DEBUG-----
				
				//il y a eu une collision, car lambda[0] n'est plus �gal � HIGH_NUM
				restTime -= lambda[0];
				
				moveAllBilles(lambda[0]);
				
				//faire la collision de la bille concern�e
				collision.collide();
			}
			else
			{
				//il n'y a pas eu de collision, alors on bouge les billes jusqu'� la fin du temps restTime
				moveAllBilles(restTime);
				restTime = 0;
			}
		}
	}

	private void moveAllBilles(double lambda) {
		//on bouge toutes les billes d'un temps lambda
		ArrayList<Bille> billes;
		Iterator<Bille> it;
		
		billes = Bille.getBilles();
		it = billes.iterator();
		while(it.hasNext()) it.next().move(lambda);
	}

	private void testCollisionPlan(Bille billeCour, int i, double[] lambda, double periode)
	{
		if(billeCour.testCollisionPlan(planCube[i], lambda))
		{
			//on prend le minimum des lambdas
			if(lambda[0] >= lambda[1])
			{
				//on ne prend pas lambda[1] si il est plus grand que la periode
				if(lambda[1] <= periode)
				{
					//on enregistre le plus petit lambda
					lambda[0] = lambda[1];
					collision = new CollisionBillePlan(billeCour, planCube[i]);
				}
			}
		}
	}
	
	private void testCollisionBilles(double[] lambda, double periode) {
		int i,j;
		
		ArrayList<Bille> billesList = Bille.getBilles();
		int nb = billesList.size();
		Bille b1, b2;
		
		//Test entre toutes les billes
		for (i = 0; i < nb; i++)
		{
			for (j = i+1; j < nb; j++)
			{
				b1 = billesList.get(i);
				b2 = billesList.get(j);
				
				if(b1.testCollisionBille(b2, lambda))
				{
					//on prend le minimum des lambdas
					if(lambda[0] >= lambda[1])
					{
						//on ne prend pas lambda[1] si il est plus grand que la periode
						if(lambda[1] <= periode)
						{
							//on enregistre le plus petit lambda
							lambda[0] = lambda[1];
							collision = new CollisionBilleBille(b1, b2, windowsUser);
						}
					}
				}
			}
		}
	}
}
