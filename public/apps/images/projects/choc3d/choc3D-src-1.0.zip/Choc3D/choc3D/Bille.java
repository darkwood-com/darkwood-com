package choc3D;

import java.util.ArrayList;
import java.util.Iterator;

import javax.media.j3d.Appearance;
import javax.media.j3d.BranchGroup;
import javax.media.j3d.Group;
import javax.media.j3d.Material;
import javax.media.j3d.Transform3D;
import javax.media.j3d.TransformGroup;
import javax.vecmath.Color3f;
import javax.vecmath.Vector3d;

import com.sun.j3d.utils.geometry.Sphere;

public class Bille extends Objet3D
{
	private static ArrayList<Bille> billes = new ArrayList<Bille>(); //liste des billes
	private static float volumeTotalBilles = 0;
	private float rayon; // m
	private Transform3D tr3D;
	
	static private final double IMPRECISION = Math.pow(10,-9);
	
	private Bille(Vector3d position, Vector3d vitesse, float rayon, double masse, Vector3d couleur, Group parentG)
	{
		super();
		
		BranchGroup bg = new BranchGroup();
		bg.setCapability(BranchGroup.ALLOW_CHILDREN_EXTEND);
		bg.setCapability(BranchGroup.ALLOW_DETACH);
		
		//on regle les vecteurs
		this.position = position;
		this.vitesse = vitesse;
		
		this.rayon = rayon;
		this.masse = masse;
		
		//on initialise les Goupes d'objet
		tg = new TransformGroup();
		tg.setCapability(TransformGroup.ALLOW_TRANSFORM_WRITE);
		tr3D = new Transform3D();
		tr3D.setTranslation(this.position);
		tg.setTransform(tr3D);
		
		//on attribue une couleur
		Appearance app = new Appearance();
		Material mat = new Material();
	    
		Vector3d diffuseVectorColor = couleur;
		Vector3d emissiveVectorColor = new Vector3d(diffuseVectorColor);
		emissiveVectorColor.scale(1f);
		Vector3d ambientVectorColor = new Vector3d(diffuseVectorColor);
		ambientVectorColor.scale(1f);
		
		Color3f ambientColor = new Color3f(ambientVectorColor);
		Color3f emissiveColor = new Color3f(emissiveVectorColor);
		Color3f diffuseColor = new Color3f(diffuseVectorColor);
		Color3f specularColor = new Color3f(1.0f, 1.0f, 1.0f);
		
		mat.setAmbientColor(ambientColor);
		mat.setEmissiveColor(emissiveColor);
	    mat.setDiffuseColor(diffuseColor);
	    mat.setSpecularColor(specularColor);
	    mat.setShininess(128.0f);
		app.setMaterial(mat);
	    
		//on cree l'objet sphere
		this.obj = new Sphere(this.rayon, app);
		
		//on ajoute a l'arboressance Java3D
		this.tg.addChild(this.obj);
		bg.addChild(this.tg);
		parentG.addChild(bg);
		
		//on ajoute a la liste des billes
		this.billes.add(this);
	}
	
	public static ArrayList<Bille> getBilles()
	{
		return Bille.billes;
	}

	
	//indique si la bille a ete ajoutee ou pas
	public static boolean ajouterBille(Group tgCube, Vector3d position, Vector3d vitesse, float rayon, double masse, Vector3d couleur)
	{
		float volNewBille;
		
		//calcul du volume de la sph�re
		volNewBille = (float) (4*Math.PI*Math.pow(rayon, 3)/3);
			
		if(!((volumeTotalBilles + volNewBille) <= 0.75 && peutEtrePlace(position, rayon))) return false;
		
		volumeTotalBilles += volNewBille;
		new Bille(position, vitesse, rayon, masse, couleur, tgCube);
		
		return true;
	}
	
	//on ajoute une nouvelle bille aleatoirement
	public static void ajouterBilleAleatoirement(Group tgCube)
	{
		RandVector3D position, vitesse, couleur;
		float rayon, volNewBille;
		double masse;
		
		position = new RandVector3D();
		vitesse = new RandVector3D();
		
		do
		{
			//calcul des positions et vitesses
			position.randomVector(Windows3D.coteCube);
			vitesse.randomUnsignedVector(Windows3D.coteCube/2000);
			
			//calcul du rayon
			rayon = (float) (Math.random() * 0.05 + 0.05); //0.05 < rayon < 0.1
			
			//calcul du volume de la sph�re
			volNewBille = (float) (4*Math.PI*Math.pow(rayon, 3)/3);
			
			//calcul de la masse qui est proportionnelle au volume de la sphere
			masse = 2 * volNewBille;
			
		}//on r�p�te tant que le volume total est supp�rieur � 75% du cube ou que la place choisie ne convient pas
		while(!((volumeTotalBilles + volNewBille) <= 0.75 && peutEtrePlace(position, rayon)));
		
		couleur = new RandVector3D();
		couleur.randomVector(1.0);
		
		volumeTotalBilles += volNewBille;
		new Bille(position, vitesse, rayon, masse, couleur, tgCube);
	}

	//regarde si on peut placer une sph�re dans le cube � la position indiqu�e
	private static boolean peutEtrePlace(Vector3d position, float rayon)
	{
		Vector3d distanceRayon = new Vector3d();
		Iterator<Bille> it = billes.iterator();
		Bille billeCour;
		while(it.hasNext())
		{
			billeCour = it.next();
			
			distanceRayon.sub(position, billeCour.position);
			//si la distance entre les positions est plus courte que la somme des deux rayons, alors il y a collision
			if(distanceRayon.lengthSquared() <= Math.pow(rayon + billeCour.rayon, 2) + Physics.EPSILON) return false;
		}
		return true;
	}
	
	//on avance la bille : position += vitesse * lambda
	public void move(double lambda)
	{
		position.scaleAdd(lambda, vitesse, position);
	}
	
	//on met a jour les deplacements
	public void updatePos()
	{
		tr3D.setTranslation(this.position);
		tg.setTransform(tr3D);
	}
	
	//collision d'une bille avec un plan
	public void collide(Plan pl)
	{
		Vector3d opositeVitesse = new Vector3d(vitesse);
		opositeVitesse.scale(-1);
		
		double prodScal = 2*opositeVitesse.dot(pl.getNormale());
		
		vitesse.scaleAdd(prodScal, pl.getNormale(), vitesse);
	}
	
	//collision d'une bille avec une bille
	public void collide(Bille b2)
	{
		//calcul de la vitesse relative
		Vector3d v = new Vector3d();
		v.sub(vitesse, b2.vitesse);
		
		//calcul de k
		Vector3d k = new Vector3d();
		k.sub(position, b2.position);
		k.normalize();
		
		//calcul de a
		double a = 2/(1/masse + 1/b2.masse) * k.dot(v);
		
		//calcul des nouvelles vitesses
		vitesse.scaleAdd(-a/masse, k, vitesse);
		b2.vitesse.scaleAdd(a/b2.masse, k, b2.vitesse);
	}
	
	public boolean testCollisionPlan(Plan pl, double[] lamda)
	{
		//produit scalaire entre la normale du plan et la direction de la bille
		double signeDirection = vitesse.dot(pl.getNormale());

		/*
		 * si signeDirection est proche de ZERO, on consid�re qu'il est nul
		 * car le calcul de t donnerai un chiffre extremement grand
		 * 
		 * si le signeDirection > ZERO cela veux dire que la bille va dans la direction oppos�e au plan, il n'y a pas collision
		 */
		
		if ( -Physics.ZERO < signeDirection) return false;
		
		Vector3d deltaPos = new Vector3d();
		deltaPos.sub(pl.getPointPlan(), position);

		double t;
		//on cherche la collision entre la bille et le plan
		t = (pl.getNormale().dot(deltaPos)) / signeDirection;

		/*
		 * nous avons t qui est la collision entre le mileu de la bille et le plan.
		 * ici, on calcule t qui est la collision entre la surface de la bille et le plan
		 * et on enregistre les infos de la collision qui a eu lieu
		 */
		
		//t = t*(1 - rayon/(t*vitesse.length()));
		lamda[1] = t;
		return true;
	}
	
	public boolean testCollisionBille(Bille b2, double[] lambda)
	{		
		//declaration des variables et calcul interm�diaire pour l'optimisation du nombre d'op�rations � effectuer
		Vector3d p = new Vector3d(); //position relative
		p.sub(b2.position, position);
		
		Vector3d v = new Vector3d(); //vitesse relative
		v.sub(b2.vitesse , vitesse);
		
		Vector3d v2 = new Vector3d(v); //vitesse relative au carre
		v2.x *= v2.x;
		v2.y *= v2.y;
		v2.z *= v2.z;
		
		Vector3d vc = new Vector3d(p); //viscosit� cin�matique
		vc.x *= v.x;
		vc.y *= v.y;
		vc.z *= v.z;
		
		double d = rayon + b2.rayon; //distance minimale entre les deux billes
		
		double c = v2.x + v2.y + v2.z;
		double b = 2*(vc.x*vc.y + vc.x*vc.z + vc.y*vc.z) + c * Math.pow(d, 2);
		b -= Math.pow(p.x, 2)*(v2.y + v2.z);
		b -= Math.pow(p.y, 2)*(v2.x + v2.z);
		b -= Math.pow(p.z, 2)*(v2.x + v2.y);
		
		//on regarde si il y a une collision (b >= 0 dans ce cas, pour pouvoir faire b^(1/2))
		if(b < 0) return false;
		//on peut prendre la racine carre de b
		b = Math.sqrt(b);
		//on peut aussi calculer a
		double a = -(vc.x + vc.y + vc.z);

		
		//il y a collision, on cherche le plus petit temps t >= 0 de collision
		double t = Physics.HIGH_NUM, t1, t2; //temps auquel nous avons une collision
		
		t1 = a + b;
		if(t1 >= 0) t = t1;
		
		t2 = a - b;
		if(t2 >= 0)
		{
			//on prend la plus petite valeur de t
			if(t > t2) t = t2;
		}
		
		//si t n'a pas chang� de valeur, alors la collision est dans le sens oppos�
		if(t == Physics.HIGH_NUM) return false;
		
		//on divise le tout par c
		t /= c;
		
		//on sauvegarde la valeur de l'instant t de collision
		lambda[1] = t;
		
		//LIGNE TRES IMPORTANTE : on soustrait une imprecision des calculs de IMPRECISION
		lambda[1] -= lambda[1]*IMPRECISION;
		
		//on renvoie vrai pour dir qu'il y a eu une collision
		return true;
	}
}