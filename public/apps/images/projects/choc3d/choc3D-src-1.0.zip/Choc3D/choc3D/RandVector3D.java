package choc3D;

import javax.vecmath.Vector3d;

public class RandVector3D extends Vector3d
{
	public double[] ramdomXYZ(double redimension)
	{
		double[] random = new double[3];
		
		random[0] = Math.random() * redimension;
		random[1] = Math.random() * redimension;
		random[2] = Math.random() * redimension;
		
		return random;
	}
	
	public double[] ramdomUnsignedXYZ(double redimension) {
		double[] randomUnsigned = ramdomXYZ(2 * redimension);
		
		randomUnsigned[0] -= redimension;
		randomUnsigned[1] -= redimension;
		randomUnsigned[2] -= redimension;
		
		return randomUnsigned;
	}
	
	public void randomVector(double redimension)
	{
		double[] random = ramdomXYZ(redimension);
		
		this.set(random);
	}

	public void randomUnsignedVector(double redimension) {
		double[] randomUnsigned = ramdomUnsignedXYZ(redimension);
		
		this.set(randomUnsigned);
	}
}
