package choc3D;

import java.awt.BorderLayout;

import javax.swing.JApplet;
import javax.swing.JPanel;

import com.sun.j3d.utils.applet.MainFrame;

public class Choc3D extends JApplet {

	public Choc3D()
	{
		super();
		
		Windows3D   windows3D =   new Windows3D();
		WindowsUser windowsUser = new WindowsUser();

		windows3D.link(windowsUser);
		windowsUser.link(windows3D);
		
		this.getContentPane().setLayout(new BorderLayout());
		this.getContentPane().add(windows3D);
		this.getContentPane().add(windowsUser,BorderLayout.SOUTH);
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new MainFrame(new Choc3D(), 570, 570); //on cree la fenetre
	}

}
