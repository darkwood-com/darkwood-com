package choc3D;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.vecmath.Vector3d;

public class WindowsUser extends JPanel implements ActionListener {
	
	private Windows3D windows3D;
	
	private JPanel panelOther;
	private JPanel panelColl;
	private JPanel panelParticule;
	
	private JButton bPlayStop;
	private JButton bErase;
	private JButton bResetColl;
	private JButton bParticleRandAdd;
	private JButton bParticleRandAll;
	private JButton bParticleRandPos;
	private JButton bParticleRandSpeed;
	private JButton bParticleRandMassRadius;
	private JButton bParticleRandColor;
	private JButton bParticleChooseColor;
	
	private JTextField[] tParticlePos;
	private JTextField[] tParticleSpeed;
	private JTextField tParticleRadius;
	private JTextField tParticleMass;
	
	private JLabel lNbColl;
	private JLabel lTxtColl;
	private JLabel lParticle;
	private JLabel lParticlePos;
	private JLabel lParticleSpeed;
	private JLabel lParticleRadius;
	private JLabel lParticleMass;
	private JLabel lParticleColor;
	
	private int nbColl;
	
	public WindowsUser()
	{
		this.nbColl = 0;
		
		this.setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		//creation des labels
		panelOther = new JPanel();
		panelColl = new JPanel();
		panelParticule = new JPanel();
		
		//creation des boutons
		bPlayStop = new JButton("Stop");
		bErase = new JButton("Tout Effacer");
		bResetColl = new JButton("Zero");
		bParticleRandAdd = new JButton("Ajouter");
		bParticleRandAll = new JButton("Aleatoire");
		bParticleRandPos = new JButton("Aleatoire");
		bParticleRandSpeed = new JButton("Aleatoire");
		bParticleRandMassRadius = new JButton("Aleatoire");
		bParticleRandColor = new JButton("Aleatoire");
		bParticleChooseColor = new JButton("Choisir");
		bParticleChooseColor.setBorder(null);
		
		//creation des champs texte
		tParticlePos = new JTextField[3];
		tParticleSpeed = new JTextField[3];
		tParticleRadius = new JTextField();
		tParticleMass = new JTextField();
		
		//creation des labels
		lNbColl = new JLabel("0");
		lTxtColl = new JLabel("Nombres de collisions");
		lParticle = newCenterLabel("Particule");
		lParticlePos = newCenterLabel("Position");
		lParticleSpeed = newCenterLabel("Vitesse");
		lParticleRadius = newCenterLabel("Rayon");
		lParticleMass = newCenterLabel("Masse");
		lParticleColor = newCenterLabel("Couleur");
		
		//ajout des layouts
		panelOther.setLayout(new FlowLayout());
		panelColl.setLayout(new FlowLayout());
		panelParticule.setLayout(new GridLayout(3,5,5,0));
		
		//evenements sur les boutons
		bPlayStop.addActionListener(this);
		bErase.addActionListener(this);
		bResetColl.addActionListener(this);
		bParticleRandAdd.addActionListener(this);
		bParticleRandAll.addActionListener(this);
		bParticleRandPos.addActionListener(this);
		bParticleRandSpeed.addActionListener(this);
		bParticleRandMassRadius.addActionListener(this);
		bParticleRandColor.addActionListener(this);
		bParticleChooseColor.addActionListener(this);
		
		//on ajoute les composants
		panelOther.add(bPlayStop);
		panelOther.add(bErase);
		
		panelColl.add(lTxtColl);
		panelColl.add(lNbColl);
		panelColl.add(bResetColl);
		
		panelParticule.add(lParticle);
		panelParticule.add(lParticlePos);
		panelParticule.add(lParticleSpeed);
		panelParticule.add(coord2JComponent(lParticleRadius,lParticleMass));
		panelParticule.add(lParticleColor);
		panelParticule.add(bParticleRandAdd);
		panelParticule.add(coord3TextField(tParticlePos));
		panelParticule.add(coord3TextField(tParticleSpeed));
		panelParticule.add(coord2JComponent(tParticleRadius,tParticleMass));
		panelParticule.add(bParticleChooseColor);
		panelParticule.add(bParticleRandAll);
		panelParticule.add(bParticleRandPos);
		panelParticule.add(bParticleRandSpeed);
		panelParticule.add(bParticleRandMassRadius);
		panelParticule.add(bParticleRandColor);
		
		this.add(panelOther);
		this.add(panelColl);
		this.add(panelParticule);
	}

	//on cree un nouveau label centre
	private JLabel newCenterLabel(String txt)
	{
		JLabel label = new JLabel(txt);
		label.setHorizontalAlignment(JLabel.CENTER);
		return label;
	}
	
	//on cree 2 JComponent dans un JPanel
	private JPanel coord2JComponent(JComponent c1, JComponent c2)
	{
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1,2,5,0));

		panel.add(c1);
		panel.add(c2);
		
		return panel;
	}
	
	//on cree 3 JTextField dans un JPanel
	private JPanel coord3TextField(JTextField[] textField)
	{
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(1,3,5,0));
		
		textField[0] = new JTextField();
		textField[1] = new JTextField();
		textField[2] = new JTextField();

		panel.add(textField[0]);
		panel.add(textField[1]);
		panel.add(textField[2]);
		
		return panel;
	}
	
	//on lie les interfaces
	public void link(Windows3D windows3D) {
		this.windows3D = windows3D;
	}
	
	//on incremente le nombre de collisions entre particules
	public void incrementColl() {
		nbColl ++;
		lNbColl.setText(String.valueOf(nbColl));
	}
	
	//on remet a zero le nombre de collisions entre particules
	private void resetColl() {
		nbColl = 0;
		lNbColl.setText(String.valueOf(nbColl));
	}
	
	//gestion des evenements sur les clics des boutons
	public void actionPerformed(ActionEvent e) {
		JButton evenSource = (JButton)e.getSource();
		if(evenSource == bPlayStop){
			//on regarde le mode (play ou stop) du bouton
			if(evenSource.getText().equals("Stop"))
			{
				evenSource.setText("Jouer");
				windows3D.stopAnim();
			}
			else
			{
				evenSource.setText("Stop");
				windows3D.startAnim();
			}
		} else if(evenSource == bErase){
			//on retire toutes les particules de l'animation
			Bille.getBilles().removeAll(Bille.getBilles());
			
			//on detruit l'arbre de scene des billes
			Windows3D.mainGroup.removeAllChildren();
		} else if(evenSource == bResetColl){
			//on remet a zero le nombre de collisions entre particules
			resetColl();
		} else if(evenSource == bParticleRandAdd){
			//on ajoute la particule de facon entierement definie
			Vector3d position, vitesse, couleur;
			float rayon;
			double masse;
			double[] vecteur = new double[3];
			
			vecteur[0] = Double.valueOf(tParticlePos[0].getText());
			vecteur[1] = Double.valueOf(tParticlePos[1].getText());
			vecteur[2] = Double.valueOf(tParticlePos[2].getText());
			position = new Vector3d(vecteur);
			
			vecteur[0] = Double.valueOf(tParticleSpeed[0].getText());
			vecteur[1] = Double.valueOf(tParticleSpeed[1].getText());
			vecteur[2] = Double.valueOf(tParticleSpeed[2].getText());
			vitesse = new Vector3d(vecteur);
			
			rayon = Float.valueOf(tParticleRadius.getText());
			masse = Double.valueOf(tParticleMass.getText());
			
			vecteur[0] = bParticleChooseColor.getBackground().getRed()/255.0;
			vecteur[1] = bParticleChooseColor.getBackground().getGreen()/255.0;
			vecteur[2] = bParticleChooseColor.getBackground().getBlue()/255.0;
			couleur = new Vector3d(vecteur);
			
			
			Bille.ajouterBille(Windows3D.mainGroup, position, vitesse, rayon, masse, couleur);
		} else if(evenSource == bParticleRandAll){
			//on ajoute la particule aleatoirement
			RandVector3D position, vitesse, couleur;
			float rayon, volNewBille;
			double masse;
			
			position = new RandVector3D();
			vitesse = new RandVector3D();
			couleur = new RandVector3D();

			couleur.randomVector(1.0);
			do
			{
				//calcul des positions et vitesses
				position.randomVector(Windows3D.coteCube);
				vitesse.randomUnsignedVector(Windows3D.coteCube/2000);
				
				//calcul du rayon
				rayon = (float) (Math.random() * 0.05 + 0.05); //0.05 < rayon < 0.1
				
				//calcul du volume de la sph�re
				volNewBille = (float) (4*Math.PI*Math.pow(rayon, 3)/3);
				
				//calcul de la masse qui est proportionnelle au volume de la sphere
				masse = 2 * volNewBille;
				
			}//on r�p�te tant que l'on a pas pu ajoute la particule
			while(!Bille.ajouterBille(Windows3D.mainGroup, position, vitesse, rayon, masse, couleur));
			
			//on met a jour les infos de l'ajout sur la fenetre utilisateur
			tParticlePos[0].setText(String.valueOf(position.x));
			tParticlePos[1].setText(String.valueOf(position.y));
			tParticlePos[2].setText(String.valueOf(position.z));
			
			tParticleSpeed[0].setText(String.valueOf(vitesse.x));
			tParticleSpeed[1].setText(String.valueOf(vitesse.y));
			tParticleSpeed[2].setText(String.valueOf(vitesse.z));
			
			tParticleRadius.setText(String.valueOf(rayon));
			tParticleMass.setText(String.valueOf(masse));
			
			Color color = new Color((float)couleur.x, (float)couleur.y, (float)couleur.z);
			bParticleChooseColor.setBackground(color);
		} else if(evenSource == bParticleRandPos){
			RandVector3D randVector3DPos = new RandVector3D();
			
			double[] randPos = randVector3DPos.ramdomXYZ(Windows3D.coteCube);
			
			tParticlePos[0].setText(String.valueOf(randPos[0]));
			tParticlePos[1].setText(String.valueOf(randPos[1]));
			tParticlePos[2].setText(String.valueOf(randPos[2]));
		} else if(evenSource == bParticleRandSpeed){
			RandVector3D randVector3DPos = new RandVector3D();
			
			double[] randPos = randVector3DPos.ramdomUnsignedXYZ(Windows3D.coteCube/2000);
			
			tParticleSpeed[0].setText(String.valueOf(randPos[0]));
			tParticleSpeed[1].setText(String.valueOf(randPos[1]));
			tParticleSpeed[2].setText(String.valueOf(randPos[2]));
		} else if(evenSource == bParticleRandMassRadius){
			float rayon, volNewBille;
			double masse;
			
			//calcul du rayon
			rayon = (float) (Math.random() * 0.05 + 0.05); //0.05 < rayon < 0.1
			
			//calcul du volume de la sph�re
			volNewBille = (float) (4*Math.PI*Math.pow(rayon, 3)/3);
			
			//calcul de la masse qui est proportionnelle au volume de la sphere
			masse = 2 * volNewBille;
			
			tParticleRadius.setText(String.valueOf(rayon));
			tParticleMass.setText(String.valueOf(masse));
		} else if(evenSource == bParticleRandColor){
			RandVector3D randVector3DPos = new RandVector3D();
			double[] randPos = randVector3DPos.ramdomXYZ(Windows3D.coteCube);
			
			Color color = new Color((float)randPos[0], (float)randPos[1], (float)randPos[2]);
			
			bParticleChooseColor.setBackground(color);
		} else if(evenSource == bParticleChooseColor){
			Color colorchoosed = JColorChooser.showDialog(this, "Choisissez votre couleur", bParticleChooseColor.getBackground());
			if(colorchoosed != null) //appui sur ok
			{
				bParticleChooseColor.setBackground(colorchoosed);
			}
		}
	}
}
