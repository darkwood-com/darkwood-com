package choc3D;

public abstract class Collision {

	abstract public void collide();

}
