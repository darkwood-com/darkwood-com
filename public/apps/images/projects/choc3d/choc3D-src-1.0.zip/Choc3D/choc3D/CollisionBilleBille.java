package choc3D;

public class CollisionBilleBille extends Collision {

	private WindowsUser windowsUser;
	private Bille b1, b2;
	
	CollisionBilleBille(Bille b1, Bille b2, WindowsUser windowsUser)
	{
		this.b1 = b1;
		this.b2 = b2;
		this.windowsUser = windowsUser;
	}
	
	public void collide()
	{
		b1.collide(b2);
		
		windowsUser.incrementColl();
	}
}
