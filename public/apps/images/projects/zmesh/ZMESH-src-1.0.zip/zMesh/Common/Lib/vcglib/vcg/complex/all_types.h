#ifndef VCG_ALL_TYPES_H
#define VCG_ALL_TYPES_H

namespace vcg{

struct AllTypes{
		struct AVertexType {};
		struct AEdgeType {};
		struct AFaceType {};
		struct AHEdgeType {};
};


};

#endif // USED_TYPES_H
