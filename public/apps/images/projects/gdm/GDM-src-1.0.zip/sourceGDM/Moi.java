import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Moi extends Joueur {
	
	/**
	 * @uml.property  name="pieceCourante"
	 * @uml.associationEnd  inverse="moi:FaceTuile"
	 * @uml.association  name="pieceCourante"
	 */
	private FaceTuile pieceCourante;
	
	/**
	 * Getter of the property <tt>faceTuile</tt>
	 * @return  Returns the faceTuile.
	 * @uml.property  name="faceTuile"
	 */
	public FaceTuile getPieceCourante() {
		return pieceCourante;
	}
	
	/**
		* Setter of the property <tt>faceTuile</tt>
	 * @param faceTuile  The faceTuile to set.
	 * @uml.property  name="faceTuile"
	 */
	public void setPieceCourante(FaceTuile faceTuile) {
		this.pieceCourante = faceTuile;
	}
	
	/**
	 * Pour savoir si notre berger a �t� pos�
	 */
	private boolean aPoseBerger=false;
	
	/**
	 * a appeler quand on pose notre berger
	 *
	 */
	public void poseBerger(){
		aPoseBerger=true;
	}
	
	/**
	 * @return true si le berger est pose
	 */
	public boolean bergerPose(){
		return aPoseBerger;
	}
	
	/**
		* @uml.property  name="maMain"
	 * @uml.associationEnd  multiplicity="(0 -1)" inverse="moi:FaceTuile"
	 * @uml.association  name="maMain"
	 */
	private Collection maMain;
	
	/**
		* Getter of the property <tt>faceTuile1</tt>
	 * @return  Returns the faceTuile1.
	 * @uml.property  name="faceTuile1"
	 */
	public Collection getMaMain() {
		return maMain;
	}
	
	/**
	 * @param numCase commence a 0
	 * @return la Face tuile courante
	 */
	public FaceTuile getPieceMain(int numCase){
		if (numCase >= maMain.size()){
			return null;
		}
		else return (FaceTuile)(((ArrayList)maMain).get(numCase));
	}
	
	/**
	* ajouter une piece a sa main
	* @param piece
	*/
	public void addPieceMain(FaceTuile piece){
		maMain.add(piece);
	}
	
	/**
	* supprimer la piece courante de sa main, c'est a dire qu'on l'a pose sur le plateau, on la supprime donc aussi de son jeu de carte
	* @param piece
	*/
	public void supprimerPieceCourante() {
		//on supprime la piece courante de son jeu
		maMain.remove(getPieceCourante());
		
		//on supprime la piece courante de sa main
		setPieceCourante(null);
		
	}
	
	/**
	 * mettre la piece courante de son jeu de carte dans sa main
	 * @return vrai si on a bien pris la piece choisie dans notre main, non si on a plus de carte
	 * @param numCase est le numero de la piece choisie
	 */
	public boolean prendrePieceMain(int numCase){
		FaceTuile tempFT=getPieceMain(numCase);
		
		if(tempFT == null) return false;
		else
		{
			setPieceCourante(tempFT);
			return true;
		}
	}
	
	
	public Moi() {
		maMain = new ArrayList();
	}
	/**
	 * 
	 * @return vrai si on une piece dans la main, faux sinon
	 */
	public boolean rotationPiece(){
		if(pieceCourante != null) {
			pieceCourante.rotation();
			return true;
		}
		else return false;
	}
	
	/**
	 * 
	 * @return vrai si on a une piece dans la main, faux sinon
	 */
	public boolean retournerPiece(){
		if(pieceCourante != null) {
			Iterator it = maMain.iterator();
			int i=0;
			FaceTuile tuileMainCourante = (FaceTuile)it.next();
			while(it.hasNext() && pieceCourante != tuileMainCourante){
				tuileMainCourante = (FaceTuile)it.next();
				i++;
			}
			((ArrayList)maMain).set(i,tuileMainCourante.getFaceTuileSuivant());
			pieceCourante = tuileMainCourante.getFaceTuileSuivant();
			return true;
		}
		else return false;
	}
	
	public void afficherMain() {
		Iterator it = maMain.iterator();
		System.out.println("Afficher ma main");
		while(it.hasNext()) {
			((FaceTuile)it.next()).afficheFaceTerminal();
		}
		System.out.println();
	}
	
	public void reinit(){
		super.reinit();
		aPoseBerger=false;
		maMain=new ArrayList();
	}
}


