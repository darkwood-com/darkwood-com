import java.util.ArrayList;
import java.util.Collection;

public class Plateau {

	public static final int nbX=50;
	public static final int nbY=50;
	
	/**
	 * la collection contient un tableau a 3 dimentions contentant dans l'ordre un objet FaceTuile, la coordonne x et y
	 * @uml.property  name="faceTuile"
	 * @uml.associationEnd  multiplicity="(0 -1)" inverse="plateau:FaceTuile"
	 * @uml.association  name="estPose"
	 */
	private FaceTuile[][] tuilePlateau;
	
	private int xMax, yMax;
	
	/**
	 * recuperer la variable xMax
	 */
	public int getXMax() {
		return xMax;
	}
	
	/**
	 * recuperer la variable yMax
	 */
	public int getYMax() {
		return yMax;
	}
	
	/**
	 * recuperer la variable tuilePlateau a la coordonnee x et y
	 * @param les coordonnees x et y sont celle de la tuile du plateau a recuperer
	 */
	public FaceTuile getTuilePlateau(int x, int y) {
		return tuilePlateau[x][y];
	}
	
	/**
	 * @param les coordonnees x et y sont celle de la premiere piece a a jouter sur le plateau
	 * @uml.property  name="faceTuile"
	 */
	public Plateau(FaceTuile piece) {
		Collection premiereTuile = new ArrayList();
		
		xMax = nbX;
		yMax = nbY;
		
		tuilePlateau = new FaceTuile[xMax][yMax];
		
		for(int i = 0; i < xMax; i++)
		{
			for(int j = 0; j < yMax; j++)
			{
				tuilePlateau[i][j] = null;
			}
		}
		
		tuilePlateau[(int)(xMax/2)][(int)(yMax/2)] = piece;
	}
	
	/**
	 * affiche l'etat du plateau
	 */
	public void afficherPlateau() {
		System.out.println("afficher plateau");
		for(int i = 0; i < getXMax(); i++)
		{
			for(int j = 0; j < getYMax(); j++)
			{
				if(getTuilePlateau(i,j) != null)
				{
					System.out.println("position x = "+i+" y = "+j);
					getTuilePlateau(i,j).afficheFaceTerminal();
				}
			}
		}
		System.out.println();
	}

	/**
	 * verifier si on peut ajouter une piece sur le plateau a la coordonnee x et y
	 * @param x et y sont les coordonnee de la piece a ajouter, pieceCourante est la piece que l'on veut ajouter
	 * @return renvoie vrai si on peut ajouter la piece a l'endroit indique, faux sinon
	 */
	public boolean peutAjouterPiece(int x, int y, FaceTuile pieceCourante){
		
		boolean peutAjouter = true;
		boolean aTuileVoisin = false;
		
		//si x et y corrects
		if(x<0 || y<0 || x>=nbX || y>=nbY){ return false; }
		
		//si sur une tuile
		if(tuilePlateau[x][y] != null) return false;

		//si loup, on regarde si il n'y a pas de chasseur
		if(pieceCourante.getType().equals("Speciale") ){
			//si loup (car je sais pas pourquoi mais getEstChasseur retourne false si c'estr un chasseur)
			if( ((FaceSpeciale)pieceCourante).getEstChasseur() ){
				//si il y a un chasseur dans la meme foret, alors pas ok
				MyInt temp=new MyInt(0);
				ArrayList coteAInit=new ArrayList();
				comptagePointBasForet( x, y-1, temp, coteAInit);
				//on reinit la foret
				for(int i=0;i<coteAInit.size();i++){
					((Cote)coteAInit.get(i)).resetComptage();
				}
				if(temp.entier!=-1){
					temp.entier=0;
					coteAInit=new ArrayList();
					comptagePointGaucheForet( x+1, y, temp, coteAInit);
					//on reinit la foret
					for(int i=0;i<coteAInit.size();i++){
						((Cote)coteAInit.get(i)).resetComptage();
					}

					if(temp.entier!=-1){
						temp.entier=0;
						coteAInit=new ArrayList();
						comptagePointHautForet( x, y+1, temp, coteAInit);
						//on reinit la foret
						for(int i=0;i<coteAInit.size();i++){
							((Cote)coteAInit.get(i)).resetComptage();
						}

						if(temp.entier!=-1){
							temp.entier=0;
							coteAInit=new ArrayList();
							comptagePointDroiteForet( x-1, y, temp, coteAInit);
							//on reinit la foret
							for(int i=0;i<coteAInit.size();i++){
								((Cote)coteAInit.get(i)).resetComptage();
							}
						}
					}
				}
				
				//donc, si on a trouve un chasseur, pas bon
				if(temp.entier==-1){
					return false;
				}
			}
		}
		
		if(tuilePlateau[x][y+1] != null)
		{
			aTuileVoisin = true;
			if(tuilePlateau[x][y+1].getCouleurCote(3) != pieceCourante.getCouleurCote(1)) peutAjouter = false;
		}
		if(tuilePlateau[x+1][y] != null)
		{
			aTuileVoisin = true;
			if(tuilePlateau[x+1][y].getCouleurCote(4) != pieceCourante.getCouleurCote(2)) peutAjouter = false;
		}
		if(tuilePlateau[x][y-1] != null)
		{
			aTuileVoisin = true;
			if(tuilePlateau[x][y-1].getCouleurCote(1) != pieceCourante.getCouleurCote(3)) peutAjouter = false;
		}
		if(tuilePlateau[x-1][y] != null)
		{
			aTuileVoisin = true;
			if(tuilePlateau[x-1][y].getCouleurCote(2) != pieceCourante.getCouleurCote(4)) peutAjouter = false;
		}
		
		
		//on ne peut pas ajouter de piece si il n'y a pas de piece voisines a cote
		if((aTuileVoisin == false) && (peutAjouter == true)) peutAjouter = false;
		
		return peutAjouter;
	}
	
	/**
	 * verifier avant si on peut ajouter une piece sur le plateau a la coordonnee x et y
	 * @param x et y sont les coordonnee de la piece a ajouter, pieceCourante est la piece que l'on veut ajouter
	 * @return renvoie vrai si on peut ajouter la piece a l'endroit indique, faux sinon
	 */
	public int ajoutPieceTab(int x, int y, FaceTuile pieceCourante){
		
		tuilePlateau[x][y] = pieceCourante;
		
		int nombrePiece = 0;
		
		if(tuilePlateau[x][y+1] != null) nombrePiece++;
		if(tuilePlateau[x+1][y] != null) nombrePiece++;
		if(tuilePlateau[x][y-1] != null) nombrePiece++;
		if(tuilePlateau[x-1][y] != null) nombrePiece++;
		
		return nombrePiece;
	}
	
	/**
	 * ajouter une piece sur le plateau a la coordonnee x et y
	 * @param x et y sont les coordonnee de la piece a ajouter, pieceCourante est la piece que l'on veut ajouter
	 * @return le nombre de piece que l'on recupere pour la pioche dans le cas ou on a pu ajoute la piece, 0 sinon
	 */
	public int ajoutTuile(int x, int y, FaceTuile pieceAAjouter){
		//regarder si on peut ajouter la pieceCourante sur le plateau a la coordonnee x et y
		if (peutAjouterPiece(x, y, pieceAAjouter) == false){
			System.out.println("Impossible d'ajouter cette pi�ce � cette place-la.");
			return 0;
		}
		
		//ajouter la piece et calculer le nombre de piece qu'il y a a cote pour la pioche
		return ajoutPieceTab(x, y, pieceAAjouter);
	}
	
	/**
	 * compte le nombre de points. ie le plus grnad enclos ferm�.
	 * @param couleur couleur � compter
	 * @return
	 */
	public int compterPoints(int couleur){
		if(couleur<0 || couleur>3){ return 0; }
		
		//initialisation
		for(int i=0;i<nbX;i++){
			for(int j=0;j<nbY; j++){
				if(tuilePlateau[i][j] != null){
					tuilePlateau[i][j].getCoteBas().resetComptage();
					tuilePlateau[i][j].getCoteHaut().resetComptage();
					tuilePlateau[i][j].getCoteDroite().resetComptage();
					tuilePlateau[i][j].getCoteGauche().resetComptage();
				}
			}
		}
		
		
		int pointsMax=0;
		MyInt temp=new MyInt(0);
		//pour chaque cote de chaque case.
		for(int i=0;i<nbX;i++){
			for(int j=0;j<nbY; j++){
				temp.entier=0;
				comptagePointBas(couleur,i,j,temp);
				if(temp.entier>pointsMax){ pointsMax=temp.entier; }
				temp.entier=0;
				comptagePointDroite(couleur,i,j,temp);
				if(temp.entier>pointsMax){ pointsMax=temp.entier; }
				temp.entier=0;
				comptagePointHaut(couleur,i,j,temp);
				if(temp.entier>pointsMax-1){ pointsMax=temp.entier; }
				temp.entier=0;
				comptagePointGauche(couleur,i,j,temp);
				if(temp.entier>pointsMax){ pointsMax=temp.entier; }
			}
		}
		
		
		return pointsMax;
	}
	
	
	//pour compter les point, on regarde chaque cote de case r�cursivament;
	private void comptagePointBas(int coul, int x, int y, MyInt nbPointDeja){
		//si existe
		if(x>=0 && x<nbX && y>=0 && y<nbY && tuilePlateau[x][y]!=null){
			//si pas deja regard�
			if(tuilePlateau[x][y].getCoteBas().pasDejaCompte()){
				//et si de la bonne couleur
				if(tuilePlateau[x][y].getCoteBas().getCouleur()==coul){
					//si pas de sortie de virage
					if(nbPointDeja.entier!=-1){ 
						//on ajoute un point
						nbPointDeja.entier++; 
						//System.err.println("+ en bas de x="+x+", y="+y);
					}
					//on dique que l'on a deja vu cette case
					tuilePlateau[x][y].getCoteBas().compte();
					//alors, ok
					//on regarde devant nous
					comptagePointHaut(coul,x,y+1,nbPointDeja);
					//on fait de meme pour touts les autres cot�s de la case (meme enclos que nous)
					comptagePointDroite(coul,x,y,nbPointDeja);
					comptagePointHaut(coul,x,y,nbPointDeja); //seulement haut et bas impossible-> pas de tests a effectuer
					comptagePointGauche(coul,x,y,nbPointDeja);
				}else{
					//on regarde si foret
					if(tuilePlateau[x][y].getCoteBas().getCouleur()==Cote.FORET){
						//on regarde si foret loup sans chasseur
						MyInt temp=new MyInt(0);
						ArrayList coteAInit=new ArrayList();
						comptagePointBasForet( x, y, temp, coteAInit);
						//on reinit la foret
						for(int i=0;i<coteAInit.size();i++){
							((Cote)coteAInit.get(i)).resetComptage();
						}
						//sauf nous
						tuilePlateau[x][y].getCoteBas().compte();
						//System.err.println("resultatB="+temp.entier);
						//et on regarde resultat
						if(temp.entier>0){//si loup
							nbPointDeja.entier=0-1;
						}//sinon, pas de problemes
					}else{
						//on dit que que l'on a deja vu cette case
						tuilePlateau[x][y].getCoteBas().compte();
						//System.err.println("bas, x="+x+", y="+y+"pas bonne coul");
					}
				}
			}
		}else{//pas de bordure -> tous l'enclos est "mort"
			nbPointDeja.entier=-1;
		}
	}
	
	private void comptagePointBasForet(int x, int y, MyInt nbLoup, ArrayList coteAInit) {
//		si existe (et pas trouv� de chasseur) 
		if(x>=0 && x<nbX && y>=0 && y<nbY && tuilePlateau[x][y]!=null && nbLoup.entier!=-1){
			//si pas deja regard�
			if(tuilePlateau[x][y].getCoteBas().pasDejaCompte()){
				//et si de la bonne couleur
				if(tuilePlateau[x][y].getCoteBas().getCouleur()==Cote.FORET){
					//si case speciale
					if(tuilePlateau[x][y].getType().equals("Speciale")){
						//System.err.println("entree case spe"+" a x="+x+", y="+y);
						//si chasseur
						if( !((FaceSpeciale)tuilePlateau[x][y]).getEstChasseur()){
							//System.err.println("entree case chass");
							nbLoup.entier=0-1;
						}else{//si loup
							//System.err.println("entree case loup");
							if(nbLoup.entier!=-1){ 
								//on ote un point
								nbLoup.entier++;
							} 
							//on peut encore voir un chasseur, on continue de regarder
							tuilePlateau[x][y].getCoteBas().compte();
							tuilePlateau[x][y].getCoteGauche().compte();
							tuilePlateau[x][y].getCoteDroite().compte();
							tuilePlateau[x][y].getCoteHaut().compte();
							coteAInit.add(tuilePlateau[x][y].getCoteBas());
							coteAInit.add(tuilePlateau[x][y].getCoteGauche());
							coteAInit.add(tuilePlateau[x][y].getCoteDroite());
							coteAInit.add(tuilePlateau[x][y].getCoteHaut());

							comptagePointBasForet(x,y-1,nbLoup,coteAInit);
							comptagePointDroiteForet(x-1,y,nbLoup,coteAInit);
							comptagePointHautForet(x,y+1,nbLoup,coteAInit);
							comptagePointGaucheForet(x+1,y,nbLoup,coteAInit);
						}
					}else{
						//System.err.println("entree case B"+tuilePlateau[x][y].getType()+" a x="+x+", y="+y);
//						on dique que l'on a deja vu cette case
						tuilePlateau[x][y].getCoteBas().compte();
						//System.err.println("B x="+x+", y="+y);
						coteAInit.add(tuilePlateau[x][y].getCoteBas());
						//alors, ok
						//on regarde devant nous
						comptagePointHautForet(x,y+1,nbLoup,coteAInit);
						//on fait de meme pour touts les autres cot�s de la case (meme enclos que nous)
						comptagePointDroiteForet(x,y,nbLoup,coteAInit);
						comptagePointHautForet(x,y,nbLoup,coteAInit); //seulement haut et bas impossible-> pas de tests a effectuer
						comptagePointGaucheForet(x,y,nbLoup,coteAInit);
					}
					
				}//sinon (si pas foret) , on s'en fout
				//else{System.err.println("pas forete B"+" a x="+x+", y="+y);}
			}
			//else{System.err.println("deja compt� B"+" a x="+x+", y="+y);}
		}//pas de bordure -> pas grave, on regarde si chasseur / loup
		//else{System.err.println("pas bordure B"+" a x="+x+", y="+y);}
	}

	private void comptagePointDroite(int coul, int x, int y, MyInt nbPointDeja){
		//si existe
		if(x>=0 && x<nbX && y>=0 && y<nbY && tuilePlateau[x][y]!=null){
			//si pas deja regard�
			if(tuilePlateau[x][y].getCoteDroite().pasDejaCompte()){
				//et si de la bonne couleur
				if(tuilePlateau[x][y].getCoteDroite().getCouleur()==coul){
					//si pas de sortie de virage, +1
					if(nbPointDeja.entier!=-1){ 
						nbPointDeja.entier++; 
						//System.err.println("+ a Droite de x="+x+", y="+y);
					}
					//on dique que l'on a deja vu cette case
					tuilePlateau[x][y].getCoteDroite().compte();
					//alors, ok
					//on regarde devant nous
					comptagePointGauche(coul,x+1,y,nbPointDeja);
					//on fait de meme pour touts les autres cot�s de la case (meme enclos que nous)
					comptagePointHaut(coul,x,y,nbPointDeja); //seulement Gauche et Droite impossible-> pas de tests a effectuer
					comptagePointGauche(coul,x,y,nbPointDeja);
					comptagePointBas(coul,x,y,nbPointDeja);
				}else{
					//on regarde si foret
					if(tuilePlateau[x][y].getCoteDroite().getCouleur()==Cote.FORET){
						//on regarde si foret loup sans chasseur
						MyInt temp=new MyInt(0);
						ArrayList coteAInit=new ArrayList();
						comptagePointDroiteForet( x, y, temp, coteAInit);
						//on reinit la foret
						for(int i=0;i<coteAInit.size();i++){
							((Cote)coteAInit.get(i)).resetComptage();
						}
						//sauf nous
						tuilePlateau[x][y].getCoteDroite().compte();
						//System.err.println("resultatD="+temp.entier);
						//et on regarde resultat
						if(temp.entier>0){//si loup
							nbPointDeja.entier=0-1;
						}//sinon, pas de problemes
					}else{
						//on dique que l'on a deja vu cette case
						tuilePlateau[x][y].getCoteDroite().compte();
						//System.err.println("Droite, x="+x+", y="+y+"pas bonne coul");
					}
				}
			}
		}else{//pas de bordure -> tous l'enclos est "mort"
			nbPointDeja.entier=-1;
		}
	}
	
	private void comptagePointDroiteForet(int x, int y, MyInt nbLoup, ArrayList coteAInit) {
//		si existe
		if(x>=0 && x<nbX && y>=0 && y<nbY && tuilePlateau[x][y]!=null && nbLoup.entier!=-1){
			//si pas deja regard�
			if(tuilePlateau[x][y].getCoteDroite().pasDejaCompte()){
				//et si de la bonne couleur
				if(tuilePlateau[x][y].getCoteDroite().getCouleur()==Cote.FORET){
//					si case speciale
					if(tuilePlateau[x][y].getType().equals("Speciale")){
						//System.err.println("entree case spe"+" a x="+x+", y="+y);
						//si chasseur
						if( !((FaceSpeciale)tuilePlateau[x][y]).getEstChasseur()){
							//System.err.println("entree case chass");
							nbLoup.entier=0-1;
						}else{//si loup
							//System.err.println("entree case loup");
							if(nbLoup.entier!=-1){ 
								//on ote un point
								nbLoup.entier++;
							} 
							//on peut encore voir un chasseur, on continue de regarder
							tuilePlateau[x][y].getCoteBas().compte();
							tuilePlateau[x][y].getCoteGauche().compte();
							tuilePlateau[x][y].getCoteDroite().compte();
							tuilePlateau[x][y].getCoteHaut().compte();
							coteAInit.add(tuilePlateau[x][y].getCoteBas());
							coteAInit.add(tuilePlateau[x][y].getCoteGauche());
							coteAInit.add(tuilePlateau[x][y].getCoteDroite());
							coteAInit.add(tuilePlateau[x][y].getCoteHaut());

							comptagePointBasForet(x,y-1,nbLoup,coteAInit);
							comptagePointDroiteForet(x-1,y,nbLoup,coteAInit);
							comptagePointHautForet(x,y+1,nbLoup,coteAInit);
							comptagePointGaucheForet(x+1,y,nbLoup,coteAInit);
						}
					}else{
						//System.err.println("entree case D"+tuilePlateau[x][y].getType()+" a x="+x+", y="+y);
						//on dique que l'on a deja vu cette case
						tuilePlateau[x][y].getCoteDroite().compte();
						//System.err.println("D x="+x+", y="+y);
						coteAInit.add(tuilePlateau[x][y].getCoteDroite());
						//alors, ok
						//on regarde devant nous
						comptagePointGaucheForet(x+1,y,nbLoup,coteAInit);
						//on fait de meme pour touts les autres cot�s de la case (meme enclos que nous)
						comptagePointHautForet(x,y,nbLoup,coteAInit);
						comptagePointGaucheForet(x,y,nbLoup,coteAInit); //seulement haut et bas impossible-> pas de tests a effectuer
						comptagePointBasForet(x,y,nbLoup,coteAInit);
					}
				}//sinon (si pas foret) , on s'en fout
				//else{System.err.println("pas forete D"+" a x="+x+", y="+y);}
			}
			//else{System.err.println("deja compt� D"+" a x="+x+", y="+y);}
		}//pas de bordure -> pas grave car on regarde si chasseur / loup
		//else{System.err.println("pas bordure D"+" a x="+x+", y="+y);}
	}
	
	private void comptagePointHaut(int coul, int x, int y, MyInt nbPointDeja){
		//si existe
		if(x>=0 && x<nbX && y>=0 && y<nbY && tuilePlateau[x][y]!=null){
			//si pas deja regard�
			if(tuilePlateau[x][y].getCoteHaut().pasDejaCompte()){
				//et si de la bonne couleur
				if(tuilePlateau[x][y].getCoteHaut().getCouleur()==coul){
					//si pas de sortie de virage, +1
					if(nbPointDeja.entier!=-1){ 
						nbPointDeja.entier++; 
						//System.err.println("+ en haut de x="+x+", y="+y+", nbPoint="+nbPointDeja.entier);
					}
					//on dique que l'on a deja vu cette case
					tuilePlateau[x][y].getCoteHaut().compte();
					//alors, ok
					//on regarde devant nous
					comptagePointBas(coul,x,y-1,nbPointDeja);
					//on fait de meme pour touts les autres cot�s de la case (meme enclos que nous)
					comptagePointDroite(coul,x,y,nbPointDeja);
					comptagePointBas(coul,x,y,nbPointDeja); //seulement haut et bas impossible-> pas de tests a effectuer
					comptagePointGauche(coul,x,y,nbPointDeja);
				}else{
					//on regarde si foret
					if(tuilePlateau[x][y].getCoteHaut().getCouleur()==Cote.FORET){
						//on regarde si foret loup sans chasseur
						MyInt temp=new MyInt(0);
						ArrayList coteAInit=new ArrayList();
						comptagePointHautForet( x, y, temp, coteAInit);
						//on reinit la foret
						for(int i=0;i<coteAInit.size();i++){
							((Cote)coteAInit.get(i)).resetComptage();
						}
						//sauf nous
						tuilePlateau[x][y].getCoteHaut().compte();
						//System.err.println("resultatH="+temp.entier);
						//et on regarde resultat
						if(temp.entier>0){//si loup
							nbPointDeja.entier=0-1;
						}//sinon, pas de problemes
					}else{
						//on dique que l'on a deja vu cette case
						tuilePlateau[x][y].getCoteHaut().compte();
						//System.err.println("haut, x="+x+", y="+y+"pas bonne coul, nbPoint="+nbPointDeja.entier);
					}
				}
			}
		}else{//pas de bordure -> tous l'enclos est "mort"
			nbPointDeja.entier=-1;
		}
	}
	
	private void comptagePointHautForet(int x, int y, MyInt nbLoup, ArrayList coteAInit) {
//		si existe et pas chasseur
		if(x>=0 && x<nbX && y>=0 && y<nbY && tuilePlateau[x][y]!=null && nbLoup.entier!=-1){
			//si pas deja regard�
			if(tuilePlateau[x][y].getCoteHaut().pasDejaCompte()){
				//et si de la bonne couleur
				if(tuilePlateau[x][y].getCoteHaut().getCouleur()==Cote.FORET){
//					si case speciale
					if(tuilePlateau[x][y].getType().equals("Speciale")){
						//System.err.println("entree case spe"+" a x="+x+", y="+y);
						//si chasseur
						if( !((FaceSpeciale)tuilePlateau[x][y]).getEstChasseur()){
							//System.err.println("entree case chass");
							nbLoup.entier=0-1;
						}else{//si loup
							//System.err.println("entree case loup");
							if(nbLoup.entier!=-1){ 
								//on ote un point
								nbLoup.entier++;
							} 
							//on peut encore voir un chasseur, on continue de regarder
							tuilePlateau[x][y].getCoteBas().compte();
							tuilePlateau[x][y].getCoteGauche().compte();
							tuilePlateau[x][y].getCoteDroite().compte();
							tuilePlateau[x][y].getCoteHaut().compte();
							coteAInit.add(tuilePlateau[x][y].getCoteBas());
							coteAInit.add(tuilePlateau[x][y].getCoteGauche());
							coteAInit.add(tuilePlateau[x][y].getCoteDroite());
							coteAInit.add(tuilePlateau[x][y].getCoteHaut());

							comptagePointBasForet(x,y-1,nbLoup,coteAInit);
							comptagePointDroiteForet(x-1,y,nbLoup,coteAInit);
							comptagePointHautForet(x,y+1,nbLoup,coteAInit);
							comptagePointGaucheForet(x+1,y,nbLoup,coteAInit);
						}
					}else{
						//System.err.println("entree case H"+tuilePlateau[x][y].getType()+" a x="+x+", y="+y);
						//on dique que l'on a deja vu cette case
						tuilePlateau[x][y].getCoteHaut().compte();
						//System.err.println("H x="+x+", y="+y);
						coteAInit.add(tuilePlateau[x][y].getCoteHaut());
						//alors, ok
						//on regarde devant nous
						comptagePointBasForet(x,y-1,nbLoup,coteAInit);
						//on fait de meme pour touts les autres cot�s de la case (meme enclos que nous)
						comptagePointGaucheForet(x,y,nbLoup,coteAInit);
						comptagePointBasForet(x,y,nbLoup,coteAInit); //seulement haut et bas impossible-> pas de tests a effectuer
						comptagePointDroiteForet(x,y,nbLoup,coteAInit);
					}
				}//sinon (si pas foret) , on s'en fout
				//else{System.err.println("pas forete H"+" a x="+x+", y="+y);}
			}
			//else{System.err.println("deja compt� H"+" a x="+x+", y="+y);}
		}//pas de bordure -> pas grave, on regarde si chasseur / loup
		//else{System.err.println("pas bordure H"+" a x="+x+", y="+y);}
	}
	
	private void comptagePointGauche(int coul, int x, int y, MyInt nbPointDeja){
		//si existe
		if(x>=0 && x<nbX && y>=0 && y<nbY && tuilePlateau[x][y]!=null){
			//si pas deja regard�
			if(tuilePlateau[x][y].getCoteGauche().pasDejaCompte()){
				//et si de la bonne couleur
				if(tuilePlateau[x][y].getCoteGauche().getCouleur()==coul){
					//si pas de sortie de virage, +1
					if(nbPointDeja.entier!=-1){ 
						nbPointDeja.entier++; 
						//System.err.println("+ a Gauche x="+x+", y="+y);
					}
					//on dique que l'on a deja vu cette case
					tuilePlateau[x][y].getCoteGauche().compte();
					//alors, ok
					//on regarde devant nous
					comptagePointDroite(coul,x-1,y,nbPointDeja);
					//on fait de meme pour touts les autres cot�s de la case (meme enclos que nous)
					comptagePointBas(coul,x,y,nbPointDeja);
					comptagePointDroite(coul,x,y,nbPointDeja);
					comptagePointHaut(coul,x,y,nbPointDeja); //seulement Gauche et Droite impossible-> pas de tests a effectuer
				}else{
					//on regarde si foret
					if(tuilePlateau[x][y].getCoteGauche().getCouleur()==Cote.FORET){
						//on regarde si foret loup sans chasseur
						MyInt temp=new MyInt(0);
						ArrayList coteAInit=new ArrayList();
						comptagePointGaucheForet( x, y, temp, coteAInit);
						//on reinit la foret
						for(int i=0;i<coteAInit.size();i++){
							((Cote)coteAInit.get(i)).resetComptage();
						}
						//sauf nous
						tuilePlateau[x][y].getCoteGauche().compte();
						//System.err.println("resultatG="+temp.entier);
						//et on regarde resultat
						if(temp.entier>0){//si loup
							nbPointDeja.entier=0-1;
						}//sinon, pas de problemes
					}else{
						//on dique que l'on a deja vu cette case
						tuilePlateau[x][y].getCoteGauche().compte();
						//System.err.println("Gauche, x="+x+", y="+y+"pas bonne coul");
					}
				}
			}
		}else{//pas de bordure -> tous l'enclos est "mort"
			nbPointDeja.entier=-1;
		}
	}
	
	private void comptagePointGaucheForet(int x, int y, MyInt nbLoup, ArrayList coteAInit) {
//		si existe
		if(x>=0 && x<nbX && y>=0 && y<nbY && tuilePlateau[x][y]!=null && nbLoup.entier!=-1){
			//si pas deja regard�
			if(tuilePlateau[x][y].getCoteGauche().pasDejaCompte()){
				//et si de la bonne couleur
				if(tuilePlateau[x][y].getCoteGauche().getCouleur()==Cote.FORET){
//					si case speciale
					if(tuilePlateau[x][y].getType().equals("Speciale")){
						//System.err.println("entree case spe"+" a x="+x+", y="+y);
						//si chasseur
						if( !((FaceSpeciale)tuilePlateau[x][y]).getEstChasseur()){
							//System.err.println("entree case chass");
							nbLoup.entier=0-1;
						}else{//si loup
							//System.err.println("entree case loup");
							if(nbLoup.entier!=-1){ 
								//on ote un point
								nbLoup.entier++;
							} 
							//on peut encore voir un chasseur, on continue de regarder
							tuilePlateau[x][y].getCoteBas().compte();
							tuilePlateau[x][y].getCoteGauche().compte();
							tuilePlateau[x][y].getCoteDroite().compte();
							tuilePlateau[x][y].getCoteHaut().compte();
							coteAInit.add(tuilePlateau[x][y].getCoteBas());
							coteAInit.add(tuilePlateau[x][y].getCoteGauche());
							coteAInit.add(tuilePlateau[x][y].getCoteDroite());
							coteAInit.add(tuilePlateau[x][y].getCoteHaut());

							comptagePointBasForet(x,y-1,nbLoup,coteAInit);
							comptagePointDroiteForet(x-1,y,nbLoup,coteAInit);
							comptagePointHautForet(x,y+1,nbLoup,coteAInit);
							comptagePointGaucheForet(x+1,y,nbLoup,coteAInit);
						}
					}else{
						//System.err.println("entree case G"+tuilePlateau[x][y].getType()+" a x="+x+", y="+y);
						//on dique que l'on a deja vu cette case
						tuilePlateau[x][y].getCoteGauche().compte();
						//System.err.println("G x="+x+", y="+y);
						coteAInit.add(tuilePlateau[x][y].getCoteGauche());
						//alors, ok
						//on regarde devant nous
						comptagePointDroiteForet(x-1,y,nbLoup,coteAInit);
						//on fait de meme pour touts les autres cot�s de la case (meme enclos que nous)
						comptagePointBasForet(x,y,nbLoup,coteAInit);
						comptagePointDroiteForet(x,y,nbLoup,coteAInit); //seulement haut et bas impossible-> pas de tests a effectuer
						comptagePointHautForet(x,y,nbLoup,coteAInit);
					}
				}//sinon (si pas foret) , on s'en fout
				//else{System.err.println("pas foret G"+" a x="+x+", y="+y);}
			}
			//else{System.err.println("deja compt� G"+" a x="+x+", y="+y);}
		}//pas de bordure -> pas grave, on regarde si chasseur / loup
		//else{System.err.println("pas bordure G"+" a x="+x+", y="+y);}
	}
	
	public void reinit() {

		FaceTuile piece=tuilePlateau[(int)(xMax/2)][(int)(yMax/2)];
		
		for(int i = 0; i < xMax; i++)
		{
			for(int j = 0; j < yMax; j++)
			{
				tuilePlateau[i][j] = null;
			}
		}
		
		tuilePlateau[(int)(xMax/2)][(int)(yMax/2)] = piece;
		
	}
	
	
	
}


