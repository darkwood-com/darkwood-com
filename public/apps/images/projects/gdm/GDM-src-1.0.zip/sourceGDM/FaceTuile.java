abstract public class FaceTuile {
	
	/**
	 * @uml.property  name="numero"
	 */
	private int numero;
	
	/**
	 * Getter of the property <tt>numero</tt>
	 * @return  Returns the numero.
	 * @uml.property  name="numero"
	 */
	public int getNumero() {
		return numero;
	}
	
	/**
		* Setter of the property <tt>numero</tt>
	 * @param numero  The numero to set.
	 * @uml.property  name="numero"
	 */
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	/**
	 * nom du fichier qui contient l'image
	 */
	private String image;
	

	/**
		* Setter of the property <tt>image</tt>
	 * @param numero  The name of the file of the imgae to set.
	 * @uml.property  name="image"
	 */
	public void setNomImage(String img) {
		this.image = img;
	}

	/**
		* Setter of the property <tt>image</tt>
	 * @param numero  The name of the file of the imgae to set.
	 * @uml.property  name="image"
	 */
	public String getNomImage() {
		return image;
	}
	
	/**
		* @uml.property  name="faceTuile2"
	 * @uml.associationEnd  inverse="faceTuile1:FaceTuile"
	 * @uml.association  name="autreFace"
	 */
	private FaceTuile faceTuileSuivant;
	
	/**
		* Getter of the property <tt>faceTuile2</tt>
	 * @return  Returns the faceTuile2.
	 * @uml.property  name="faceTuile2"
	 */
	public FaceTuile getFaceTuileSuivant() {
		return faceTuileSuivant;
	}
	
	/**
		* Setter of the property <tt>faceTuile2</tt>
	 * @param faceTuile2  The faceTuile2 to set.
	 * @uml.property  name="faceTuile2"
	 */
	public void setFaceTuileSuivant(FaceTuile faceTuileSuivant) {
		this.faceTuileSuivant = faceTuileSuivant;
	}

	public FaceTuile(int numeroFT, String nomFicImage){
		this.numero=numeroFT;
		this.image=nomFicImage;
	}

	public FaceTuile(int numeroFT){
		this.numero=numeroFT;
		this.image="";
	}
	
	//methodes pour le comptage des points (a redefinir)
	abstract public Cote getCoteBas();
	abstract public Cote getCoteGauche();
	abstract public Cote getCoteHaut();
	abstract public Cote getCoteDroite();
	abstract public String getType();
	
	
	
	//methodes abstracts
	abstract public void afficheFaceTerminal();
	abstract public void rotation();
	abstract public int getCouleurCote(int cote);
	abstract public int getNbRot();
}


