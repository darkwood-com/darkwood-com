
public class Action {
	public String commande;
	public int numeroJoueur;
	
	Action(){
		commande="";
		numeroJoueur=-1;
	}
	Action(String comm, int numJ){
		commande=comm;
		numeroJoueur=numJ;
	}
}
