import java.awt.Frame;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;

import javax.swing.JOptionPane;

/*
* Created on 7 juin 2006
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/

/**
* @author rdurand
*
* TODO To change the template for this generated type comment go to
* Window - Preferences - Java - Code Style - Code Templates
*/
public class ThreadClientServeurMouton implements Runnable{

	private Thread _t; //le thread
	Socket _sock; // recevra le socket liant au client
	private BufferedReader _in; // pour gestion du flux d'entr�e
	private PrintWriter _out; // pour gestion du flux de sortie
	private ArrayList _tabOut; //tableau des flux de sortie (vers les clients)
	private int _numClient; //numero du client
	private ServeurMouton _monServ;
	private boolean _monTourSpecial=false;

	ThreadClientServeurMouton(Socket s, ArrayList listOut, ServeurMouton serv){
		_monServ=serv;
		_sock=s; // passage de local en global
		_tabOut=listOut;
		try {
			// fabrication d'une variable permettant l'utilisation du flux de sortie avec des string
			_out = new PrintWriter(_sock.getOutputStream());
			// fabrication d'une variable permettant l'utilisation du flux d'entr�e avec des string
			_in = new BufferedReader(new InputStreamReader(_sock.getInputStream()));
			//renvoie le code retour pour dire comment s'est pass� la connexion
			// ajoute le flux de sortie dans la liste et r�cup�ration de son numero
			_numClient = _monServ.addClient(_out);
			if(_numClient==0){
				_out.print("10Erreur, serveur complet\n");
				_out.flush();
				System.out.println("Client: Un nouveau client ne s'est pas connect�, no "+_numClient);
			}else{
				//envoie du message
				_out.print("1"+_numClient+"Connecte\n");
				_out.flush();
				System.out.println("Client: Un nouveau client s'est connecte, no "+_numClient);
				_t = new Thread(this); // instanciation du thread
				_t.start(); // demarrage du thread, la fonction run() est ici lanc�e
			}
		} catch (IOException e){ }
	}


	public void run() {
		//String message = ""; // d�claration de la variable qui recevra les messages du client
		char[] lire=new char[1]; //pour lire un caractere (le code)
		boolean pasQuitter=true; //pour gerer la deconnection "propre"
		// on indique dans la console la connection d'un nouveau client
		try { // la lecture des donn�es entrantes se fait caract�re par caract�re ...
			//lecture du code
			while(pasQuitter){
				_in.read(lire,0,1);
				System.out.println("Client "+_numClient+": reception d'un message.");
				//on regarde le code du message
				switch(lire[0]){
					case 'p':
						setNomJoueur();
						break;
					case '2':
						demarragePartie();
						break;
					case '8':
						finitTour();
						break;
					case 'a':
						pieceposee();
						break;
					case 'e':
						reveleCouleurEtPoseBerger();
						break;
					case 'c':
						reveleCouleur();
						break;
					case 'i':
						abandon();
						break;
					case 'u':
						reinit();
						break;
					case '0':
						quitter();
						pasQuitter=false;
						break;
					//pour le replay
					case 's':
						replaySuivant();
						break;
					case 'w':
						saveReplay();
						break;
					case 'r':
						chargerpartie();
						break;
					default:
						System.out.println("Client "+_numClient+": message inconnu:"+lire[0]);
						JOptionPane.showMessageDialog(new Frame(), "Erreur de reception, Probleme de connection avec le client "+_numClient+".", "Erreur",JOptionPane.YES_OPTION );
						//que faire?
						System.exit(0);
						break;
				}
			}

		} catch (Exception e){
			//en principe, on n'arrive l� que si il y a des problemes de connexion
			
			e.printStackTrace();
			System.err.println("Client "+_numClient+": deconnexion brutale.");
			//reveler couleur inconnu (car on ne sais pas)
			for(int i=0; i<_tabOut.size(); i++){
				//mais pas a "nous" ni aux decos
				if( i != _numClient-1 && _tabOut.get(i)!=null){
					System.out.println("Client "+_numClient+": revelation de notre couleur au joueur n�"+Integer.toString(i+1));
					//revele couleur
					((PrintWriter)_tabOut.get(i)).print('g'+Integer.toString(_numClient)+"\n9\n");
					((PrintWriter)_tabOut.get(i)).flush();
				}
			}
			//faire la deco
			if(_monServ.deconnection(_numClient)){
			//le joueur courant avait la main
				//on passe au suivant
				finitTour();
			}
			
		}
		
		System.out.println("Client "+_numClient+": deconnexion.");
		_out.close();
	}


	private void quitter() {
		System.out.println("Client "+_numClient+": quitter.");
		_monServ.deconnection(_numClient);
		_out.write("0");
		_out.flush();
	}


	private void setNomJoueur() {
	
		try {
			String nom=_in.readLine();
			
			System.out.println("Client "+_numClient+": changement de pseudo � "+nom);

			//on le dit au serveur
			_monServ.setNom(_numClient, nom);
			
			//on repercute PAS aux autre clients cet evenement CAR on s'en chargera + tard
			/*for(int i=0; i<_tabOut.size(); i++){
				//mais pas a "nous"
				if( i != _numClient-1){
					((PrintWriter)_tabOut.get(i)).print('q'+Integer.toString(_numClient)+'\n'+nom+'\n');
					((PrintWriter)_tabOut.get(i)).flush();
				}
			}*/
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void reinit() {
		System.out.println("Client "+_numClient+": demande de reinitialisation du serveur");
		//si pas de parite en cours et je suis le joueur1
		if(_monServ.partieInactive() && _numClient==1){
			//alors lancement d'une nouvelle partie
			_monServ.reinit();
		}
	}


	private void reveleCouleurEtPoseBerger() {
		System.out.println("Client "+_numClient+": nous donne sa couleur");
		//si on joue
		if(_monServ.partieJoue()){
			System.out.println("Client "+_numClient+": revelation de la couleur et posage de berger.");
			String coul,x,y,nbPieceACote;
			try{
				//d'abord, on prend la main pour jouer une fois suppl�mentaire
				_monServ.prendreLaMain(_numClient);
				_monTourSpecial=true;
				
				//on lit la couleur
				coul=_in.readLine();
				//on lit la coordonnee x
				x=_in.readLine();
				//on lit la coordonnee y
				y=_in.readLine();
				//on lit le nombre de piece a lui donner
				nbPieceACote=_in.readLine();

				//on repercute aux autre clients cet evenement
				for(int i=0; i<_tabOut.size(); i++){
					//mais pas a "nous" ni aux decos
					if( i != _numClient-1 && _tabOut.get(i)!=null){
						System.out.println("Client "+_numClient+": revelation de notre couleur au joueur n�"+Integer.toString(i+1));
						//revele couleur
						((PrintWriter)_tabOut.get(i)).print('g'+Integer.toString(_numClient)+'\n'+coul+'\n');
						((PrintWriter)_tabOut.get(i)).flush();
						//pose berger
						((PrintWriter)_tabOut.get(i)).print('l'+coul+'\n'+x+'\n'+y+'\n');
						((PrintWriter)_tabOut.get(i)).flush();
					}
				}
				//on stocke l'info pose berger
				_monServ.addCommande('l'+coul+'\n'+x+'\n'+y+'\n',_numClient);
				
				//on renvoie les tuiles pioch�s
				envoieTuiles(Integer.parseInt(nbPieceACote));
				
				//on nous dit que c'est notre tour
				_out.write("6");
				_out.flush();

			}catch(IOException e){ }
		}else{
			//on vide le flux manuellement
			try {
				//on lit la couleur
				_in.readLine();
				//on lit la coordonnee x
				_in.readLine();
				//on lit la coordonnee y
				_in.readLine();
				//on lit le nombre de piece a lui donner
				_in.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}


	private void chargerpartie() {
		//si on ne fait "rien", alors on peut voir un replay (mais en rincipe, pas besoin de tests)
		if(_monServ.partieInactive()){
			try {
				String st=_in.readLine();
				_monServ.chargerPartie(st);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{
			//on vide le flux manuellement
			try {
				_in.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}


	private void saveReplay() {
		try {
			_monServ.sauverReplay(_in.readLine());
		} catch (IOException e) {
			e.printStackTrace();
		}
	}


	private void replaySuivant() {
		//si on est en train de joueur un replay
		if(_monServ.partieReplay()){
			_monServ.doNextStepOfReplay();
		}
	}

	private void demarragePartie(){
		System.out.println("Client "+_numClient+": demande de demarrage de la partie.");
		//si on est le joueur1 (et que l'on ne fait rien)
		if(_numClient==1 && _monServ.partieInactive()){
			System.out.println("Client "+_numClient+": demarrage.");
			_out.print("31");
			_out.flush();
			//puit on d
			_monServ.distribuePioche();
			
		}else{
			//sinon, c'est pas a nous de faire ca!
			_out.print("30");
			_out.flush();
		}
	}

	private void finitTour(){
//		ok si on joue
		if(_monServ.partieJoue()){
			//on regarde si on ne doit pas rendre la main
			if(_monTourSpecial){
				_monServ.redonnerLaMain();
				_monTourSpecial=false;
				return;
			}
			//sinon, cas normal: la main au suivant vivant
			System.out.println("Client "+_numClient+": fin du tour du joueur num="+_numClient);
//			on prend l'entier qui correspond au joueur suivant (num-1)+1 % 4, 
			//on continue a en chercher un tant qu'on en a pas trouv� un qui joue
			int suivant=_numClient-1;
			suivant=suivant+1;
			//System.err.println("Test1 "+suivant+" ("+_tabOut.size()+")");
			if(suivant==_tabOut.size()){ suivant=0; }
			//System.err.println("Test2 "+suivant);
			int nbMax=0;
			while(  ( _tabOut.get(suivant)==null || _monServ.aAbandonne(suivant+1) )  &&  nbMax<_tabOut.size()  ){
				System.out.println("Client, le joueur "+suivant+" a finit de jouer, il ne peut pas jouer");
				suivant=suivant+1;
				//System.err.println("Test1 "+suivant+" ("+_tabOut.size()+")");
				if(suivant>=_tabOut.size()){ suivant=0; }
				//System.err.println("Test2 "+suivant);
				nbMax++;
			}
			if(nbMax>=_tabOut.size()){//si plus personne
				_monServ.finPartie();
			}else{
				System.out.println("Client "+_numClient+": debut du tour du joueur num="+(suivant+1));
				//on lui donne la main
				((PrintWriter)(_tabOut.get(suivant))).print('6');
				((PrintWriter)(_tabOut.get(suivant))).flush();
				_monServ.setJoueurCourant(suivant+1);

				//stockage du changement de joueur courant
				_monServ.addCommande("n"+(suivant+1)+"\n",suivant+1);	
			}
		}
	}

	private void abandon() {
		//si on joue
		if(_monServ.partieJoue()){
			System.out.println("Client "+_numClient+": abandon du joueur num="+_numClient);
			//on stocke cette info
			int place=_monServ.abandonne(_numClient);
			//on lui dit sa place
			_out.print("j"+place+"\n");
			_out.flush();
			//on dit aux autres qu'il a finit
			for(int i=0; i<_tabOut.size(); i++){
				//mais pas a "nous" ni a ceux qui sont deco
				if( i != _numClient-1 && _tabOut.get(i)!=null){
					((PrintWriter)_tabOut.get(i)).print("z"+_numClient+"\n"+place+"\n");
					((PrintWriter)_tabOut.get(i)).flush();;
				}
			}

			//stockage de l'info
			_monServ.addCommande("z"+_numClient+"\n"+place+"\n",_numClient);
			
			//on regarde si c'est le dernier
			if(place==_tabOut.size()){
				//alors, on lance la fin de partie
				_monServ.finPartie();
			}	
		}else{
			//si on joue pas, on lui renvoie 0
			System.out.println("Client "+_numClient+": Pas d'abandon du joueur num="+_numClient);
			_out.print("j0\n");
		}
	}

	private void pieceposee(){
		String stTemp,numTuile,nbRotation,x,y;
		int nbPieceACote;
		//ok si on joue
		if(_monServ.partieJoue()){
			try{
				//on lit le numero
				numTuile=_in.readLine();
				//numFace=Integer.parseInt(numTuile);
				System.out.println("Client "+_numClient+": pose de la  piece num "+numTuile+".");
				//on lit la rotation
				nbRotation=_in.readLine();
				//on lit la coordonnee x
				x=_in.readLine();
				//on lit la coordonnee y
				y=_in.readLine();
				//on lit le nombre de piece a lui donner
				stTemp=_in.readLine();
				nbPieceACote=Integer.parseInt(stTemp);

				//on repercute aux autre clients cet evenement
				for(int i=0; i<_tabOut.size(); i++){
					//mais pas a "nous" nni aux decos
					if( i != _numClient-1 && _tabOut.get(i)!=null){
						((PrintWriter)_tabOut.get(i)).print('d'+numTuile+'\n'+nbRotation+'\n'+x+'\n'+y+'\n');
						((PrintWriter)_tabOut.get(i)).flush();
					}
				}

				//on renvoie les tuiles pioch�s
				envoieTuiles(nbPieceACote);
				
				//stockage de l'info
				//System.err.println('d'+numTuile+"\\n"+nbRotation+"\\n"+x+"\\n"+y+"\\n");
				_monServ.addCommande('d'+numTuile+'\n'+nbRotation+'\n'+x+'\n'+y+'\n',_numClient);
				
			}catch(IOException e){ }
		}else{
			//on vide le flux
			System.out.println("Client "+_numClient+": PAS de pose de la  piece.");
			try {
				numTuile=_in.readLine();
				//numFace=Integer.parseInt(numTuile);
				System.out.println("Client "+_numClient+":ne peut pas poser la  piece num "+numTuile+".");
				//on lit la rotation
				nbRotation=_in.readLine();
				//on lit la coordonnee x
				x=_in.readLine();
				//on lit la coordonnee y
				y=_in.readLine();
				//on lit le nombre de piece a lui donner
				stTemp=_in.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			
		}
	}

	/**
	 * revele la couleur de ce joueur aux autres
	 *
	 */
	private void reveleCouleur(){
		String coul;
		System.out.println("Client "+_numClient+": veut reveler sa couleur.");
		//si on joue
		if(_monServ.partieJoue()){
			System.out.println("Client "+_numClient+": revelation de la couleur.");
			
			try{
				//on lit la couleur
				coul=_in.readLine();

				//on repercute aux autre clients cet evenement
				for(int i=0; i<_tabOut.size(); i++){
					//mais pas a "nous" ni aux deco
					if( i != _numClient-1 && _tabOut.get(i)!=null){
						System.out.println("Client "+_numClient+": revelation de notre couleur au joueur n�"+(i+1));
						//revele couleur
						((PrintWriter)_tabOut.get(i)).print('g'+Integer.toString(_numClient)+'\n'+coul+'\n');
						((PrintWriter)_tabOut.get(i)).flush();
					}
				}

			}catch(IOException e){ }
		}else{
			//on vide le flux
			try {
				System.out.println("Client "+_numClient+": PAS de revelation de la couleur.");
				coul=_in.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * appel� quand on pose un tuile
	 * @param nbPieces � renvoyer
	 */
	private void envoieTuiles(int nbPieces){
		//init var
		String msg=new String("");
		int i,num;

		//init while
		i=0;
		num=_monServ.donnePiece();
		//on prend les tuiles
		while( i<nbPieces-1 && num!=-1){
			msg=msg+Integer.toString(num)+'\n';
			//relance
			i++;
			num=_monServ.donnePiece();
		}
		//on regarde si la derni�re tuiles est possible
		if(num!=-1){
			msg=msg+Integer.toString(num)+'\n';
			i++;
		}

		//on envoie le message
		//System.err.println('b'+Integer.toString(i)+'\n'+msg);
		_out.print('t'+Integer.toString(i)+'\n'+msg);
		_out.flush();
	}
	
	
}


