import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PipedInputStream;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.channels.Pipe;

import javax.swing.JOptionPane;

/*
 * Created on 8 juin 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author mledru
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class SocketClientMouton extends Socket {

	PrintWriter _out;
	BufferedReader _in;
	//int numClient;
	//ThreadClientMouton ecouteur;
	//le flux entrant
	//PipedInputStream _in;
	//PipedReader _in;
	
	public SocketClientMouton(String adr, int port, String monNom, GDM prog)throws IOException {
		super(adr,port);
		
		System.out.println("Emmeteur: Demande Connexion.");
		
		//on prend les flux du terminal
		BufferedReader inTh=new BufferedReader(new InputStreamReader(this.getInputStream()));
		_out=new PrintWriter(this.getOutputStream());

		//on cree le flux qui lit � m'ecouteur
		PipedWriter outTh=new PipedWriter();
		_in=new BufferedReader(new PipedReader(outTh));
		
		//on attend le mesage de retour de connexion
		System.out.println("Demande de connexion.");
		char[] cBuff=new char[1];
		
		new ThreadClientMouton( inTh, outTh, prog);
		_in.read(cBuff,0,1);
		
		//si pas bon, on quitte
		if(cBuff[0]=='0'){
			JOptionPane.showMessageDialog(prog.getFrame(), "Erreur de connection avec le serveur\n" +
					"Verifiez que celui-ci existe et qu'il n'est pas d�j� lanc�.", "Erreur",JOptionPane.ERROR_MESSAGE );
			System.exit(0);
		}
		
		//sinon, on indique notre pseudo au serveur
		envoiePseudo(monNom);
	}
	
	/**
	 * Permet de changer de pseudo
	 */
	public void envoiePseudo(String pseudo){
		System.out.println("Emmeteur: Envoie pseudo.");
		_out.print("p"+pseudo+"\n");
		_out.flush();
	}
	
	public void demandeDebutPartie(){
		System.out.println("Emmeteur: Demande debut de la partie.");
		//var
		char[] cBuff=new char[1];
		cBuff[0]='0';
		//init
		//_in.reset();
		//on demande le debut de partie
		_out.print("2");
		_out.flush();
		//on attend la reponse, via ecouteur
		//non pas pb de pipe
		/*try {
			_in.read(cBuff,0,1);
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(cBuff[0]=='0'){
			return false;
		}
		return true;*/
	}
	/*
	public int[] attendreTuilesDepart() throws IOException{
		//var
		char[] cBuff=new char[1];
		String stBuff;
		int[] tabTuiles;
		System.err.println("testeur1");
		//on atted de recevoir la trame
		_in.read(cBuff,0,1);
		System.err.println("testeur2,"+new String(cBuff));
		//la, en principe, cbuff[0]==4
		stBuff=_in.readLine();
		System.err.println("testeur2.5,"+stBuff);
		tabTuiles=new int[Integer.parseInt(stBuff)];
		/
		 * /tabTuiles=new int[Integer.parseInt(_in.readLine())];
		System.err.println("testeur3");
		for(int i=0;i<tabTuiles.length;i++){
			stBuff=_in.readLine();
			System.err.println("testeur4,"+stBuff);
			tabTuiles[i]=Integer.parseInt(stBuff);
		}
		return tabTuiles;
	}
	*/
	public void signalePosePiece(int numP, int nbRot, int x, int y, int nbTuileACote){
		System.out.println("Emmeteur: Signale piece pos�e.");
		_out.write("a"+Integer.toString(numP)+"\n"+
				Integer.toString(nbRot)+"\n"+
				Integer.toString(x)+"\n"+
				Integer.toString(y)+"\n"+
				Integer.toString(nbTuileACote)+"\n");
		_out.flush();
	}
	
	public void signaleFinTour(){
		System.out.println("Emmeteur: fin de notre tour.");
		_out.write("8");
		_out.flush();
	}
	
	public void reveleCouleur(int coul, int x, int y, int nbPieces){
		System.out.println("Emmeteur: revele notre couleur et pose le berger.");
		_out.write("e"+Integer.toString(coul)+"\n"+
				Integer.toString(x)+"\n"+
				Integer.toString(y)+"\n"+
				Integer.toString(nbPieces)+"\n");
		_out.flush();
	}
	

	public int abandonner(){
		System.out.println("Emmeteur: Signal abandon.");
		//on envoie
		_out.write("i");
		_out.flush();
		//on attend la reponse
		/*try{
			char[] cBuff=new char[1];
			_in.read(cBuff,0,1);
			return Integer.parseInt(new String(cBuff));
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}*/
		return 0;
	}
	
	/**
	 * pour continuer l'iteration du replay
	 */
	public void replaySuivant(){
		System.out.println("Emmeteur: Demande etape du replay suivant.");
		_out.write("s");
		_out.flush();
	}
	
	public void saveReplay(String empl){
		System.out.println("Emmeteur: Demande sauvegarde du replay.");
		_out.write("w"+empl+'\n');
		_out.flush();
	}

	public void chargerPartie(String nomFic) {
		System.out.println("Emmeteur: Demande chargement replay.");
		_out.write("r"+nomFic+"\n");
		_out.flush();
		
	}

	/**
	 * pour reveler sa couleur quand on arrete de jouer
	 * @param numero
	 * @param couleur
	 */
	public void reveleCouleur(int couleur) {
		System.out.println("Emmeteur: Revele couelur seule.");
		_out.write("c"+Integer.toString(couleur)+'\n');
		_out.flush();
	}

	/**
	 * Demande au serveur de nous lancer une nouvelle partie
	 *
	 */
	public void demandeReinit() {
		System.out.println("Emmeteur: Demande reinitialisation du serveur.");
		_out.write("u");
		_out.flush();
		
	}

	public void demandeQuitter() {
		System.out.println("Emmeteur: Signal que l'on quitte.");
		_out.write("0");
		_out.flush();
	}
	
}

