public class FaceSpeciale extends FaceNormale {
	
	public static final String type="Speciale";
	
	/**
	 * @uml.property  name="estChasseur"
	 */
	private boolean estChasseur;
	
	
	/**
	 * Getter of the property <tt>estChasseur</tt>
	 * @return  Returns the estChasseur.
	 * @uml.property  name="estChasseur"
	 */
	public boolean getEstChasseur() {
		return estChasseur;
	}
	
	/**
		* Setter of the property <tt>estChasseur</tt>
	 * @param estChasseur  The estChasseur to set.
	 * @uml.property  name="estChasseur"
	 */
	public void setEstChasseur(boolean estChasseur) {
		this.estChasseur = estChasseur;
	}
	
	/**
	 * 
	 * @param stPersonage "loup" ou "chasseur"
	 * @param stCouleur "jaune", "rose", "vert" ou "bleu"
	 */
	public FaceSpeciale(int numFace, String stPersonage, String stCouleur){
		super(numFace, Cote.coulToString(Cote.FORET), "moutons/tuile"+((numFace/2)+1)+".jpg" );
		//cree la face speciale
		if(stPersonage.equalsIgnoreCase("chasseur")){
			estChasseur=true;
		}else{
			estChasseur=false;
		}
		
		//ajout du fichier d'image
		//setNomImage("moutons/tuile"+((numFace/2)+1)+".jpg");
		
		//cree lautre face
		this.setFaceTuileSuivant(new FaceNormale(numFace+1,stCouleur,"moutons/tuile"+((numFace/2)+1)+"b.jpg"));
		
		//on lui dit que son autre cote cest nous
		this.getFaceTuileSuivant().setFaceTuileSuivant(this);
	}
	
	public void afficheFaceTerminal(){
		System.out.println(super.getNomImage());
		if(estChasseur){
			System.out.println("chasseur");
		}else{
			System.out.println("loup");
		}
	}
	
	public void rotation(){
		
	}
	
	public int getCouleurCote(int cote) {
		return 5;
	}
	
	public int getNbRot(){
		return 0;
	}

	public String getType() {
		return "Speciale";
	}
	
	
}


