import javax.swing.JLabel;

/*
 * Created on 14 juin 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author mledru
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class JLabelTuile extends JLabel {

	public int numeroMain;
	public int plateauX;
	public int plateauY;
}
