import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.border.Border;

/*
 * Created on 8 juin 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

/**
 * @author mledru
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */

public class Fenetre extends JFrame implements MaFenMouton, ActionListener{
	
	private static final long serialVersionUID = 1;
	private String dossierCourant;
	private GDM prog;
	
	private JPanel fenJoueur;
	private JScrollPane fenJoueur2;
	private JPanel fenPlateau;
	private JScrollPane fenPlateau2;
	private JPanel fenMain;
	private JScrollPane fenMain2;
	private JPanel fenAction;
	
	private int numNous=0;
	private static final int xMax = 800, yMax = 600;
	//private int selectPlateauX = 0, selectPlateauY = 0;
	private JLabelTuile selectPlateau=null;
	//private int indiceMain;
	
	private JButton bRotation = new JButton("Rotation");
	private JButton bRetournerPiece = new JButton("Retourner");
	private JButton bValiderTour = new JButton("Passer son tour");
	private JButton bPoserPiece = new JButton("Poser la piece");
	private JButton bRevelerCoul = new JButton("Reveler la couleur");
	private JButton bAbandon = new JButton("Arreter de jouer");
	private JButton bQuitter = new JButton("Quitter le jeu");

	private int scrollX=0;
	private int scrollY=0;
	
	//public void afficherMain()
	
	public Fenetre(String nomDossier, GDM progCourant){
		
		dossierCourant = nomDossier;
		this.prog = progCourant;
		//setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		WindowListener wli=new WindowAdapter(){
			public void windowClosing(WindowEvent arg0) {
				prog.demandeQuitterObligatoire();
			}
		};
		this.addWindowListener(wli);

		this.setSize(xMax,yMax);
		this.getContentPane().setLayout(new BorderLayout());
		
		fenJoueur = new JPanel();
		fenPlateau = new JPanel();
		fenMain = new JPanel();
		fenAction = new JPanel();
		
		fenAction.setLayout(new GridLayout(0,1));
		fenAction.setBackground(Color.MAGENTA);
		
		fenAction.add(bRotation);
		fenAction.add(bRetournerPiece);
		fenAction.add(bPoserPiece);
		fenAction.add(bRevelerCoul);
		fenAction.add(bValiderTour);
		fenAction.add(bAbandon);
		fenAction.add(bQuitter);

		bValiderTour.setEnabled(false);
		bPoserPiece.setLabel("Poser chasseur/loup");
		bAbandon.setEnabled(false);
		
		bRotation.addActionListener(this);
		bRetournerPiece.addActionListener(this);
		bPoserPiece.addActionListener(this);
		bRevelerCoul.addActionListener(this);
		bValiderTour.addActionListener(this);
		bAbandon.addActionListener(this);
		bQuitter.addActionListener(this);

		fenMain.setBackground(Color.blue);
		fenMain2= new JScrollPane(fenMain);
		fenJoueur.setBackground(Color.GREEN);
		fenJoueur2= new JScrollPane(fenJoueur);
		fenPlateau.setBackground(Color.PINK);
		fenPlateau.setLayout(new GridLayout(Plateau.nbX, Plateau.nbY));
		fenPlateau2 = new JScrollPane(fenPlateau);
		AdjustmentListener liScrollX=new AdjustmentListener(){
			public void adjustmentValueChanged(AdjustmentEvent arg0) {
				scrollX=arg0.getValue();
			}
		};
		fenPlateau2.getHorizontalScrollBar().addAdjustmentListener(liScrollX);
		AdjustmentListener liScrollY=new AdjustmentListener(){
			public void adjustmentValueChanged(AdjustmentEvent arg0) {
				scrollY=arg0.getValue();
			}
		};
		fenPlateau2.getVerticalScrollBar().addAdjustmentListener(liScrollY);

		getContentPane().add(fenJoueur2,BorderLayout.NORTH);
		getContentPane().add(fenPlateau2,BorderLayout.CENTER);
		getContentPane().add(fenMain2,BorderLayout.SOUTH);
		getContentPane().add(fenAction,BorderLayout.EAST);
		
		//on met un petit message
		fenJoueur.add(new JLabel("Connection �tablie, attente du demarrage de la partie."));
		
		setVisible(true);
	}
	
	
	public void cestMonTour(boolean monTour){
		bValiderTour.setEnabled(monTour);
		if(monTour){
			bPoserPiece.setLabel("Poser piece");
			JOptionPane.showMessageDialog(this, "C'est votre tour.\nVous pouvez poser une piece.", "Information", JOptionPane.PLAIN_MESSAGE);
		}else{
			bPoserPiece.setLabel("Poser chasseur/loup");
		}
	}
	
	/**
	 * pour mettre les scrollbar au milieu au debut de la partie
	 */
	public void initPlateau(){
		// on met les scrollbar au milieu
		JScrollBar scTemp=fenPlateau2.getHorizontalScrollBar();
		scrollX=scTemp.getMaximum()/2-(fenPlateau2.getWidth()/2);
		scTemp.setValue(scrollX);
		scTemp=fenPlateau2.getVerticalScrollBar();
		scrollY=scTemp.getMaximum()/2-(fenPlateau2.getHeight()/2);
		//on rajoute un peu � scrollY car il y a le panel de notre main qui va grossir
		scrollY+=50;
		scTemp.setValue(scrollY);
	}

	public void refreshPlateau(Plateau p){
		FaceTuile piece;
		ImageIcon pieceImage;
		JLabelTuile pieceLabel;
		Border cadre = BorderFactory.createLineBorder(Color.RED, 5);
		
		fenPlateau.removeAll();
		fenPlateau.repaint();
		
		for(int j = 0; j < p.getYMax(); j++)
		{
			for(int i = 0; i < p.getXMax(); i++)
			{
				piece = p.getTuilePlateau(i, j);
				
				pieceLabel = new JLabelTuile();
				if(piece != null)
				{
					pieceImage = selectImage(piece.getNomImage());
					
//					faire tourner l'image
					rotationImg(pieceLabel, pieceImage, piece.getNbRot());
				}
				else
				{
					pieceImage = selectImage("moutons/tuileVide.jpg");
					pieceLabel.setIcon(pieceImage);
					
					pieceLabel.plateauX = i;
					pieceLabel.plateauY = j;
					
					pieceLabel.addMouseListener(new MouseListener() {

						public void mouseClicked(MouseEvent e) {
							//si yen a deja un
							if(selectPlateau!=null){ 
								//on l'efface
								selectPlateau.setBorder(null);
							}
							//on met le suivant
							selectPlateau = ((JLabelTuile)e.getSource());
							//selectPlateauX = selectPlateau.plateauX;
							//selectPlateauY = selectPlateau.plateauY;
							selectPlateau.setBorder(BorderFactory.createLineBorder(Color.RED, 5));
							//refreshPlateau((Plateau)prog.getPlateau());
						}

						public void mousePressed(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}

						public void mouseReleased(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}

						public void mouseEntered(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}

						public void mouseExited(MouseEvent e) {
							// TODO Auto-generated method stub
							
						}
						
					});
				}
				
				//if (i == selectPlateauX && j == selectPlateauY) pieceLabel.setBorder(cadre);
				if (pieceLabel==selectPlateau) pieceLabel.setBorder(cadre);
				
				
				fenPlateau.add(pieceLabel);
			}
		}

		/*JScrollBar scTemp=fenPlateau2.getHorizontalScrollBar();
		scTemp.setValue(scrollX);
		System.err.println("xvar="+scrollX);
		System.err.println("x="+scTemp.getValue());
		scTemp=fenPlateau2.getVerticalScrollBar();
		scTemp.setValue(scrollY);
		System.err.println("yvar="+scrollY);
		System.err.println("y="+scTemp.getValue());*/

		setVisible(true);
		
		initPlateau();
	}
	
	/**
	 * 
	 * @param maMain array list de FaceTuiles
	 */
	public void refreshMain(ArrayList maMain, FaceTuile pieceCourante){
		int i = 0;
		FaceTuile piece;
		ImageIcon pieceImage;
		JLabelTuile pieceLabel;
		Border cadre = BorderFactory.createLineBorder(Color.RED, 5);
		
		fenMain.removeAll();
		fenMain.repaint();
		
		for(i=0;i<maMain.size(); i++)
		{
			piece = (FaceTuile) maMain.get(i);
			
			pieceImage = selectImage(piece.getNomImage());
			
			pieceLabel = new JLabelTuile();
			
//			faire tourner l'image
			rotationImg(pieceLabel, pieceImage, piece.getNbRot());
			
			if(piece == pieceCourante) {
				pieceLabel.setBorder(cadre);
//				pieceCourante.afficheFaceTerminal();
			}
			
			
			pieceLabel.numeroMain = i;
			
			pieceLabel.addMouseListener(new MouseListener() {

				public void mouseClicked(MouseEvent e) {
				}

				public void mousePressed(MouseEvent e) {
					JLabelTuile piece;
					piece = (JLabelTuile)e.getSource();
					
					prog.prendrePieceMain(piece.numeroMain);
				}

				public void mouseReleased(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				public void mouseEntered(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}

				public void mouseExited(MouseEvent e) {
					// TODO Auto-generated method stub
					
				}
				
			});
			
			fenMain.add(pieceLabel);
		}
		setVisible(true);
	}
	
	/**
	 * 
	 * @param Joueur ArrayList de Joueur
	 */
	public void refreshJoueur(ArrayList joueur){
		
		JLabel jLabel;
		int num;
		String buff;
		
		fenJoueur.removeAll();
		fenJoueur.repaint();
		
		for(int i=0;i<joueur.size();i++){
			num=((Joueur)joueur.get(i)).getNumero();
			if( (num) == numNous){
				
				//on regarde si on est encore de la partie (pour voir si on peut abandonner ou reveler sa couleur)
				if(((Joueur)joueur.get(i)).joue()){
					bAbandon.setEnabled(true);
					//on regarde si notre berger est pose
					if(((Moi)joueur.get(i)).bergerPose()){
						this.bRevelerCoul.setEnabled(false);
					}else{
						this.bRevelerCoul.setEnabled(true);
					}
				}else{
					bAbandon.setEnabled(false);
					bRevelerCoul.setEnabled(false);
				}
				//System.err.println( ((Joueur)joueur.get(i)).getNumero()+", "+((Joueur)joueur.get(i)).getNumero() );
				buff=" vous: n�"+ ((Joueur)joueur.get(i)).getNumero() 
				+", "+((Joueur)joueur.get(i)).getNom()+" "
				+"\n coul="+ Cote.coulToString(((Joueur)joueur.get(i)).getCouleur()) ;
			}else{
				buff= " j n�"+ ((Joueur)joueur.get(i)).getNumero()
				+", "+((Joueur)joueur.get(i)).getNom()+" ";
				if(((Joueur)joueur.get(i)).getACouleur()){
					buff=buff+("\n coul="+Cote.coulToString( ((Joueur)joueur.get(i)).getCouleur() ));
				}
			}
			//on indique si il y a eu un abandon
			if( !((Joueur)joueur.get(i)).joue() ){
				buff=buff+(", abandon n�"+((Joueur)joueur.get(i)).getOrdreFinPartie());
			}
			//et si il est deco
			if(((Joueur)joueur.get(i)).isDeco()){
				buff=buff+" !DECONNECTE!";
			}
			buff=buff+(" ");
			jLabel=new JLabel(buff);
			jLabel.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
			fenJoueur.add(jLabel);
		}
		setVisible(true);
	}
	
	/**
	 * indique quel joueur on est (si on ne l'a pas dit � l'initielisation)
	 * @param numJoueur numero de nous
	 */
	public void setNous(int numJoueur){
		numNous=numJoueur;
		setTitle(new String("joueur "+numJoueur));
	}

	private void rotationImg(JLabel pieceLabel, ImageIcon pieceImage, int nbRot) {
		Image gna = pieceImage.getImage();
		BufferedImage bim = new BufferedImage(62, 62, BufferedImage.TYPE_INT_RGB);
		Graphics2D etc = (Graphics2D)(bim.getGraphics());
		AffineTransform rotation = AffineTransform.getRotateInstance(Math.PI/2 * nbRot, bim.getWidth(pieceLabel)>>1, bim.getHeight(pieceLabel)>>1);
		etc.drawImage(gna,rotation,pieceLabel);
		pieceLabel.setIcon(new ImageIcon(bim));
	}

	private ImageIcon selectImage(String nomImage) {
		return new ImageIcon(dossierCourant+"/"+nomImage);
	}


	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 */
	public void actionPerformed(ActionEvent e) {
		JButton evenSource = (JButton)e.getSource();
		if(evenSource == bRotation){
			prog.rotationPiece();
		}
		
		else if(evenSource == bRetournerPiece){
			prog.retournerPiece();
		}
		
		else if(evenSource == bPoserPiece){
			if( prog.poserPiece(selectPlateau.plateauX, selectPlateau.plateauY) ){
				//bValiderTour.setEnabled(false);
				//bPoserPiece.setLabel("Poser chasseur/loup");
			}
		}
		
		else if(evenSource == bRevelerCoul){
			if( selectPlateau!=null && prog.poserMonBerger(selectPlateau.plateauX, selectPlateau.plateauY) ){
				bRevelerCoul.setEnabled(false);
			}
			
		}
		else if(evenSource == bValiderTour){
			bValiderTour.setEnabled(false);
			bPoserPiece.setLabel("Poser chasseur/loup");
			prog.passerTour();
			
		}else if(evenSource == bAbandon){
			prog.abandonner();// la confirmation viendra apres
			
			//if(prog.abandonner()){
				bAbandon.setEnabled(false); //pour eviter un appuit suppl�mentaire
				//si c'est notre tour, on le "passe" ?
				/*if( prog.passerTour() ){
					bValiderTour.setEnabled(false);
					bPoserPiece.setEnabled(false);
				}*/
			//}
		
		//pour quitter le jeu "brutalement" (pour le moment du moins)
		}else if(evenSource == bQuitter){
			int ok=JOptionPane.showConfirmDialog(this, "Etes-vous s�r de vouloir quitter le jeu?", "confirmation", JOptionPane.YES_NO_OPTION);
			if(ok==0){ 
				prog.demandeQuitter();
			}
		}
	}
	
}

