public class Joueur {
	
	/**
	 * Pour savoir si on est encore de la partie
	 */
	private boolean connecte=true;
	
	/**
	 * Pour dire qu'on s'est deco
	 */
	public void deco(){
		connecte=false;
	}
	
	/**
	 *  POur savoir si on est deco
	 * @return true si deco
	 */
	public boolean isDeco(){
		return !connecte;
	}
	
	/**
	 * @uml.property  name="numero"
	 */
	private int numero;
	
	/**
	 * Getter of the property <tt>numero</tt>
	 * @return  Returns the numero.
	 * @uml.property  name="numero"
	 */
	public int getNumero() {
		return numero;
	}
	
	/**
		* Setter of the property <tt>numero</tt>
	 * @param numero  The numero to set.
	 * @uml.property  name="numero"
	 */
	public void setNumero(int numero) {
		this.numero = numero;
	}

	/**
	 * Le nom du joueur
	 */
	private String nom;
	
	/**
	 * change le nom du joueur
	 * @param n le nom � mettre
	 */
	public void setNom(String n){
		nom=n;
	}
	
	/**
	 * 
	 * @return le nom du joueur
	 */
	public String getNom(){
		return nom;
	}
	
	/**
		* @uml.property  name="aCouleur"
	 */
	private boolean aCouleur;
	
	/**
		* Getter of the property <tt>aCouleur</tt>
	 * @return  Returns the couleur.
	 * @uml.property  name="aCouleur"
	 */
	public boolean getACouleur() {
		return aCouleur;
	}
	
	/**
		* Setter of the property <tt>aCouleur</tt>
	 * @param aCouleur  The couleur to set.
	 * @uml.property  name="aCouleur"
	 */
	public void setACouleur(boolean aCouleur) {
		this.aCouleur = aCouleur;
	}
	
	/** 
		* @uml.property name="estCouleur"
		*/
	private int couleur;
	
	/** 
		* Getter of the property <tt>estCouleur</tt>
		* @return  Returns the estCouleur.
		* @uml.property  name="estCouleur"
		*/
	public int getCouleur() {
		return couleur;
	}
	
	/** 
		* Setter of the property <tt>estCouleur</tt>
		* @param estCouleur  The estCouleur to set.
		* @uml.property  name="estCouleur"
		*/
	public void setCouleur(int couleur) {
		this.couleur = couleur;
	}
	
	//garde en quel position il a abandonn�, 0=joue encore
	private int ordreFinPartie=0;
	
	public boolean joue(){
		return 0==ordreFinPartie;
	}
	
	public void setOdreFinPartie(int position){
		ordreFinPartie=position;
	}

	public int getOrdreFinPartie(){
		return ordreFinPartie;
	}
	
	public Joueur(){
		numero=0;
		couleur=0;
		aCouleur=false;
		nom="";
	}

	public Joueur(int num, String name){
		numero=num;
		couleur=0;
		aCouleur=false;
		nom=name;
	}
	
	public int nbPointClassement(){
		if(this.ordreFinPartie==1){
			return 6;
		}else if(ordreFinPartie==2){
			return 3;
		}else if(ordreFinPartie==3){
			return 1;
		}else{
			return 0;
		}
	}

	public void reinit() {
		this.aCouleur=false;
		this.ordreFinPartie=0;
	}
	
}


