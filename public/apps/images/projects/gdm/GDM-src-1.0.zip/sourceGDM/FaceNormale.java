
public class FaceNormale extends FaceTuile {

	public static final String type="Normale";
	
	/**
		* @uml.property  name="coteDuBas"
	 * @uml.associationEnd  inverse="faceNormale:Cote"
	 * @uml.association  name="aCote"
	 */
	private Cote coteDuBas;
	
	/**
		* Getter of the property <tt>cote>DuBas</tt>
	 * @return  Returns the coteDuBas.
	 * @uml.property  name="coteDuBas"
	 */
	public Cote getCoteDuBas() {
		return coteDuBas;
	}
	
	/**
		* Setter of the property <tt>cote</tt>
	 * @param cote  The cote to set.
	 * @uml.property  name="cote"
	 */
	public void setCoteDuBas(Cote cote) {
		this.coteDuBas = cote;
	}
	
	
	/**
		* @uml.property  name="nbRot"
	 */
	private int nbRot=0;
	
	/**
		* @return  Returns the number of rotation to have this cote.
	 * @uml.property  name="nbRot"
	 */
	public int getRotation() {
		return nbRot;
	}
	
	/**
	 * peut servir pour ajouter divers tuiles avec 4 cot�s identiques
	 * @param numFace
	 * @param coul
	 * @param nomFicImage
	 */
	public FaceNormale(int numFace, String coul, String nomFicImage){
		super(numFace,nomFicImage);
		
		nbRot = 0;
		
		//on cree un tableau de couleur
		String[] tempBuffCoul=new String[4];
		tempBuffCoul[0]=coul;
		tempBuffCoul[1]=coul;
		tempBuffCoul[2]=coul;
		tempBuffCoul[3]=coul;
		
		//ajout des faces
		coteDuBas=new Cote(tempBuffCoul);
	}

	/**
	 * pour creer un revers de berger ou un pate de maison...
	 */ 
	public FaceNormale( int coul){
		super(-1);
		nbRot = 0;
		
		//ajout de l'autre face (meme si jamais utilise, on sais jamais
		setFaceTuileSuivant(this);
		
		//on met le nom du fichier image
		switch(coul){
			case 0:
				this.setNomImage("moutons/tuileRose.jpg");
				break;
			case 1:
				this.setNomImage("moutons/tuileBleu.jpg");
				break;
			case 2:
				this.setNomImage("moutons/tuileJaune.jpg");
				break;
			case 3:
				this.setNomImage("moutons/tuileNoir.jpg");
				break;
			case 4:
				this.setNomImage("moutons/tuile_depart.jpg");
				break;
			case 5:
				this.setNomImage("moutons/tuileSecret.jpg");
				break;
		}
		
		//creation du tableau d'int pour ajout des faces
		int[] couleurs=new int[4];
		couleurs[0]=coul;
		couleurs[1]=coul;
		couleurs[2]=coul;
		couleurs[3]=coul;
		
		//ajout des faces
		coteDuBas=new Cote(couleurs);
	}
	
	public FaceNormale(int numFace, String[] stFace){
		super(numFace);
		
		nbRot = 0;
		
		//si on doit cree les deux faces
		if(stFace.length==8){
			String[] tempBuffCoul=new String[4];
			tempBuffCoul[0]=stFace[0];
			tempBuffCoul[1]=stFace[1];
			tempBuffCoul[2]=stFace[2];
			tempBuffCoul[3]=stFace[3];
			
			//ajout des faces
			coteDuBas=new Cote(tempBuffCoul);
			
			//ajout du fichier d'image
			setNomImage("moutons/tuile"+((numFace/2)+1)+".jpg");
			
			//on prepare la cretion de l'autre face
			tempBuffCoul[0]=stFace[4];
			tempBuffCoul[1]=stFace[5];
			tempBuffCoul[2]=stFace[6];
			tempBuffCoul[3]=stFace[7];
			
			//cree lautre face
			this.setFaceTuileSuivant(new FaceNormale(numFace+1,tempBuffCoul));
			
			//on lui dit que son autre cote cest nous
			this.getFaceTuileSuivant().setFaceTuileSuivant(this);
			
			//sinon, si on n'a que notre face a creer
		}else if(stFace.length==4){
			//ajout des faces
			coteDuBas=new Cote(stFace);
			
			//ajout du fichier d'image
			setNomImage("moutons/tuile"+((numFace+1)/2)+"b.jpg");
			
		}
	}
	
	public void afficheFaceTerminal(){
		System.out.println(super.getNomImage());
		System.out.println("\\ "+coteDuBas.getCoteSuivant().getCoteSuivant()+" /");
		System.out.println(coteDuBas.getCoteSuivant().getCoteSuivant().getCoteSuivant()+" X "+coteDuBas.getCoteSuivant());
		System.out.println("/ "+coteDuBas+" \\");
	}

	public void rotation(){
		coteDuBas = coteDuBas.getCoteSuivant();
		nbRot = (nbRot+1)%4;
	}
	
	/**
	* @return  Retourne le cote du bas si cote = 1, a droite si cote = 2, du haut si cote = 3, du gauche si cote = 4.
	*/
	public int getCouleurCote(int cote){
		switch(cote)
		{
			case 1:
				return coteDuBas.getCouleur();
			case 2:
				return coteDuBas.getCoteSuivant().getCouleur();
			case 3:
				return coteDuBas.getCoteSuivant().getCoteSuivant().getCouleur();
			case 4:
				return coteDuBas.getCoteSuivant().getCoteSuivant().getCoteSuivant().getCouleur();
		}
		return 0;
	}
	
	public int getNbRot(){
		return nbRot;
	}

	public Cote getCoteBas() {
		return coteDuBas;
	}

	public Cote getCoteDroite() {
		return coteDuBas.getCoteSuivant();
	}

	public Cote getCoteHaut() {
		return coteDuBas.getCoteSuivant().getCoteSuivant();
	}

	public Cote getCoteGauche() {
		return coteDuBas.getCoteSuivant().getCoteSuivant().getCoteSuivant();
	}
	
	public String getType() {
		return "Normale";
	}
}

