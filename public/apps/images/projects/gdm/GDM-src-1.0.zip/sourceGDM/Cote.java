public class Cote {

	public static final int ROSE=0;
	public static final int BLEU=1;
	public static final int JAUNE=2;
	public static final int NOIR=3;
	public static final int MAISON=4;
	public static final int FORET=5;
	
	/**
	 * sert pour le comptage des points
	 */
	private boolean estCompte;
	
	public boolean pasDejaCompte(){
		return !estCompte;
	}
	public void resetComptage(){
		estCompte=false;
	}
	public void compte(){
		estCompte=true;
	}
	
	/**
	 * @uml.property  name="cote2"
	 * @uml.associationEnd  inverse="cote1:Cote"
	 * @uml.association  name="coteSuivant"
	 */
	private Cote coteSuivant;
	
	/**
	 * Getter of the property <tt>cote2</tt>
	 * @return  Returns the cote2.
	 * @uml.property  name="cote2"
	 */
	public Cote getCoteSuivant() {
		return coteSuivant;
	}
	
	/**
		* Setter of the property <tt>cote2</tt>
	 * @param cote2  The cote2 to set.
	 * @uml.property  name="cote2"
	 */
	public void setCoteSuivant(Cote coteSuivant) {
		this.coteSuivant = coteSuivant;
	}
	
	
	/**
		* @uml.property  name="cote2"
	 * @uml.associationEnd  inverse="cote1:Cote"
	 * @uml.association  name="coteSuivant"
	 */
	private int couleur;
	
	/**
		* Getter of the property <tt>cote2</tt>
	 * @return  Returns the cote2.
	 * @uml.property  name="cote2"
	 */
	public int getCouleur() {
		return couleur;
	}
	
	/**
		* Setter of the property <tt>cote2</tt>
	 * @param cote2  The cote2 to set.
	 * @uml.property  name="cote2"
	 */
	public void setCouleur(int couleur) {
		this.couleur = couleur;
	}

	public static String coulToString(int coul){
		if(coul==0){
			return "rose";
		}
		else if(coul==1){
			return "bleu";
		}
		else if(coul==2){
			return "jaune";
		}
		else if(coul==3){
			return "noir";
		}
		else if(coul==4){
			return "village";
		}
		else if(coul==5){
			return "foret";
		}
		else{
			return "inconnu";
		}
	}

	/**
	 * 
	 * @param cotesCoul tableau de 4 String qui correspond � chaque "couleur" � ajouter pour chaque tuile, en partant du bas , dans le sens des aiguilles d'une montre.
	 */
	public Cote(String[] cotesCoul){
		
		if(cotesCoul[0].equalsIgnoreCase("rose")){
			couleur = 0;
		}
		else if(cotesCoul[0].equalsIgnoreCase("bleu")){
			couleur = 1;
		}
		else if(cotesCoul[0].equalsIgnoreCase("jaune")){
			couleur = 2;
		}
		else if(cotesCoul[0].equalsIgnoreCase("noir")){
			couleur = 3;
		}
		else if(cotesCoul[0].equalsIgnoreCase("village")){
			couleur = 4;
		}
		else if(cotesCoul[0].equalsIgnoreCase("foret")){
			couleur = 5;
		}
		
		//si pas le dernier, on cree le suivant
		if(cotesCoul.length > 1){
			String[] cotesCoulSuivt=new String[cotesCoul.length-1];
			for(int i=1;i<cotesCoul.length;i++){
				cotesCoulSuivt[i-1]=cotesCoul[i];
			}
			coteSuivant=new Cote(cotesCoulSuivt);
			
		}
		
		//si le premier, on indique au dernier qu'on est son suivant
		if(cotesCoul.length==4){
			this.getCoteSuivant().getCoteSuivant().getCoteSuivant().setCoteSuivant(this);
		}
		
	}

	/**
	 * 
	 * @param cotesCoul tableau de 4 entier qui correspond � chaque code couleur � ajouter pour chaque tuile, en partant du bas , dans le sens des aiguilles d'une montre.
	 */
	public Cote(int[] cotesCoul){
		
		//on ajoute la couleur
		couleur=cotesCoul[0];
		
		//si pas le dernier, on cree le suivant
		if(cotesCoul.length > 1){
			int[] cotesCoulSuivt=new int[cotesCoul.length-1];
			for(int i=1;i<cotesCoul.length;i++){
				cotesCoulSuivt[i-1]=cotesCoul[i];
			}
			coteSuivant=new Cote(cotesCoulSuivt);
			
		}
		
		//si le premier, on indique au dernier qu'on est son suivant
		if(cotesCoul.length==4){
			this.getCoteSuivant().getCoteSuivant().getCoteSuivant().setCoteSuivant(this);
		}
		
	}
	
	//utile pour le comptage des points, pour montrer les loups et chasseurs
	public Cote(int coteCoul){
		couleur=coteCoul;
		//inutile mais bon...
		coteSuivant=this;
	}
	
	public String toString(){
		String st=new String();
		if(couleur==0){
			st="R";
		}
		else if(couleur==1){
			st="B";
		}
		else if(couleur==2){
			st="J";
		}
		else if(couleur==3){
			st="N";
		}
		else if(couleur==4){
			st="M";
		}
		else if(couleur==5){
			st="F";
		}
		return st;
	}
}


