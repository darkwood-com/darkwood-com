import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.border.Border;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

public class FenetreReplay extends JFrame implements MaFenMouton, ActionListener{

	private String dossierCourant;
	private GDM prog;

	private int numNous=0;
	
	
	private JPanel fenJoueur;
	private JScrollPane fenJoueur2;
	private JPanel fenAction;
	private JPanel fenPlateau;
	private JScrollPane fenPlateau2;

	private JButton bSuivant = new JButton("Suivant");
	private JButton bQuitter = new JButton("Quitter");

	private int scrollX=0;
	private int scrollY=0;
	
	private static final int xMax = 800, yMax = 600;

	public FenetreReplay(String nomDossier, GDM progCourant){
		
		dossierCourant = nomDossier;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.prog = progCourant;

		this.setSize(xMax,yMax);
		this.getContentPane().setLayout(new BorderLayout());
		
		fenPlateau = new JPanel();
		fenAction = new JPanel();
		fenJoueur = new JPanel();
		
		fenAction.setLayout(new GridLayout(0,1));
		fenAction.setBackground(Color.MAGENTA);
		
		fenJoueur.setLayout(new FlowLayout());
		fenJoueur.setBackground(Color.MAGENTA);

		fenAction.add(bSuivant);
		fenAction.add(bQuitter);

		bSuivant.setEnabled(true);
		bSuivant.addActionListener(this);
		bQuitter.setEnabled(true);
		bQuitter.addActionListener(this);
		
		fenJoueur.setBackground(Color.GREEN);
		fenJoueur2= new JScrollPane(fenJoueur);
		fenPlateau.setBackground(Color.PINK);
		fenPlateau.setLayout(new GridLayout(Plateau.nbX, Plateau.nbY));
		fenPlateau2 = new JScrollPane(fenPlateau);
		fenPlateau2 = new JScrollPane(fenPlateau);
		AdjustmentListener liScrollX=new AdjustmentListener(){
			public void adjustmentValueChanged(AdjustmentEvent arg0) {
				scrollX=arg0.getValue();
			}
		};
		fenPlateau2.getHorizontalScrollBar().addAdjustmentListener(liScrollX);
		AdjustmentListener liScrollY=new AdjustmentListener(){
			public void adjustmentValueChanged(AdjustmentEvent arg0) {
				scrollY=arg0.getValue();
			}
		};
		fenPlateau2.getVerticalScrollBar().addAdjustmentListener(liScrollY);

		getContentPane().add(fenPlateau2,BorderLayout.CENTER);
		getContentPane().add(fenAction,BorderLayout.EAST);
		getContentPane().add(fenJoueur2,BorderLayout.NORTH);

		setTitle(new String("GDM-Replay"));
		setVisible(true);
	}

	public void cestMonTour(boolean oui) {
		//ne sert a rien
	}

	public void refreshPlateau(Plateau p) {
		FaceTuile piece;
		ImageIcon pieceImage;
		JLabelTuile pieceLabel;
		
		fenPlateau.removeAll();
		
		for(int j = 0; j < p.getYMax(); j++)
		{
			for(int i = 0; i < p.getXMax(); i++)
			{
				piece = p.getTuilePlateau(i, j);
				
				pieceLabel = new JLabelTuile();
				if(piece != null)
				{
					pieceImage = new ImageIcon(dossierCourant+"/"+piece.getNomImage());
//					faire tourner l'image
					rotationImg(pieceLabel, pieceImage, piece.getNbRot());
				}
				else
				{
					pieceImage = new ImageIcon(dossierCourant+"/"+"moutons/tuileVide.jpg");
					pieceLabel.setIcon(pieceImage);
				}
				fenPlateau.add(pieceLabel);
			}
		}
		//on met les scrollbar � leur emplacement
		JScrollBar scTemp=fenPlateau2.getHorizontalScrollBar();
		scTemp.setValue(scrollX);
		scTemp=fenPlateau2.getVerticalScrollBar();
		scTemp.setValue(scrollY);
		
		setVisible(true);
	}
	
	private void rotationImg(JLabel pieceLabel, ImageIcon pieceImage, int nbRot) {
		Image gna = pieceImage.getImage();
		BufferedImage bim = new BufferedImage(62, 62, BufferedImage.TYPE_INT_RGB);
		Graphics2D etc = (Graphics2D)(bim.getGraphics());
		AffineTransform rotation = AffineTransform.getRotateInstance(Math.PI/2 * nbRot, bim.getWidth(pieceLabel)>>1, bim.getHeight(pieceLabel)>>1);
		etc.drawImage(gna,rotation,pieceLabel);
		pieceLabel.setIcon(new ImageIcon(bim));
	}

	public void refreshMain(ArrayList maMain, FaceTuile tuileCourante) {
		// ne sert a rien (pour le moment?)
	}

	public void refreshJoueur(ArrayList joueur) {

		JLabel jLabel;
		int num;
		String buff;
		
		fenJoueur.removeAll();
		fenJoueur.repaint();
		
		for(int i=0;i<joueur.size();i++){
			num=((Joueur)joueur.get(i)).getNumero();
			if( (num) == numNous){
				//System.err.println( ((Joueur)joueur.get(i)).getNumero()+", "+((Joueur)joueur.get(i)).getNumero() );
				buff=" celui qui joue:";
			}else{
				buff= " j";
			}
			buff=buff+" n�"+ ((Joueur)joueur.get(i)).getNumero()
			+", "+((Joueur)joueur.get(i)).getNom()+" "
			+", coul="+ Cote.coulToString(((Joueur)joueur.get(i)).getCouleur());
			//on indique si il y a eu un abandon
			if( !((Joueur)joueur.get(i)).joue() ){
				buff=buff+(", abandon n�"+((Joueur)joueur.get(i)).getOrdreFinPartie());
			}
//			et si il est deco
			if(((Joueur)joueur.get(i)).isDeco()){
				buff=buff+" !DECONNECTE!";
			}
			buff=buff+(" ");
			jLabel=new JLabel(buff);
			jLabel.setBorder(BorderFactory.createLineBorder(Color.BLUE, 2));
			fenJoueur.add(jLabel);
		}
		setVisible(true);
	}

	public void setNous(int numJoueur) {
		numNous=numJoueur;
	}

	public void initPlateau() {
		// on met les scrollbar au milieu
		JScrollBar scTemp=fenPlateau2.getHorizontalScrollBar();
		scrollX=scTemp.getMaximum()/2-(fenPlateau2.getWidth()/2);
		scTemp.setValue(scrollX);
		scTemp=fenPlateau2.getVerticalScrollBar();
		scrollY=scTemp.getMaximum()/2-(fenPlateau2.getHeight()/2);
		scTemp.setValue(scrollY);
	}

	public void actionPerformed(ActionEvent e) {
		JButton evenSource = (JButton)e.getSource();
		if(evenSource == bSuivant){
			prog.replaySuivant();
		}else if(evenSource==bQuitter){
			int ok=JOptionPane.showConfirmDialog(this, "Etes-vous s�r de vouloir quitter le replay?", "confirmation", JOptionPane.YES_NO_OPTION);
			if(ok==0){ 
				System.exit(0); 
			}
		}
	}
	
	
	
}
