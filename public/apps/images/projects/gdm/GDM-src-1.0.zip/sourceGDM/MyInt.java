/**
 * 
 */
import java.lang.Integer;
/**
 * @author Remi
 *
 */
public class MyInt {
	public int entier;
	public String toString(){ return Integer.toString(entier); }
	public MyInt(){ entier=0; }
	public MyInt(int nb){entier=nb;}
}
