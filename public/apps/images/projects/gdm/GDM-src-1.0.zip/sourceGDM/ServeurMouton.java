import java.awt.Frame;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Reader;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Random;

import javax.swing.JOptionPane;

/*
* Created on 7 juin 2006
*
* TODO To change the template for this generated file go to
* Window - Preferences - Java - Code Style - Code Templates
*/

/**
* @author rdurand
*
* TODO To change the template for this generated type comment go to
* Window - Preferences - Java - Code Style - Code Templates
*/

public class ServeurMouton {

	private static final int nbTuilesDepart=4;
	private ArrayList _clientsFluxOut;
	private ArrayList _clientsNoms;
	private LinkedList _pioche;
	private LinkedList _gagnants;
	public static final int _nbFacePieces=128;
	private LinkedList _replay;
	private int _etat=0; //pour savoir si on ne joue pas=0, si on joue=1 ou si on regarde un replay=2
	private int numJoueurCourant=0;
	
	
	ServeurMouton(){
		//init
		_clientsFluxOut=new ArrayList();
		_gagnants=new LinkedList();
		_replay=new LinkedList();
		_clientsNoms=new ArrayList();
		
		creerPioche();
	}
	
	/**
	 * Pour creer la pioche, dans un ordre aleatoire
	 *
	 */
	private void creerPioche(){
		//var
		LinkedList temp=new LinkedList();
		Random aleat=new Random(System.currentTimeMillis());
		int numTemp,nbFaceMax;
		
		//init
		_pioche=new LinkedList();

		//ajout des tuiles, au hazard
		
		//pour cela, on contruit la liste de tous les numeros disponibles
		for(int i=0;i<_nbFacePieces;i+=2){
			temp.add(new Integer(i));
		}
		
		//tuile 24 deja utilis�, on la suppr
		temp.remove(12);
		nbFaceMax=temp.size();
		//on les transfere dans le bon tableau, unue par une, aleatoirement
		for(int i=0;i<nbFaceMax;i++){
			//prise d'un numero aleatoirement entre -temp.size et temp.size, non comprit
			numTemp=(aleat.nextInt()%temp.size());
			//on le remet en positif uniquement
			//numTemp=numTemp*Integer.signum(numTemp);
			if(numTemp<0){ numTemp=0-numTemp; }
			//on transfert le numero de tuile dans la tableau, en tete
			_pioche.add(temp.get(numTemp));
			temp.remove(numTemp);
		}
	}

	public void start(){
		start(33333);
	}
	public void start(int port){
		System.out.println("Serveur: lancement.");
		ServerSocket ss;
		try {
			ss = new ServerSocket(port); // ouverture d'un socket serveur sur port
			while (true) // attente en boucle de connexion (bloquant sur ss.accept)
			{
				new ThreadClientServeurMouton(ss.accept(), _clientsFluxOut, this); // un client se connecte, un nouveau thread client est lanc�
			}
		} catch (Exception e) { }

	}

	public int addClient(PrintWriter clientOut){
		System.out.println("Serveur: nouveau client!");
		//cas d'erreur: plein ou en train de jouer
		if(_clientsFluxOut.size()==4 || _etat!=0){
			System.out.println("Serveur: mais yen a deja asser, aller, ouste!");
			return 0;
		}
		
		//cas normal, on l'ajoute
		_clientsFluxOut.add(clientOut);
		_clientsNoms.add("");
		System.out.println("Serveur: c'est le num "+_clientsFluxOut.size()+".");
		return _clientsFluxOut.size();
	}
	
	/**
	 * permet d'avoir tt les pseudos, separe par des retours � la ligne (\\n)
	 * @param numJ
	 * @param out
	 */
	public String recupereNoms(){
		String st="";
		//pour chaque client
		for(int i=0;i<_clientsNoms.size();i++){
			//meme "nous"
			//if(i+1!=numJ){
				//on "nous" passe son pseudo/nom
				st=st+(String)_clientsNoms.get(i)+"\n";
			//}
		}
		return st;
	}

	/**
	 * 
	 * @return numero de la piece, -1 si plus de pieces
	 */
	public int donnePiece(){
		//var
		Integer temp;
		
		//test d'erreur
		if(_pioche.size()==0){ return -1; }
		//on prend une piece
		temp=(Integer)_pioche.getFirst();
		//on la suppr
		_pioche.removeFirst();
		System.out.println("Serveur: choix de la piece num "+temp+".");
		return temp.intValue();
	}

	public void distribuePioche(){

		System.out.println("Serveur: distribution des tuiles aux clients.");
		String stBuff;

		//on construit le tableau des couleurs des joueurs
		LinkedList temp=new LinkedList(),tabCoul=new LinkedList();
		int numTemp,nbMax,prem;
		Random aleat=new Random(System.currentTimeMillis());
		
		for(int i=0;i<4;i++){
			temp.add(new Integer(i));
		}
		nbMax=temp.size();
		//on les transfere dans le bon tableau, une par une, aleatoirement
		for(int i=0;i<nbMax;i++){
			//prise d'un numero aleatoirement entre -temp.size et temp.size, non comprit
			numTemp=(aleat.nextInt()%temp.size());
			//on le remet en positif uniquement
			//numTemp=numTemp*Integer.signum(numTemp);
			if(numTemp<0){numTemp=0-numTemp;}
			//on transfert le numero de tuile dans la tableau, en tete
			tabCoul.add(temp.get(numTemp));
			temp.remove(numTemp);
		}
		
		System.out.println("Serveur: nbCli="+_clientsFluxOut.size());
		//pour chaque client (sauf ceux deco)
		for(int i=0; i<_clientsFluxOut.size(); i++){
		  if(_clientsFluxOut.get(i)!=null){
			//on indique notre couleur, le nombre de joueurs
			//on met l'en-tete
			System.out.println("Serveur: envoie d'un message d'initialisation au joueur "+Integer.toString(i+1));
			stBuff="4"+((Integer)tabCoul.get(i)).toString()+'\n'+Integer.toString(_clientsFluxOut.size())+'\n'+recupereNoms();
			//on envoie les pieces au client
			((PrintWriter)_clientsFluxOut.get(i)).write(stBuff);
			((PrintWriter)_clientsFluxOut.get(i)).flush();
			
			
			//on distribue les cartes
			//on met l'en-tete
			
			stBuff="t"+Integer.toString(nbTuilesDepart)+"\n";
			//on lui met les numeros de face pieces tir� de la pioche
			for(int j=0; j<nbTuilesDepart; j++){
					System.out.println("Serveur: tuile n�"+j);
					// on ne fait pas de test d'erreur car � la pioche du debut, on a forc�ment assez de pieces
					stBuff=stBuff+Integer.toString(donnePiece())+"\n";
			}
			//on envoie les pieces au client
			System.out.println("Serveur: envoie d'une pioche");
			((PrintWriter)_clientsFluxOut.get(i)).write(stBuff);
			((PrintWriter)_clientsFluxOut.get(i)).flush();
			
			//la partie commence
			_etat=1;
		  }
		}
		
//		stockage de l'initialisation
		//du j1
		addCommande("4"+((Integer)tabCoul.get(0)).toString()+'\n'+Integer.toString(_clientsFluxOut.size())+'\n'+recupereNoms(),1);
		//des autres j
		for(int i=1; i<_clientsFluxOut.size(); i++){
			addCommande('g'+Integer.toString(i+1)+'\n'+((Integer)tabCoul.get(i)).toString()+'\n', i+1);
		}
		
		//on dit � un joueur qu'il peut commencer (si il y en a)
		prem=aleat.nextInt()%_clientsFluxOut.size();
		if(prem<0){prem=0-prem;}
		int nbIterationMax=100;
		 //tant que l'on en a pas trouv� 1
		while(_clientsFluxOut.get(prem)==null && nbIterationMax>0){
			prem=aleat.nextInt()%_clientsFluxOut.size();
			if(prem<0){prem=0-prem;}
			nbIterationMax--;
		}
		if(nbIterationMax==0){ System.exit(0); }// au cas ou
		((PrintWriter)_clientsFluxOut.get(prem)).write('6');
		((PrintWriter)_clientsFluxOut.get(prem)).flush();
		numJoueurCourant=prem+1;
	}

	public int abandonne(int num){
		System.out.println("Serveur : le joueur n�"+num+" a andondonn�.");
		_gagnants.add(new Integer(num));
		return _gagnants.size();
	}

	public boolean aAbandonne(int num){
		Iterator it=_gagnants.iterator();
		boolean pastrouve=true;
		while(it.hasNext() && pastrouve){
			pastrouve=((Integer)it.next()).intValue() != num;
			
		}
		return !pastrouve;
	}

	public void finPartie() {
		_etat=0;
		
		Iterator it=_clientsFluxOut.iterator();
		PrintWriter out;
		while(it.hasNext()){
			out=(PrintWriter)it.next();
			if(out!=null){
				out.write("f");
				out.flush();
			}
		}
	}
	
	/**
	 * Permet de (re)lancer une nouvelle partie
	 *
	 */
	public void reinit() {
		creerPioche();
		_gagnants=new LinkedList();
		_replay=new LinkedList();
	}

	public static void main(String[] args)throws Exception{
		ServeurMouton serv=new ServeurMouton();
		serv.start();
	}
	
	public void addCommande(String commande, int numClient){
		_replay.add(new Action(commande,numClient));
	}
	
	public void doNextStepOfReplay(){
		System.out.println("Serveur: iteration suivante");
		Iterator it=_clientsFluxOut.iterator();
		PrintWriter output;
		if(_replay.size()>0){
			Action actuelle=(Action)_replay.removeFirst();		
			while(it.hasNext()){
				output=(PrintWriter)it.next();
				if(it!=null){
					//output.write("n"+actuelle.numeroJoueur+"\n");
					//output.flush();
					//System.out.println("Serveur: "+actuelle.commande);
					output.write(actuelle.commande);
					output.flush();
				}
			}
		}else{
			System.out.println("Serveur: plus de trames");
			while(it.hasNext()){
				output=(PrintWriter)it.next();
				if(it!=null){
					output.write("f");
					output.flush();
				}
			}
			//JOptionPane.showMessageDialog(new Frame(), "Fin de la partie", "Etat du replay",JOptionPane.YES_OPTION );
		}
	}

	public void sauverReplay(String empl){
		System.out.println("Serveur: sauver le replay");
		Iterator it=_replay.iterator();
		Action actuelle;
		PrintWriter output;
		try {
			output = new PrintWriter( new BufferedWriter(new FileWriter(empl)));
			while(it.hasNext()){
				actuelle=(Action)it.next();
				//output.write("n"+actuelle.numeroJoueur+"\n");
				//output.flush();
				//System.err.print("------------------j'ecris:----------------\n"+'1'+actuelle.numeroJoueur+"\n"+actuelle.commande);
				output.write("1"+Integer.toString(actuelle.numeroJoueur)+"\n"+actuelle.commande);
			}
			//fin de fichier
			output.write('0');
			output.close();
		} catch (IOException e) {
			e.printStackTrace();
		}	
		
	}

	public void chargerPartie(String empl){
		System.out.println("Serveur: charger le replay");
		Iterator it=_replay.iterator();
		BufferedReader input;
		int numJ;
		String st1,tempSt;
		char[] c=new char[1];
		
		//init
		_replay.clear();
		
		try {
			//creation du lecteur
			input = new BufferedReader( new FileReader(empl));
			//init while
			input.read(c, 0, 1);
			while(c[0]=='1'){
				//lecture du numero de joueur
				st1=input.readLine();
				numJ=Integer.parseInt(st1);
				//lecture de l'en-tete
				input.read(c, 0, 1);
				//System.out.println("Serveur: lecture d'une commande ("+c[0]+").");
				switch(c[0]){
					case '4':
						//"4"+((Integer)tabCoul.get(0)).toString()+'\n'+Integer.toString(_clientsFluxOut.size())+'\n'+t les noms
						String stEnd;
						int nbC;
						//on prend la couleur
						stEnd=input.readLine()+"\n";
						//on prend le nombre de joueurs
						nbC=Integer.parseInt(input.readLine());
						stEnd=stEnd+Integer.toString(nbC)+"\n";
						//on prend les noms des joueurs
						for(int i=0;i<nbC;i++){
							stEnd=stEnd+input.readLine()+"\n";
						}
						//on stocke le tt
						_replay.add(new Action('4'+stEnd, numJ));
						break;
					case 'd':
						//'d'+numTuile+'\n'+nbRotation+'\n'+x+'\n'+y+'\n'
						_replay.add(new Action('d'+input.readLine()+'\n'+input.readLine()+'\n'+input.readLine()+'\n'+input.readLine()+'\n', numJ));
						break;
					case 'g':
						_replay.add(new Action('g'+input.readLine()+'\n'+input.readLine()+'\n', numJ));
						break;
					case 'z':
						_replay.add(new Action('z'+input.readLine()+'\n'+input.readLine()+'\n', numJ));
						break;
					case 'l':
						_replay.add(new Action('l'+input.readLine()+'\n'+input.readLine()+'\n'+input.readLine()+'\n', numJ)); //en fait, on connait le nmero du joueur
						break;
					case 'n':
						_replay.add(new Action('n'+input.readLine()+'\n', numJ));
						break;
					case '-':
						tempSt=input.readLine();
						_replay.add(new Action('-'+tempSt+'\n', Integer.parseInt(tempSt)));
						break;
					default:
						System.err.println("message inconnu: "+c[0]+", fichier corrompu.");
						break;
				}
				
				//relance
				input.read(c, 0, 1);
			}
			input.close();
			
			//ensuite, on lit les messages d'initialisation (le premier donne le nombre de joueur)
			String stTemp= ((Action)_replay.getFirst()).commande;
			int taille=Integer.parseInt(String.valueOf( stTemp.charAt(3) ));
			//on les transmets
			for(int i=0;i<taille;i++){
				this.doNextStepOfReplay();
			}
			
			//on se met en mode replay
			_etat=2;
			
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public boolean partieInactive(){
		return _etat==0;
	}
	
	public boolean partieJoue(){
		return _etat==1;
	}
	
	public boolean partieReplay(){
		return _etat==2;
	}

	/**
	 * permet de mettre � jour la liste des pseudos
	 * @param client le numero du client (4>client>0)
	 * @param nom le psudo, ou nom
	 */
	public void setNom(int client, String nom) {
		_clientsNoms.set(client-1, nom);
	}

	/**
	 * Deconnecte proprement le joueur
	 * @param numClient le numero du joueur � deconnecter
	 */
	public boolean deconnection(int numClient) {
		int nbJoue=0;
		//on le "supprime"
		_clientsFluxOut.set(numClient-1, null);
		
		//et on le dit aux autres
		for(int i=0;i<_clientsFluxOut.size();i++){
			
			if(_clientsFluxOut.get(i)!=null){
				if(!aAbandonne(i+1)){ nbJoue++; }
				((PrintWriter)_clientsFluxOut.get(i)).write("-"+numClient+"\n");
				((PrintWriter)_clientsFluxOut.get(i)).flush();
			}
		}
		
		//si plus de joueurs jouant, on declenche la fin de jeu
		if(nbJoue==0){
			finPartie();
		}
		
		//on le sauve
		addCommande("-"+numClient+"\n",numClient);
		
		//si joueur courant, on passe au suivant
		if(numClient==numJoueurCourant){
			return true;
		}
		return false;
	}
	
	public void setJoueurCourant(int numJ){
		this.numJoueurCourant=numJ;
	}
	
	public void prendreLaMain(int numJ){
		System.out.println("Serveur: il prend la main");
		//on indique � celui qui joue que ce n'est plus � lui
		((PrintWriter)_clientsFluxOut.get(numJoueurCourant-1)).write("r");
		((PrintWriter)_clientsFluxOut.get(numJoueurCourant-1)).flush();

		//on stocke l'info pour replay
		addCommande("n"+numJ+"\n",numJ);
	}
	
	public void redonnerLaMain(){
		System.out.println("Serveur: il rend la main");
		//on indique � celui qui l'avais que c'est plus bon
		((PrintWriter)_clientsFluxOut.get(numJoueurCourant-1)).write("6");
		((PrintWriter)_clientsFluxOut.get(numJoueurCourant-1)).flush();
		
		//on stocke l'info pour replay
		addCommande("n"+numJoueurCourant+"\n",numJoueurCourant);
	}
	
}


