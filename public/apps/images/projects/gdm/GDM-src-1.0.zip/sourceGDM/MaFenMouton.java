import java.util.ArrayList;

public interface MaFenMouton {
	
	public void cestMonTour(boolean cestVrai);

	public void refreshPlateau(Plateau p);
	
	/**
	 * 
	 * @param maMain array list de FaceTuiles
	 */
	public void refreshMain(ArrayList maMain, FaceTuile tuileCourante);
	
	/**
	 * 
	 * @param Joueur ArrayList de Joueur
	 */
	public void refreshJoueur(ArrayList joueur);
	
	/**
	 * indique quel joueur on est (si on ne l'a pas dit � l'initielisation)
	 * @param numJoueur numero de nous
	 */
	public void setNous(int numJoueur);
	
	/**
	 * pour mettre les scrollbar au milieu au debut de la partie
	 */
	public void initPlateau();
	
}
