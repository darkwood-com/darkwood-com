import java.awt.Frame;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PipedWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Iterator;

import javax.swing.JOptionPane;

/**
 * 
 */

/**
 * @author Remi
 *
 */
public class ThreadClientMouton implements Runnable{

	private Thread _t; //le thread
	private BufferedReader _in; // pour gestion du flux d'entr�e
	private PipedWriter _out; //pour dire au programme ce que l'on a lu, quand c'est n�c�ssaire
	private GDM _monClient;

	ThreadClientMouton(BufferedReader input, PipedWriter output, GDM client){
		//vars
		char[] cBuff=new char[1];
		int num;
		//init
		_in=input;
		_out=output;
		_monClient=client;
		try {
			//on attend le code retour pour voir comment s'est pass� la connexion
			_in.read(cBuff);
			//en principe,/\cbuff[0]==1
			//lecture code retour
			_in.read(cBuff);
			num=Integer.parseInt(Character.toString(cBuff[0]));
			if(cBuff[0]!='0'){
				_t=new Thread(this);
				//on est connect�
				_monClient.setNum(num);
				System.out.println("Connect�, num="+num+".");
				//on reprend le message qui nous est destine (pour l'explication)
				System.out.println(_in.readLine());
				//on repercute?
				_out.write('1');
				_out.flush();
				//on demmarre
				//try{_out.write(1);}catch(Exception e){ e.printStackTrace(); }
				_t.start();
			}else{
				
				//on est rejet�
				String msg;
				msg=_in.readLine();
				System.out.println("Pas connect�, "+msg);
				//on repercute?
				_out.write('0');
				_out.flush();
			}
		} catch (IOException e){ e.printStackTrace(); }
	}

	public void run() {
		char[] lire=new char[1]; //pour lire un caractere (le code)
		boolean pasQuitter=true;
		//try{_out.write(1);}catch(Exception e){ e.printStackTrace(); }
		try {
			System.out.println("Recepteur: en attente de messages");
			//lecture du code
			while(pasQuitter ){
				_in.read(lire,0,1);
				System.out.println("Recepteur : reception d'un message.");
				//on regarde le code du message
				switch(lire[0]){
					case 'q':
						System.out.println("recoit un pseudo d'un joueur");
						prendPseudo();
						break;
					case '3':
						System.out.println("demarrage partie");
						demarragePartie();
						break;
					case '4':
						System.out.println("recoit couleur");
						recoitCouleur();
						break;
					case '6':
						System.out.println("mon tour");
						monTour();
						break;
					case 't':
						System.out.println("recoit tuiles");
						recoitTuiles();
						break;
					case 'd':
						System.out.println("pose piece");
						posePiece();
						break;
					case 'g':
						System.out.println("couleur revele");
						couleurRevele();
						break;
					case 'r':
						System.out.println("on donne la main");
						plusMonTour();
						break;
					case 'j':
						System.out.println("place d'abandon donn�e");
						confirmationAbandon();
						break;
					case 'z':
						System.out.println("Un joueur a abandonn�");
						joueurAbandon();
						break;
					case 'l':
						System.out.println("berger pos�");
						poseBerger();
						break;
					case 'f':
						System.out.println("fin de la partie");
						finPartie();
						break;
					case '0':
						System.out.println("fermeture autoris�");
						quitter();
						pasQuitter=false; //jamaias execute car quitter fait System.exit
						break;
					case '-':
						System.out.println("quelqu'un s'est deconnecte");
						deconnectionJoueur();
						break;
					//pour le replay
					case 'n':
						System.out.println("changement de joueur courant");
						setNumJoueurCourant();
						break;
					default:
						System.out.println("message inconnu: "+lire[0]);
						JOptionPane.showMessageDialog(_monClient.getFrame(), "Erreur de reception, Probleme de connection avec le serveur.", "Erreur",JOptionPane.ERROR_MESSAGE );
						//que faire?
						System.exit(0);
						break;
				}
				//reinitialisation du flux d'entree
				//_in.reset();
			}

		} catch (Exception e){
			//si connection avec le serveur interrompu
			System.err.println("Recepteur: Crash du serveur"); 
			
			//on l'indique au programme
			_monClient.gereDeco(1);
		}
		System.out.println("Recepteur: deconnexion.");
	}

	private void plusMonTour() {
		_monClient.setEstMonTour(false);
	}

	private void deconnectionJoueur() {
		int numDeco;
		try {
			numDeco=Integer.parseInt(_in.readLine());
			_monClient.gereDeco(numDeco);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void quitter() {
		_monClient.exit();
	}

	private void prendPseudo() {
		try {
			int numJ=Integer.parseInt(_in.readLine());
			String nomJ=_in.readLine();
			_monClient.changeNomJ(numJ,nomJ);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void finPartie() {
		_monClient.finPartie();
	}

	/**
	 * appel� pour le replay
	 * definit le joueur courant
	 */
	private void setNumJoueurCourant() {
		try{
			String st=_in.readLine();
			_monClient.changerNum(Integer.parseInt(st));
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	private void joueurAbandon() {
		String numJ,place;
		try{
			numJ=_in.readLine();
			place=_in.readLine();
			_monClient.signalAbandon(Integer.parseInt(numJ), Integer.parseInt(place) );
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}

	private void confirmationAbandon() {
		String st="0";
		try{
			st=_in.readLine();
		//	_out.write(st);
		}catch(Exception e){
			e.printStackTrace();
			/*try{
				_out.write("0");
			}catch(Exception e2){e.printStackTrace();}*/
		}
		_monClient.confirmationAbandon(Integer.parseInt(st));
	}

	private void recoitCouleur() {
		int coulJ,nbJ;
		ArrayList tabNomJ=new ArrayList();
		try{
			//lecture de la coul
			coulJ=Integer.parseInt(_in.readLine());
			//lecture du nb de joueur
			nbJ=Integer.parseInt(_in.readLine());
			//prise de noms de joueurs (meme nous)
			for(int i=0; i<nbJ;i ++){
				tabNomJ.add(new String(_in.readLine()));
			}
			//on le dit au prog
			this._monClient.construitJoueurs(coulJ, nbJ, tabNomJ);
		}catch(IOException e){ e.printStackTrace(); }
	}

	/**
	 * un joueur a revele sa couleur
	 * on doit indiquer sa couleur
	 */
	private void couleurRevele() {
		String stBuff;
		int numJ,coul,x,y;
		
		try{
			//on prend le num du joueur
			stBuff=_in.readLine();
			numJ=Integer.parseInt(stBuff);
			//on prend la coul
			stBuff=_in.readLine();
			coul=Integer.parseInt(stBuff);
			
			//on indique au prog q'une couleur est r�v�l�
			_monClient.setCouleurJoueur(numJ,coul);
			
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	/**
	 * on doit ajouter sa tuile de berger
	 */
	private void poseBerger() {
		String stBuff;
		int numJ,coul,x,y;
		
		try{
			//on prend la coul
			stBuff=_in.readLine();
			coul=Integer.parseInt(stBuff);
			//on prend le x
			stBuff=_in.readLine();
			x=Integer.parseInt(stBuff);
			//on prend le y
			stBuff=_in.readLine();
			y=Integer.parseInt(stBuff);
			
			//on indique au prog de le rajouter
			_monClient.poserBerger(coul,x,y);
			
		}catch(IOException e){
			e.printStackTrace();
		}
	}

	private void posePiece() {
		String stBuff;
		int numTuile,rot,x,y;
		
		try{
			//on prend le num de la tuile
			stBuff=_in.readLine();
			numTuile=Integer.parseInt(stBuff);
			//on prend la rot
			stBuff=_in.readLine();
			rot=Integer.parseInt(stBuff);
			//on prend le x
			stBuff=_in.readLine();
			x=Integer.parseInt(stBuff);
			//on prend le y
			stBuff=_in.readLine();
			y=Integer.parseInt(stBuff);
			
			//on indique au prog de le rajouter
			_monClient.poserPiece(numTuile,rot,x,y);
			
		}catch(IOException e){
			System.err.println(e);
		}
		
	}

	private void monTour() {
		_monClient.setEstMonTour(true);
	}

	private void recoitTuiles() {
		try{
			//var
			String stBuff;
			int nbTuiles;
			//on lit le nombre de tuiles
			stBuff=_in.readLine();
			nbTuiles=Integer.parseInt(stBuff);
			//on prend les tuiles
			for(int i=0;i<nbTuiles;i++){
				stBuff=_in.readLine();
				//on les ajoute � la main
				_monClient.ajouterPieceMain(Integer.parseInt(stBuff));
			}
		}catch(IOException e){ e.printStackTrace(); }
	}

	private void demarragePartie() {
		char[] cBuff=new char[1];
			try{
			//on regarde la reponse
			_in.read(cBuff,0,1);
			//si pas encore
			if(cBuff[0]=='0'){
				JOptionPane.showConfirmDialog(_monClient.getFrame(), "Impossible de lancer la partie.\n" +
						"C'est le joueur 1 qui doit le faire.", "Erreur", JOptionPane.ERROR_MESSAGE);
				//_out.write('0');
				//_out.flush();
			}else{
				//sinon, cool
				//et on signale que c'est ok
				//_out.write('1');
				//_out.flush();
			}
		}catch(IOException e){e.printStackTrace(); }
	}


}
