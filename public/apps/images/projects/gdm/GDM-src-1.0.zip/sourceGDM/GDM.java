import java.awt.Frame;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class GDM {

	/**
	 * @uml.property  name="etat"
	 */
	private String etat = "";

	/**
	 * @uml.property  name="numJoueur"
	 */
	private MaFenMouton lienInterfaceGraph=null;
	
	/**
	 * @uml.property  name="estMonTour"
	 */
	private boolean estMonTour = false;


	/**
	 * @uml.property  name="moi"
	 * @uml.associationEnd  inverse="gDM:Moi"
	 * @uml.association  name="moiMeme"
	 */
	private Moi moiMeme;


	/**
	 * @uml.property  name="monPlateau"
	 * @uml.associationEnd  inverse="gDM:Plateau"
	 * @uml.association  name="aPlateau"
	 */
	private Plateau monPlateau;

	/** 
	 * @uml.property name="joueurs"
	 * @uml.associationEnd multiplicity="(1 -*)" inverse="gDM:Joueur"
	 */
	private Collection joueurs;


	/** 
	 * @uml.property name="tuilesDuJeu"
	 * @uml.associationEnd  inverse="gDM:FaceTuile"
	 * @uml.association  name="tuilesDuJeu"
	 */
	private Collection tuilesDuJeu;

	
	/**
	 * Getter of the property <tt>etat</tt>
	 * @return  Returns the etat.
	 * @uml.property  name="etat"
	 */
	public String getEtat() {
		return etat;
	}

	/**
	 * Setter of the property <tt>etat</tt>
	 * @param etat  The etat to set.
	 * @uml.property  name="etat"
	 */
	public void setEtat(String etat) {
		this.etat = etat;
	}


	/** 
	 * Getter of the property <tt>joueur</tt>
	 * @return  Returns the joueur.
	 * @uml.property  name="joueur"
	 */
	public Collection getJoueurs() {
		return joueurs;
	}

	/** 
	 * Setter of the property <tt>joueur</tt>
	 * @param joueur  The joueur to set.
	 * @uml.property  name="joueur"
	 */
	public void setJoueurs(Collection joueurs) {
		this.joueurs = joueurs;
	}


	/**
	 * Getter of the property <tt>moi</tt>
	 * @return  Returns the moi.
	 * @uml.property  name="moi"
	 */
	public Moi getMoiMeme() {
		return moiMeme;
	}

	/**
	 * Setter of the property <tt>moi</tt>
	 * @param moi  The moi to set.
	 * @uml.property  name="moi"
	 */
	public void setMoiMeme(Moi moiMeme) {
		this.moiMeme = moiMeme;
	}

	/**
	 * Getter of the property <tt>plateau</tt>
	 * @return  Returns the plateau.
	 * @uml.property  name="monPlateau"
	 */
	public Plateau getPlateau() {
		return monPlateau;
	}

	/**
	 * Setter of the property <tt>plateau</tt>
	 * @param plateau  The plateau to set.
	 * @uml.property  name="plateau"
	 */
	public void setPlateau(Plateau plateau) {
		this.monPlateau = plateau;
	}
	
	/**
	 * affiche l'etat du plateau
	 */
	public void afficherPlateau() {
		monPlateau.afficherPlateau();
	}
	
	/**
	 * connexion avec le serveur
	 */
	SocketClientMouton connexion;


	/**
	 * cree moimeme, init joueurs, tuiles, plateau
	 * @param nomDossier nom du dossier ou sont les images des tuiles et le fichier des donnees de tuiles
	 */
	public GDM(String nomDossier){
//		init joueurs
		moiMeme = new Moi();
		joueurs = new ArrayList();
		joueurs.add(moiMeme);
			
		//init tuiles
		initTuiles(nomDossier);

		//init plateau
		FaceTuile maisons=new FaceNormale(4);
		monPlateau = new Plateau(maisons);
		
	}
	
	/**
	 * cree moimeme, init joueurs, tuiles, plateau
	 * @param nomDossier nom du dossier ou sont les images des tuiles et le fichier des donnees de tuiles
	 */
	public void connectionServeurJeu( String nomDossier, int port, String adresse, String pseudo){

		etat="Joue";
		
		//init Interface graphique
		lienInterfaceGraph=new Fenetre(nomDossier, this);
		lienInterfaceGraph.refreshPlateau(monPlateau);
		//lienInterfaceGraph.initPlateau();
		
		//init connexion avec le serveur
		try{
			connexion=new SocketClientMouton(adresse,port,pseudo,this);
	
		}catch(Exception e){ 
			JOptionPane.showMessageDialog((Frame)lienInterfaceGraph, "Impossible de se connecter au serveur", "Erreur",JOptionPane.YES_OPTION );
			System.exit(0);
		}
		
	}

	/**
	 * Pour voir un replay
	 * @param nomDossier
	 * @param port
	 * @param adresse
	 * @param nomFic chemin et nom du fichier o� est stock� le replay
	 */
	public void connectionServeurReplay( String nomDossier, int port, String adresse, String nomFic) {

		etat="Replay";
		
		//init Interface graphique
		lienInterfaceGraph=new FenetreReplay(nomDossier, this);
		lienInterfaceGraph.refreshPlateau(monPlateau);
		lienInterfaceGraph.initPlateau();
		
		//init connexion avec le serveur
		try{
			connexion=new SocketClientMouton(adresse,port,"",this);
	
		}catch(Exception e){ e.printStackTrace(); }
		
		//on charge le replay
		connexion.chargerPartie(nomFic);
	}

	/**
	 * 
	 * @param nomDossier nom du dossier ou sont les images des tuiles et le fichier des donnees de tuiles, il doit finir par un slash
	 */
	private void initTuiles(String nomDossier){
		BufferedReader ficLect;
		String buffer;
		String[] tabBuffer;
		String[] tabBufferTemp;
		int numeroFace;
		FaceTuile tempTuile;
		
		//init
		tuilesDuJeu=new ArrayList();
		  
		try{
			//inFic=new FileInputStream(nomFic);
			ficLect=new BufferedReader(
				  	new InputStreamReader(
				  		new FileInputStream(nomDossier+"/tuiles.dat")));
			  //pour chaque ligne, jusqu'a la fin du fichier
			numeroFace=0;
			while(ficLect.ready()){
				buffer=ficLect.readLine();
				tabBuffer=buffer.split(String.valueOf((char)9));
				//traitement specifique pour les tuiles a 4 forets
				if(tabBuffer.length > 8){
					tempTuile=new FaceSpeciale(numeroFace, tabBuffer[8], tabBuffer[4]);
				}else{
					tabBufferTemp = new String[8];
					
					tabBufferTemp[0] = new String(tabBuffer[3]);
					tabBufferTemp[1] = new String(tabBuffer[2]);
					tabBufferTemp[2] = new String(tabBuffer[1]);
					tabBufferTemp[3] = new String(tabBuffer[0]);
					tabBufferTemp[4] = new String(tabBuffer[7]);
					tabBufferTemp[5] = new String(tabBuffer[6]);
					tabBufferTemp[6] = new String(tabBuffer[5]);
					tabBufferTemp[7] = new String(tabBuffer[4]);
					
					tabBuffer = tabBufferTemp;
					
					tempTuile=new FaceNormale(numeroFace, tabBuffer);
				}
				
				//ajout dans la liste
				tuilesDuJeu.add(tempTuile);
				tuilesDuJeu.add(tempTuile.getFaceTuileSuivant());
				
				numeroFace+=2; //car on a ajoute deux faces
		  	}
		}catch(Exception e){
			e.printStackTrace();
			JOptionPane.showMessageDialog(getFrame(), "Erreur, impossible de lire le fichier tuiles.dat.", "Erreur",JOptionPane.ERROR_MESSAGE );
			System.exit(0);
		}
	}
	
	/**
	 * affiche la liste des cates sur la sortie standard
	 */
	public void afficherListeCartes(){
		Iterator it=tuilesDuJeu.iterator();
		while(it.hasNext()){
			System.out.println();
			((FaceTuile)it.next()).afficheFaceTerminal();
		}
	}
	
	/**
	 * rechercher une carte dans la liste de carte
	 * @param numero de la carte a rechercher
	 * @return  Returns le pointeur de cette carte si elle est trouvee, null sinon
	 */
	public FaceTuile rechercherCarte(int numero) {
		FaceTuile tuile;
		Iterator it=tuilesDuJeu.iterator();
		while(it.hasNext()){
			tuile = (FaceTuile) it.next();
			if(tuile.getNumero() == numero) return tuile;
		}
		return null;
	}
	
	/**
	 * affiche la carte selon son numero sur la sortie standard
	 * @param numero de la carte
	 */
	public void afficherCarte(int numero) {
		FaceTuile tuile;
		tuile = rechercherCarte(numero);
		if (tuile != null)
		{
			System.out.println("Carte numero "+tuile.getNumero());
			tuile.afficheFaceTerminal();
		}
		else
		{
			System.out.println("La carte n'existe pas");
		}
	}
	
	/**
	 * 
	 * @return vrai si on a bien pris la piece choisie dans notre main, non si on a plus de carte
	 * @param numCase est le numero de la piece choisie
	 */
	public boolean prendrePieceMain(int numCase){
		boolean ok=moiMeme.prendrePieceMain(numCase);
		this.lienInterfaceGraph.refreshMain((ArrayList)getMoiMeme().getMaMain(), getMoiMeme().getPieceCourante());
		return ok;
	}
	
	/**
	* ajouter une piece a sa main
	* @param numero de la piece suivant la liste de carte
	*/
	public void ajouterPieceMain(int numero){
		if(numero >= 0 && numero < tuilesDuJeu.size())
		{
			moiMeme.addPieceMain((FaceTuile)((ArrayList)tuilesDuJeu).get(numero));
		}
		this.lienInterfaceGraph.refreshMain((ArrayList)moiMeme.getMaMain(),moiMeme.getPieceCourante());
		//this.lienInterfaceGraph.refreshPlateau(monPlateau);
	}
	
	/**
	* afficher les pieces de sa main
	* @param numero de la piece suivant la liste de carte
	*/
	public void afficherMain(){
		moiMeme.afficherMain();
	}
	
	/**
	 * 
	 * @return vrai si on a une piece dans la main, faux sinon
	 */
	public boolean rotationPiece(){
		boolean estRotationne = moiMeme.rotationPiece();

		this.lienInterfaceGraph.refreshMain((ArrayList)getMoiMeme().getMaMain(), getMoiMeme().getPieceCourante());
		return estRotationne;
	}
	
	/**
	 * 
	 * @return vrai si on a une piece dans la main, faux sinon
	 */
	public boolean retournerPiece(){
		boolean estRetourne = moiMeme.retournerPiece();

		this.lienInterfaceGraph.refreshMain((ArrayList)getMoiMeme().getMaMain(), getMoiMeme().getPieceCourante());
		return estRetourne;
	}
	
	
	/**
	* poser une piece de sa main sur le plateau de jeu (en meme temps recupere des cartes dans la pioche)
	* @param coordonnees X et Y ou on veux poser la piece
	* @return vrai si on peux poser la piece, faux si on peux pas (pas de piece dans la main courant, la piece ne peux pas se poser a l'endroit indique)
	*/
	public boolean poserPiece(int x, int y) {
		int nombrePieceObtenue;
		FaceTuile tuile;
		
		//verifier si le joueur a une piece dans sa main
		if(moiMeme.getPieceCourante() == null) return false;
		
		//et que si ce n'est pas notre tour, il s'agit d'une piece speciale
		if(!this.estMonTour && !moiMeme.getPieceCourante().getType().equals(FaceSpeciale.type))  return false;
		
		//si on a ajouter la piece sur le plateau
		nombrePieceObtenue = monPlateau.ajoutTuile(x, y, moiMeme.getPieceCourante());
		if(nombrePieceObtenue == 0) return false;
		
		//c'est ok, donc on la stocke
		tuile=moiMeme.getPieceCourante();
		
		//apres avoir pose la piece, on la supprime de sa main
		moiMeme.supprimerPieceCourante();
		
		//et on le dit au serveur
		this.connexion.signalePosePiece(tuile.getNumero(), tuile.getNbRot(),x,y,nombrePieceObtenue);
		


//		on fait la fin du tour si ce n'etait pas un loup ou un chasseur
		if(!tuile.getType().equals(FaceSpeciale.type)){
			lienInterfaceGraph.cestMonTour(false);
			this.connexion.signaleFinTour();
			estMonTour=false;
		}else{
			if(estMonTour) {
				lienInterfaceGraph.cestMonTour(true);
			}
		}
		

		
		this.lienInterfaceGraph.refreshPlateau(monPlateau);
		//this.lienInterfaceGraph.refreshMain((ArrayList)this.moiMeme.getMaMain(), null);
		
		
		return true;
	}
	
	/**
	 * 
	 * @return le numero de joueur de nous
	 */
	public int getNum(){
		return this.moiMeme.getNumero();
	}
	
	/**
	 * Demande au serveur de debuter la partie
	 *
	 */
	public void demandeDebutpartie(){
		connexion.demandeDebutPartie();
	}
	
	/**
	 * 
	 * @param args[0] dossier qui contient les ressources du jeu
	 */
	static public void main(String[] args)throws Exception{
		String adresseReseauServeur="localhost",nomFic="save.repl";
		int portServeur=33333;
		String pseudo="Joueur";
		
		//on demande si on doit faire la creation d'un serveur
		Object[] options = {"Creer Serveur", "Se connecter � un serveur existant", "Regarder un replay"};
		int n = JOptionPane.showOptionDialog(new Frame(),
											"Voulez-vous h�berger la partie ou rejoindre une partie \n"+
											"cr�e par une autre personne qui n'est pas encore commenc�e?\n"+
											"Vous pouvez aussi regarder un replay d'un ancien exploit.",
											"Demarrage",
											JOptionPane.YES_NO_OPTION,
											JOptionPane.QUESTION_MESSAGE,
											null,
											options,
											options[0]);
		
		//interpretation du resultat
		if(n==-1){ System.exit(0); } //cas annuler (croix du haut)
		if(n==0){
			//si creation serveur, on le cree et on s'y connecte
			Thread th=new Thread(){
				public void run(){
					ServeurMouton serv=new ServeurMouton();
					serv.start();
				}
			};
			th.start();
			
		}else if(n==1){
			//si connexion � un autre serveur, on demande lequel
			adresseReseauServeur = (String)JOptionPane.showInputDialog(
					                    new Frame(),
					                    "Donnez l'adresse ip du serveur (???.???.???.???)\n" +
					                    "avec ??? comprit entre 0 et 255 ou alors le nom de l'ordinateur",
					                    "choix du serveur",
					                    JOptionPane.QUESTION_MESSAGE,
					                    null,
					                    null,
					                    "localhost");
			//au cas ou=anuler
			if(adresseReseauServeur == null){
				System.exit(0);
			}else{
				//petite correction d'erreurs evidente
				if ( adresseReseauServeur.length() < 7  ) {
				    JOptionPane.showMessageDialog(new Frame(), "Erreur, adresse ip incorecte.\n Fin du programme.", "Erreur", JOptionPane.ERROR_MESSAGE);
				    System.exit(0);
				}
			}


		}else if(n==2){
			//replay
			/*nomFic = (String)JOptionPane.showInputDialog(
                    new Frame(),
                    "Donner Le nom du fichier",
                    "Charder un replay",
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    null,
                    "save.repl");*/
			JFileChooser fileChoice=new JFileChooser();
			int returnVal = fileChoice.showOpenDialog(new Frame());
//			au cas ou=anuler
			if(returnVal != JFileChooser.APPROVE_OPTION){
				System.exit(0);
			}else{
				Thread th=new Thread(){
					public void run(){
						ServeurMouton serv=new ServeurMouton();
						serv.start(33334);
					}
				};
				th.start();
				GDM temp=new GDM(".");
				temp.connectionServeurReplay(".", 33334, adresseReseauServeur, fileChoice.getSelectedFile().getAbsolutePath());
			}
			//pour ne pas continuer, sans quitter pour autant le programme
			return;
		}

		//et on demande le pseudo
		pseudo = (String)JOptionPane.showInputDialog(
				new Frame(),
                "Donner votre pseudo",
                "choix du serveur",
                JOptionPane.QUESTION_MESSAGE,
                null,
                null,
                "Joueur");
		//si annuler, on quitte
		if(pseudo==null){
			System.exit(0);
		}
		//jeu
		GDM prog = new GDM(".");
		prog.connectionServeurJeu( ".", portServeur, adresseReseauServeur, pseudo);
		//prog.connexion.demandeDebutPartie();
		if(prog.getNum()==1){
			//on demande la connexion, tant que pas encore accept�
			JOptionPane.showMessageDialog((Frame)prog.lienInterfaceGraph, "Quand vos amis se seront connect�s, \n appuyez sur ok pour lancer la partie.", "Lancement", JOptionPane.DEFAULT_OPTION);
			prog.demandeDebutpartie(); /* */
		}
		//on obtenient notre main automatiquement
		
	}

	/**
	 * indique qui nous sommes
	 * @param num numero du joueur (dans 1,2,3,4)
	 */
	public void setNum(int num) {
		moiMeme.setNumero(num);
		this.lienInterfaceGraph.setNous(num);
	}
	
	/**
	 * appel� pour le replay
	 * @param num du joueur courant
	 */
	public void changerNum(int num){
		lienInterfaceGraph.setNous(num);
		lienInterfaceGraph.refreshJoueur((ArrayList)joueurs);
	}

	/**
	 * Permet de d�fiinr si c'est notre tour. Active /desative les boutons dans l'interface aussi.
	 * @param monTour true si c'est mon tour
	 */
	public void setEstMonTour(boolean monTour){
		estMonTour=monTour;
		lienInterfaceGraph.cestMonTour(monTour);
	}

	/**
	 * ajoute une tuile au plateau de jeu, 
	 * appele quand les autres joueurs posent une tuile
	 * @param numTuile le numero de la facetuile � ajouter
	 * @param rot la rot de la tuile
	 * @param x emplacement x
	 * @param y emplacement y
	 */
	public void poserPiece(int numTuile, int rot, int x, int y) {
		//on prend la tuile a rajouter
		FaceTuile tempTuile=this.getPiece(numTuile);
		//on la rotate
		for(int i=0;i<rot;i++){	tempTuile.rotation(); }
		//on l'ajoute au plateau, ordre du serveur-> on discute pas
		this.monPlateau.ajoutPieceTab(x,y,tempTuile);
		//on l'indique � l'interface graphique
		this.lienInterfaceGraph.refreshPlateau(monPlateau);
	}

	/**
	 * Pour obtenir une tuiles existante selon son numero
	 * @param numTuile numero de la tiule
	 * @return
	 */
	private FaceTuile getPiece(int numTuile) {
		return (FaceTuile)(((ArrayList)tuilesDuJeu).get(numTuile));
	}
	
	/**
	 * appel� par l'ecouteur (vient du serveur, quand un joueur pose son berger
	 * @param coul du joueur
	 * @param x posx de son berger
	 * @param y posy de son berger
	 */
	public void poserBerger(int coul, int x, int y) {
		//creation de la facetuile
		FaceTuile berger=new FaceNormale(coul);
		//ajout au plateau (odre du serveur-> on discute pas
		this.monPlateau.ajoutPieceTab(x,y,berger);
		//on l'indique � l'interface graphique
		this.lienInterfaceGraph.refreshPlateau(monPlateau);
	}

	/**
	 * appel� par l'interface, quand on pose notre berger
	 * @param x
	 * @param y
	 * @return
	 */
	public boolean poserMonBerger(int x, int y) {
		//creation de la facetuile
		FaceTuile berger=new FaceNormale(moiMeme.getCouleur());
		//ajout au plateau
		int nb=this.monPlateau.ajoutTuile(x,y,berger);
		//System.err.println("coul="+moiMeme.getCouleur()+", nb="+nb);
		if(nb==0){
			System.out.println("Erreur, pas ajoutberger");
			return false;
		}else{
			//ok
			System.out.println("Ok, ajoutberger");
			
			//on dit qu'il est pose � nous
			moiMeme.poseBerger();
			
			//et aux autres
			this.connexion.reveleCouleur(moiMeme.getCouleur(), x, y, nb);

			//on l'indique � l'interface graphique (pas besoin!)
			this.lienInterfaceGraph.refreshPlateau(monPlateau);
			return true;
		}
		
	}

	/**
	 * cree le arraylist des joueurs, sauf moiMeme
	 * appel� par l'ecouteur
	 * @param couleur
	 * @param nombreJoueurs
	 */
	public void construitJoueurs(int couleur, int nombreJoueurs, ArrayList tabNom) {
		//init
		joueurs=new ArrayList();
		joueurs.add(moiMeme);
		moiMeme.setCouleur(couleur);
		moiMeme.setACouleur(true);
		
		for(int i=0;i<nombreJoueurs;i++){
			if( i == (moiMeme.getNumero()-1) ){//si moi
				//en fait, on n'a pas encore pris notre pseudos
				moiMeme.setNom((String)tabNom.get(i));
			}else{//si pas moi
				joueurs.add(new Joueur(i+1, (String)tabNom.get(i)));
			}
		}
		this.lienInterfaceGraph.refreshJoueur((ArrayList)joueurs);
	}

	/**
	 * 
	 * @param numJ le joueur � qui changer sa couleur
	 * @param coul sa couleur
	 */
	public void setCouleurJoueur(int numJ, int coul) {
		int i=0;
		//System.err.println("set coul"+numJ+", "+coul);
		while( i<joueurs.size() && ((Joueur)(((ArrayList)joueurs).get(i))).getNumero() != numJ ){
			i++;
		}
		if(i<joueurs.size()){
			//System.err.println("set coul OK"+numJ+", "+coul);
			((Joueur)(((ArrayList)joueurs).get(i))).setCouleur(coul);
			((Joueur)(((ArrayList)joueurs).get(i))).setACouleur(true);
			lienInterfaceGraph.refreshJoueur((ArrayList)joueurs);
		}
	}
	
	/**
	 * On dit au serveur qu'on passe son tour
	 * @return true si ok, fakse si on n'avait pas la main
	 */
	public boolean passerTour(){
		if(estMonTour){
			this.connexion.signaleFinTour();
			return true;
		}
		return false;
	}
	
	/**
	 * Dit au serveur que on abandonne
	 * fait tout ce qui est n�c�ssaire pour cela
	 */
	public void abandonner(){
		System.out.println("on demande l'abandon");
		
		//puit on abandonne
		connexion.abandonner();
		
	}
	
	/**
	 * Appel� par l'ecouteur quand on recoit la confiramation d'abandon
	 * @param place
	 */
	public void confirmationAbandon(int place){
		//on revele sa couleur
		connexion.reveleCouleur(moiMeme.getCouleur());
		//si on joue, on passe son tour
		if(estMonTour){
			this.setEstMonTour(false);
			connexion.signaleFinTour();
		}
		//et on se met notre place de fin
		moiMeme.setOdreFinPartie(place);
		lienInterfaceGraph.refreshJoueur((ArrayList)joueurs);
	}

	/**
	 * L'ecouteur nous signale qu'il y a eu un abandon de quelqu'un d'autre via cette methode
	 * @param num le numero du joueur qui a abandonn�
	 * @param place sa position d'abandon (pour ses points)
	 */
	public void signalAbandon(int num, int place) {
		Iterator it=joueurs.iterator();
		Joueur tempJ=null;
		boolean pasTrouve=true;
		while( it.hasNext() && pasTrouve ){
			tempJ=((Joueur)it.next());
			pasTrouve=tempJ.getNumero()!=num;
		}
		if(!pasTrouve){ tempJ.setOdreFinPartie(place); }
		lienInterfaceGraph.refreshJoueur((ArrayList)joueurs);
	}
	
	/**
	 * Compte les points d'un joueur
	 * @param jou le joueur dont il faut compter les points
	 * @return
	 */
	public int comptePoints(Joueur jou){
		return monPlateau.compterPoints(jou.getCouleur())+jou.nbPointClassement();
	}
	
	/**
	 * appel� par fenetreReplay, demande � passer � m'iteration suivante
	 * 
	 */
	public void replaySuivant(){
		connexion.replaySuivant();
	}

	/**
	 * Appel� par l'ecouteur quand le serveur dit que c'est la fin de la partie
	 *
	 */
	public void finPartie() {
		String message="";
		//on compte les points pour chaque joueur
		Iterator it=joueurs.iterator();
		Joueur tempJ,gagnant=moiMeme;
		int nbPoints,maxPoints=0,num=1;
		int sauv=2;
		while(it.hasNext()){
			tempJ=(Joueur)it.next();
			//on comptre pour ce joueur
			nbPoints=comptePoints(tempJ);
			//si c'est celui qui en a le plus
			if(nbPoints>maxPoints){
				maxPoints=nbPoints;
				gagnant=tempJ;
			}
			//on affiche
			message=message+"\nLe joueur n�"+tempJ.getNumero()
						+" de couleur "+Cote.coulToString(tempJ.getCouleur())
						+" a "+nbPoints
						+" points.";
			num++;
		}

		//message & l'utilisateur
		JOptionPane.showMessageDialog((Frame)lienInterfaceGraph, "Comptage des points: \n"+
				"Le gagnant est le joueur n�"+gagnant.getNumero()+", "+gagnant.getNom()+" avec "+maxPoints+" points."+
				message, "Resultats", JOptionPane.PLAIN_MESSAGE);
	    
		//si on est pas en replay
		if(!etat.equals("Replay")){
			
			//si on est le serveur, on peut sauver le replay
			if(moiMeme.getNumero()==1){
				sauv=JOptionPane.showConfirmDialog((Frame)lienInterfaceGraph, "Voulez-vous sauvegarder le replay de la partie?","Sauvegarde du replay",JOptionPane.YES_NO_OPTION);
	
	//			si sauvegarde
				if(sauv==0){
					JFileChooser fileChoice=new JFileChooser();
					int returnVal = fileChoice.showSaveDialog(new Frame());
	//				si tj ok, on sauv
					if(returnVal == JFileChooser.APPROVE_OPTION){
						connexion.saveReplay(fileChoice.getSelectedFile().getAbsolutePath());
					}
				}
			}
			
			
			//on refait une partie? (couleurs et pioches envoy�s par le serveur)
			reinit();
			if(moiMeme.getNumero()==1){
				connexion.demandeReinit();
				//mais la, on est avec le thread de l'ecouteur.
				//or, pour demander un debut de partie, il faut que l'ecouter tourne en meme temps
				//donc on cree un nouveau thread
				Thread th=new Thread(){
					public void run(){
						connexion.demandeDebutPartie();
					}
				};
				th.start();
			}
		}
	}

	/**
	 * Pour r�initialiser le programme, en vu d'une nouvelle partie.
	 *
	 */
	private void reinit() {
		
		monPlateau.reinit();
		lienInterfaceGraph.refreshPlateau(monPlateau);
		
		Iterator it=joueurs.iterator();
		while(it.hasNext()){
			((Joueur)it.next()).reinit();
		}
		lienInterfaceGraph.refreshJoueur((ArrayList)joueurs);
		lienInterfaceGraph.refreshMain((ArrayList)moiMeme.getMaMain(), moiMeme.getPieceCourante());
		
	}

	/**
	 * Change le pseudo d'un joueur
	 * @param numJ
	 * @param nomJ
	 */
	public void changeNomJ(int numJ, String nomJ) {
		((Joueur)((ArrayList)joueurs).get(numJ-1)).setNom(nomJ);
	}
	
	/**
	 * On dit au serveur que l'on quitte 
	 * Fait des verification (et message de confirmation si joueur1)
	 */
	public void demandeQuitter(){
		connexion.reveleCouleur(moiMeme.getCouleur());
		if(moiMeme.getNumero()==1){
			int ok=JOptionPane.showConfirmDialog((Frame)lienInterfaceGraph, "Etes-vous s�r de vouloir quitter le jeu?\n" +
					"Vous etes celui qui heberge le serveur,\n" +
					"si vous quitter, tous les joueurs vont etre deconnect�s.", "confirmation", JOptionPane.YES_NO_OPTION);
			if(ok==0){ 
				connexion.demandeQuitter();
			}
		}else{
			//petite gestion si on a la main
			if(moiMeme.joue()){
				if(estMonTour){
					connexion.signaleFinTour();
				}
			}
			connexion.demandeQuitter();
		}
		
	}

	/**
	 * pour savoir combien de joueur n'ont pas encore abandonn�
	 * @return
	 */
	private int nbJoue() {
		int nb=0;
		Iterator it=joueurs.iterator();
		while(it.hasNext()){
			if( ((Joueur)it.next()).joue() ){
				nb++;
			}
		}
		return nb;
	}

	/**
	 * L'ecouteur nous dit qu'un joueur s'est deco
	 * @param numDeco numero du joueur
	 */
	public void gereDeco(int numDeco) {
		Joueur j=null;
		Iterator it=joueurs.iterator();
		boolean trouve=false;
		while(it.hasNext() && !trouve){
			j=(Joueur)it.next();
			trouve=j.getNumero()==numDeco;
		}
		//si c'est le serveur, on peut pas continuer
		if(numDeco==1 && trouve){
			JOptionPane.showMessageDialog((Frame)lienInterfaceGraph, "Le serveur \""+j.getNom()+"\" vous a d�connect�!", "Erreur",JOptionPane.YES_OPTION );
			String message="Comptage des points:";
			it=joueurs.iterator();
			Joueur tempJ;
			int sauv=2;
			while(it.hasNext()){
				tempJ=(Joueur)it.next();
				message=message+"\nLe joueur n�"+tempJ.getNumero()
							+" de couleur "+Cote.coulToString(tempJ.getCouleur())
							+" a "+monPlateau.compterPoints(tempJ.getCouleur())
							+" points.";
			}

			//message � l'utilisateur
			JOptionPane.showMessageDialog((Frame)lienInterfaceGraph, message, "Resultats", JOptionPane.PLAIN_MESSAGE);
		
			//on quitte
			System.exit(0);
			
		}else{
			//pas le serveur

			//on le modifie du tab de joueur
			if(trouve){
				j.deco();
				
				//message � l'utilisateur pour le prevenir
				JOptionPane.showMessageDialog((Frame)lienInterfaceGraph, "Le joueur n�"+numDeco+" \""+j.getNom()+"\" a �t� d�connect�!", "Erreur",JOptionPane.YES_OPTION );

				//on reaffiche
				lienInterfaceGraph.refreshJoueur((ArrayList)joueurs);
			}
			
		}
		
	}

	/**
	 * Pour quitter (appel� par l'ecouteur)
	 */
	public void exit() {
		System.exit(0);
	}
	
	/**
	 * Pour avoir la frmae quand on veut afficher un message d'erreur
	 * @return
	 */
	public Frame getFrame(){
		return (Frame)lienInterfaceGraph;
	}

	/**
	 * Dit au serveur que l'on quitte
	 * une petite verif (si mon tour)
	 * Plus de mesage de confirmation si joueur1
	 */
	public void demandeQuitterObligatoire() {
		connexion.reveleCouleur(moiMeme.getCouleur());
//		petite gestion si on a la main
		if(moiMeme.joue()){
			if(estMonTour){
				connexion.signaleFinTour();
			}
		}
		connexion.demandeQuitter();
	}
	
}


