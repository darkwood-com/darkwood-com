//
//  main.m
//  KissXML
//
//  Created by Robbie Hanson on 9/27/08.
//  Copyright Deusty Designs, LLC. 2008. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc,  (const char **) argv);
}
