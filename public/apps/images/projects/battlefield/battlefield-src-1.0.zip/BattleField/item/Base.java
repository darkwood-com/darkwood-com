package item;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;

import patch.Maillage;

public class Base extends Item {
	
	Color teamColor;
	
	public static ArrayList<Base> bases = new ArrayList<Base>(); //toutes les bases du jeu
	
	public Base(Maillage maillage, Color teamColor) {
		super(maillage);
		
		this.teamColor = teamColor;
		
		taille = 10;
		
		maxLife = 1000;
		life = maxLife;
		
		bases.add(this);
	}

	public void draw(Graphics g) {
		g.setColor(teamColor);
		coord.fillRect(g, taille);
	}
	
	//retourne la base ennemie de l'unite
	static public Base getBaseEnnemie(Color c) {
		Base baseIt;
		Iterator<Base> it = bases.iterator();
		while(it.hasNext()) {
			//la base ennemie est une couleur differente de c
			baseIt = it.next();
			if(baseIt.teamColor != c) {
				return baseIt;
			}
		}
		return null;
	}
	
	//retourne la base ennemie de l'unite
	static public Base getBaseAllie(Color c) {
		Base baseIt;
		Iterator<Base> it = bases.iterator();
		while(it.hasNext()) {
			//la base ennemie est la meme couleur que c
			baseIt = it.next();
			if(baseIt.teamColor == c) {
				return baseIt;
			}
		}
		return null;
	}
}
