package item;

import java.util.Iterator;

import patch.Maillage;
import team.Unit;

public class PULife extends PowerUp {

	protected PULife(Maillage maillage) {
		super(maillage, new String("Vie"));
	}
	
	//donne de l'extra life a tous ses allies sur un rayon de 50
	public void takenBy(Unit unit) {
		super.takenBy(unit);
		
		Unit uIt;
		Iterator<Unit> it = unit.getVoisins(100).iterator();
		while(it.hasNext()) {
			uIt = it.next();
			
			uIt.life = uIt.maxLife;
		}
	}
}
