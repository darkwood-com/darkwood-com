package item;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;

import patch.Maillage;
import team.Unit;
import utils.Vector2d;

public abstract class PowerUp extends Item {
	int lifeTime; //le powerUp a un certain temps de vie sur la carte (en FPS)
	String name; //nom du powerUp
	
	static private Random rand = new Random();
	static private ArrayList<PowerUp> powerUps = new ArrayList<PowerUp>();

	protected PowerUp(Maillage maillage, String name) {
		super(maillage);
		this.name = name;
		
		lifeTime = 200;
	}
	
	//cree aleatoirement un evenement en ajoutant des powerUp
	public static void event(Maillage maillage) {
		//nouveaux powerup sur la carte
		if(rand.nextInt(100) == 0) {
			switch(rand.nextInt(2)) {
			case 0:
				powerUps.add(new PUView(maillage));
				break;
			default:
				powerUps.add(new PULife(maillage));
				break;
			}
			
		}
	}

	//dessine tous les power up
	public static void drawAll(Graphics g) {
		PowerUp puIt;
		for(int i=0; i<powerUps.size(); i++) {
			puIt = powerUps.get(i);
			puIt.lifeTime--;
			if(puIt.lifeTime <= 0) //fin de vie du powerup
			{
				removePowerUp(puIt);
				i--;
				continue;
			}
			
			puIt.draw(g);
		}
	}
	
	//recupere un PowerUp dans la liste
	public static PowerUp getOne() {
		int nbPowerUp = powerUps.size();
		if(nbPowerUp > 0) {
			return powerUps.get(rand.nextInt(nbPowerUp));
		}
		return null;
	}
	
	//on retire un powerup de la liste
	public static void removePowerUp(PowerUp pu) {
		powerUps.remove(pu);
		pu.removed = true;
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.GREEN);
		coord.fillRect(g, taille);
		
		g.setColor(Color.BLACK);
		//au dessus, on affiche sa duree de vie restante
		Vector2d txtCoord = new Vector2d(coord);
		txtCoord.x -= 10;
		txtCoord.y -= 10;
		txtCoord.drawText(g, String.valueOf(lifeTime));
		
		txtCoord.set(coord);
		txtCoord.x -= 10;
		txtCoord.y += 20;
		txtCoord.drawText(g, name);
	}
	
	
	public void takenBy(Unit unit) {
		//on retire le powerup de la liste
		removePowerUp(this);
	}
}
