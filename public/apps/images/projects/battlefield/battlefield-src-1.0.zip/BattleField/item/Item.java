package item;

import patch.Flag;
import patch.Maillage;
import patch.PointWithFlag;
import team.Unit;
import team.UnitLeader;
import utils.Object2d;

public class Item extends Object2d {
	public boolean removed; //indique si l'item est desuet, si celuis ci a ete pris ou detruit
	public Flag closedFlag; //flag visible le plus proche de l'item
	
	protected Item(Maillage maillage) {
		super(maillage.surface);
		
		//a leur initialisation,
		//les items connaissent leur flag le plus proche et visible
		PointWithFlag startPos = maillage.randValidPointInSurfaceSeeOneFlag();
		
		coord.set(startPos.point);
		closedFlag = startPos.flag;
		removed = false;
	}

	public void takenBy(Unit unit) {
		
	}
}
