package item;

import java.util.Iterator;

import patch.Maillage;
import team.Unit;

public class PUView extends PowerUp{

	protected PUView(Maillage maillage) {
		super(maillage, new String("Vue"));
	}

	//augmente la vue de tir a tous les voisins allies
	public void takenBy(Unit unit) {
		super.takenBy(unit);
		
		Unit uIt;
		Iterator<Unit> it = unit.getVoisins(100).iterator();
		while(it.hasNext()) {
			uIt = it.next();
			
			uIt.currWeapon.scaleViewFactor(5);
		}
	}
}
