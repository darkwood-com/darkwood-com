package patch;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Iterator;
import java.util.Random;
import java.util.Vector;

import applets.BattleField;


import surface.Surface;
import utils.Object2d;
import utils.Vector2d;

public class Maillage {
	public Surface surface;
	
	private Vector<Flag> flags;
	
	public Maillage(int nbFlags, Surface surface) {
		this.surface = surface;
		
		int x = surface.wxsize;
		int y = surface.wysize;
		
		flags = new Vector<Flag>();
		
		Random rand = new Random();
		
		boolean posePremierFlag = false;
		while(!posePremierFlag) {
			try {
				flags.add(new Flag(surface, rand.nextInt(x), rand.nextInt(y)));
			} catch (Exception e) {
				continue;
			}
			posePremierFlag = true;
		}
		
		int nbCurrFlags = 1;
		while(nbCurrFlags < nbFlags) {
			try {
				flags.add(new Flag(flags, surface, rand.nextInt(x), rand.nextInt(y)));
			} catch (Exception e) {
				continue;
			}
			nbCurrFlags ++;
		}
	}

	public void draw(Graphics g) {
		if(BattleField.levelDetail >= 1) {
			g.setColor(Color.ORANGE);
		   for(int i=0;i<flags.size();i++) {
			   flags.get(i).draw(g);
			   flags.get(i).drawVoisins(g);
		   }
		}
	}
	
	public Flag getRandomFlag() {
		Random rand = new Random();
		return flags.get(rand.nextInt(flags.size()));
	}
	
	public Vector<Flag> getFlags() {
		return flags;
	}
	
	public PointWithFlag randValidPointInSurfaceSeeOneFlag() {
		Flag f = null;
		Vector2d point;
		
		Vector<Flag> flags = this.getFlags();
		float distance;
		float newDistance;
		
		do {
			point = surface.randValidPointInSurface();
			
			distance = Float.MAX_VALUE;
			for(int i=0;i<flags.size();i++) {
				newDistance = flags.get(i).coord.distance2(point);
				 if(distance > newDistance && flags.get(i).canSee(point)) {
					 f = flags.get(i);
					 distance = newDistance;
				 }
			}
		} while(f == null);
	   
	   return new PointWithFlag(point, f);
	}

	public Flag getSeeFlag(Vector2d pos) {
		Flag flagIt;
		Iterator<Flag> it = flags.iterator();
		while(it.hasNext()) {
			flagIt = it.next();
			if(flagIt.canSee(pos)) {
				return flagIt;
			}
		}
		
		return null;
	}
}
