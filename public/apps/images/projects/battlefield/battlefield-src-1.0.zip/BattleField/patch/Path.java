package patch;

import item.Item;

import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;

import surface.Surface;
import utils.Object2d;
import utils.Vector2d;

//chemin parmis plusieurs flags qui se voient
public class Path {
	
	Object2d finalTarget;
	ArrayList<Flag> flags;
	
	int lastPosFlagVu;
	
	public Path(AStar aStar, Item targetObject) {
		flags = new ArrayList<Flag>();
		
		Flag backTracking = aStar.goal;
		flags.add(backTracking);
		
		while(backTracking.precedent != null) {
			flags.add(0, backTracking.precedent);
			backTracking = backTracking.precedent;
		}
		
		lastPosFlagVu = 0;
		this.finalTarget = targetObject;
	}
	
	public void draw(Graphics g) {
		Iterator<Flag> it = flags.iterator();
		
		Flag f;
		while(it.hasNext()) {
			f = it.next();
			
			if (f.precedent != null) {
				f.coord.drawLine(g, f.precedent.coord);
			}
		}
	}
	
	//si on voit un flag plus loin dans le chemin,
	//on le retourne, sinon on retourne null
	public Object2d nextVisibleObj(Object2d obj, Surface surface) {
		Object2d nexVisibleObj = null;
		
		for(int i=lastPosFlagVu + 1; i < flags.size(); i++) {
			if(obj.canSee(flags.get(i))) {
				nexVisibleObj = flags.get(i);
				lastPosFlagVu = i;
			}
		}
		
		if(obj.canSee(finalTarget)) {
			nexVisibleObj = finalTarget;
		}
		
		if(nexVisibleObj == null) {
			nexVisibleObj = flags.get(lastPosFlagVu);
		}
		
		return nexVisibleObj;
	}

	public Flag getLastSeenFlag() {
		return flags.get(lastPosFlagVu);
	}
}
