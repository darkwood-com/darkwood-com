package patch;

import utils.Vector2d;

/**
 * a partir d'un point, on connait le flag le plus proche que le point peut voir
 * le flag existe necessairement, sinon ya pas d'instance
 * @author mledru
 *
 */
public class PointWithFlag {
	public Vector2d point;
	public Flag flag;
	
	PointWithFlag(Vector2d point, Flag flag) {
		this.point = point;
		this.flag = flag;
	}
}
