package patch;

import java.awt.Graphics;
import java.util.Vector;

import surface.Surface;
import utils.Object2d;
import utils.Vector2d;

public class Flag extends Object2d implements Comparable{
	Vector<Flag> voisins = new Vector<Flag>();
	
	//heuristique pour le A Etoile
	float heuriH;
	float heuriG;
	Flag precedent;
	
	//pose du premier flag
	public Flag(Surface surface, int x, int y) throws Exception{
		super(surface);
		if(surface.collide(x, y) != null) throw new Exception();
		coord = new Vector2d(x, y);
		
		taille = 5;
	}
	
	//pose des flags suivants
	public Flag(Vector<Flag> flags, Surface surface , int x, int y) throws Exception{
		super(surface);
		if(surface.collide(x, y) != null) throw new Exception();
		boolean hasOneFlagNeighbour = false;

		coord = new Vector2d(x, y);
		for(int i=0;i<flags.size();i++) {
			 if(surface.cansee(coord, flags.get(i).coord)) {
				 hasOneFlagNeighbour = true;
				 //on ajoute les voisins
				 voisins.add(flags.get(i));
				 flags.get(i).voisins.add(this);
			 }
		}
		
		if(!hasOneFlagNeighbour) throw new Exception();
	}

	
	public void draw(Graphics g) {
		coord.fillCircle(g, taille);
	}
	
	public void drawVoisins(Graphics g) {
		Flag voisin;
		for(int i=0;i<voisins.size();i++) {
			voisin = voisins.get(i);
			coord.drawLine(g, voisin.coord);
		}
	}

	public int compareTo(Object o) {
		Flag f = (Flag)o;
		
		float heuriF1 = this.heuriH + this.heuriG;
		float heuriF2 = f.heuriH + f.heuriG;
		
		if(heuriF1  < heuriF2) return -1;
		else if(heuriF1 > heuriF2) return 1;
		else return 0;
	}
	
	public float distanceToFlag(Flag f) {
		return coord.distance(f.coord);
	}
}
