package patch;

import item.Base;
import item.Item;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Vector;

import utils.Object2d;
import utils.Vector2d;




/*
 *  Ajouter START � la liste OPEN
	Tant que la liste OPEN n'est pas vide
		Retirer le n�ud n de la liste OPEN tel que f(n) soit le plus petit
		Si n est le GOAL retourner la solution ;
		Sinon ajouter n � CLOSED
		Pour chaque successeur n' du noeud n
			Heuristique H = estimation du co�t de n' au GOAL
			Stocker dans G_tmp, le co�t g(n) + le co�t pour aller de n � n'
			Stocker dans F_tmp, g(n') + H ; c'est l'heuristique
			Si n' se trouve d�j� dans OPEN avec un f(n') meilleur on passe au point n' suivant
			Si n' se trouve d�j� dans CLOSED avec un f(n') meilleur on passe au point n' suivant
			Mettre n dans parent(n')
			Mettre G_tmp dans g(n')
			Mettre F_tmp dans f(n')
			Retirer n' des deux listes OPEN et CLOSED
			Ajouter n' � la liste OPEN
 */

public class AStar {
	Vector<Flag> flags;
	
	ArrayList<Flag> open;
	ArrayList<Flag> closed;
	Flag start, goal;
	
	public Path currPath; //chemin qui est courament assigne a AStar
	
	public AStar(Maillage maillage) {
		this.flags = maillage.getFlags();
		
		open = new ArrayList<Flag>();
		closed = new ArrayList<Flag>();
		
		currPath = null;
	}
	
	public void searchPath(Flag start, Item targetObject) {
		this.start = start;
		this.goal = targetObject.closedFlag;
		
		//initialisation
		for(int i=0;i<flags.size();i++) {
			//on precalcule les heuristique H qui ne changent pas pendant tout AStar
			//car les flags sont fixes sur la map
			flags.get(i).heuriH = flags.get(i).distanceToFlag(goal);
			flags.get(i).heuriG = -1;
			flags.get(i).precedent = null;
		}
		
		closed.clear();
		open.clear();
		
		open.add(start);
		
		start.heuriG = 0;
		while(!open.isEmpty()) {
			Collections.sort(open);
			
			/*Iterator<Flag> it = open.iterator();
			System.out.println("------------");
			Flag itFlag;
			while(it.hasNext()) {
				itFlag = it.next();
				
				System.out.println((itFlag.heuriH + itFlag.heuriG));
			}*/
			
			Flag curr = open.remove(0);
			
			//System.out.println("e "+(curr.heuriH + curr.heuriG));
			
			if(curr == goal)
			{
				currPath = new Path(this, targetObject); //on cree le chemin
				
				return; //retourne la solution
			}
			
			closed.add(curr);
			//on met a jour les successeurs
			Flag fV;
			for(int i=0;i<curr.voisins.size();i++) {
				fV = curr.voisins.get(i);
				
				float newHeuriG = curr.heuriG + fV.distanceToFlag(curr);
				boolean isInOpen = open.contains(fV);
				if(fV.heuriG == -1 || (isInOpen && fV.heuriG > newHeuriG))
				{
					fV.precedent = curr;
					fV.heuriG = newHeuriG;
					if(!isInOpen) open.add(fV);
				}
			}
		}
	}

	public void draw(Graphics g) {
		g.setColor(Color.CYAN);
		start.draw(g);
		
		g.setColor(Color.PINK);
		goal.draw(g);
		
		g.setColor(Color.GREEN);
		if(currPath != null)
		{
			currPath.draw(g);
		}
	}
}
