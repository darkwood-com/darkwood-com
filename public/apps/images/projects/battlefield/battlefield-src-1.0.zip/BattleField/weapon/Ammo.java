package weapon;

import java.awt.Graphics;
import java.util.Iterator;

import surface.Surface;
import team.Team;
import team.Unit;
import utils.Object2d;
import utils.Vector2d;

public class Ammo extends Object2d {
	public float damage;
	
	Ammo(Surface surface, Vector2d start, Vector2d direction) {
		super(surface);
		coord.set(start);
		speed.set(direction);
		taille = 2;
		damage = 1;
		
		maxSpeed = 10;
		speed.setApproximateTruncate(maxSpeed);
	}
	
	//renvoie vrai si la balle touche un obstacle (ennemi, mur ou sortie de map), faux sinon
	public boolean anim(Team teamEnnemi) {
		coord = coord.add(speed);
		
		//si la balle touche une unite de la team ennemie
		Unit unitIt;
		Iterator<Unit> it = teamEnnemi.getUnits().iterator();
		while(it.hasNext()) {
			unitIt = it.next();
			
			if(coord.distance2(unitIt.coord) <= unitIt.taille * unitIt.taille) {
				//la balle touche une unite ennemie
				unitIt.touch(this);
				return true;
			}
		}
		
		return surface.collide(coord) == null && surface.isInSurface(coord);
	}

	public void draw(Graphics g) {
		
		coord.fillCircle(g, taille);
	}
}
