package weapon;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;

import surface.Surface;
import team.Team;
import utils.Vector2d;

public class Weapon {
	int nbAmmoMax;
	int currNbAmmos;
	ArrayList<Ammo> ammos;
	int maxRate; //en frame par secondes
	int currRate; //rate = 0 : on peut tirer
	public int currView; //portee maximale
	int minView; //portee minimale
	Surface surface;
	
	public Weapon(Surface surface) {
		this.surface = surface;
		ammos = new ArrayList<Ammo>();
		nbAmmoMax = 5;
		currNbAmmos = 0;
		maxRate = 24;
		currRate = 0;
		minView = 100;
		currView = minView;
	}

	public void anim(Team teamEnnemi) {
		//la vue decremente dans le temps
		currView -= 0.01;
		if(currView < minView) currView = minView;
		
		Ammo itAmmo;
		for(int i = 0; i < currNbAmmos; i++)
		{
			itAmmo = ammos.get(i);
			if(!itAmmo.anim(teamEnnemi)) {
				//on retire la balle du jeu si elle touche quelque chose
				ammos.remove(i);
				currNbAmmos--;
				i--;
			}
		}
		
		//incremente le compteur pour pouvoir a nouveau tirer
		if(currRate > 0) currRate = (currRate + 1) % maxRate;
	}

	public boolean canShoot() {
		return currRate == 0 && currNbAmmos <= nbAmmoMax;
	}

	public void shoot(Vector2d start, Vector2d direction) {
		if(canShoot()) {
			currRate = 1; //lance le compteur
			currNbAmmos++;
			//on ajoute a la liste des ammos une nouvelle balle
			ammos.add(new Ammo(surface, start, direction));
		}
	}
	
	public void draw(Graphics g) {
		Iterator<Ammo> it = ammos.iterator();
		while(it.hasNext()) {
			it.next().draw(g);
		}
	}

	//multiplie la vue
	public void scaleViewFactor(float scale) {
		currView *= scale;
	}
}
