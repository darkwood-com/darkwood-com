package surface;

import utils.Vector2d;
import java.util.*;
import java.awt.*;

public class Surface {

	public int wxsize, wysize;

	private Vector<PolylineObject> objects; // The objects on the surface
	
	public Surface(int nbObstacle, int wxsize, int wysize) {
		   this.wxsize = wxsize;
		   this.wysize = wysize;
		   objects = new Vector<PolylineObject>();
		   
		   for(int i = 0; i < nbObstacle; i++) {
			   objects.add(PolylineObject.newRandomPolylineObject(this));
		   }
	    }

   public void draw(Graphics g) {
	   g.setColor(Color.BLACK);
	   for(int i=0;i<objects.size();i++) {
		   objects.get(i).draw(g);
	   }
   }
   
   //on regarde simplement si le segment entre A et B ne collisionne pas
   //avec l'ensemble des obstacles
   public boolean cansee(Vector2d tmpA, Vector2d tmpB) {
	   for(int i=0;i<objects.size();i++) {
		   if (objects.get(i).intersectsWith(tmpA, tmpB))
			   return false;
	   }
	   return true;
   }
   
   //canseeGetProjection == cansee
   //sauf que l'on affecte a coord la projection de  futurCoord sur le segment le plus proche
   //si il y a collision entre coord et futurCoord
   public boolean canseeGetProjection(Vector2d coord, Vector2d futurCoord) {
	   
	   //utile pour que l'on puisse se degager d'un mur
	   Vector2d prevCoord = futurCoord.subtract(coord).add(coord);
	   if(collide(prevCoord) == null) {
		   coord.set(futurCoord);
		   return true;
	   }
	   
	   for(int i=0;i<objects.size();i++) {
		   if (objects.get(i).closestPointOfIntersectionWithGetProjection(coord, futurCoord))
			   return false;
	   }
	   
	   //s'il n'y a pas eu de collision, alors coord = futurCoord
	   coord.set(futurCoord);
	   return true;
	}
   
   public PolylineObject collide(Vector2d pos) {
	   return collide(pos.x, pos.y);
   }
   
   public PolylineObject collide(double x, double y) {
	   PolylineObject itPO;
	   Iterator<PolylineObject> it = objects.iterator();
	   while (it.hasNext()) {
		   itPO = it.next();
		   if(itPO.containsPoint(x, y)) return itPO;
	   }
	   
	   return null;
   }
   
   public PolylineObject collide(PolylineObject po) {
	   PolylineObject itPO;
	   Iterator<PolylineObject> it = objects.iterator();
	   while (it.hasNext()) {
		   itPO = it.next();
		   if(itPO.collide(po)) return itPO;
	   }
	   
	   return null;
	}
   
   public Vector2d randValidPointInSurface() {
   		Vector2d point = new Vector2d();
		
		int xMax = this.wxsize;
		int yMax = this.wysize;
		
		Random rand = new Random();
		do {
			point.set(rand.nextInt(xMax), rand.nextInt(yMax));
		} while(this.collide(point) != null);
		
		return point;
   }
   
   public boolean isInSurface(Vector2d coord) {
	   return coord.x >= 0 && coord.y >= 0 && coord.x <= wxsize && coord.y <= wysize;
   }
}

