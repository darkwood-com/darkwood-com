package utils;

import surface.Surface;
import team.Unit;
import team.UnitLeader;

public abstract class Object2d {
	public float maxLife;
	public float life;
	
	public Vector2d coord;
	public Vector2d speed;
	protected float maxSpeed;
	
	public int taille;
	
	protected Surface surface;
	
	protected Object2d(Surface surface) {
		this.surface = surface;
		
		coord = new Vector2d();
		speed = new Vector2d();
		
		maxSpeed = 5;
		taille = 5;
		
		maxLife = 100;
		life = maxLife;
	}
	
	//peut voir un autre objet dans sa vision
	public boolean canSee(Object2d o) {
		return surface.cansee(coord, o.coord);
	}
	
	//peut voir un autre objet dans sa vision a une certaine distance maximale
	public boolean canSee(Object2d o, int viewLength) {
		return coord.distance2(o.coord) <= viewLength * viewLength && surface.cansee(coord, o.coord);
	}
	
	public boolean canSee(Vector2d v) {
		return surface.cansee(coord, v);
	}

	//l'unite prend l'objet
	public void takenBy(Unit unit) {
		
	}
}
