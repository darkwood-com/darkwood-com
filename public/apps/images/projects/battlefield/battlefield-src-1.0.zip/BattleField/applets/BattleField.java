package applets;

import item.PowerUp;

import java.awt.*;
import java.awt.event.*;
import java.util.GregorianCalendar;

import javax.swing.JApplet;

import com.sun.j3d.utils.applet.MainFrame;

import patch.Maillage;

import team.Team;
import utils.*;
import surface.*;

public class BattleField extends JApplet implements Runnable, MouseListener
{
	Surface surface;
	Maillage maillage;
	Team team1;
	Team team2;
	
	static public int levelDetail = 0;

    private Thread update;
    Vector2d viewCenter;
    int framesSinceTouch;
    int wxsize, wysize;
    static final Color bgColor = new Color(0.9F, 0.9F, 0.8F);
    Image canvasimage;
    Graphics canvasG;
    
    // Very simple constructor
    public BattleField() {
    	super();
    	
    	wxsize = 570;
    	wysize = 570;
    }
    
    public BattleField(int width, int heigth)
    {
    	super();
    	
    	wxsize = width;
    	wysize = heigth;
    }
    
	public void init()
    {
        super.init();
        
        resize(wxsize, wysize);
        canvasimage = createImage(wxsize, wysize);
        canvasG = canvasimage.getGraphics();
        
        this.getContentPane().setBackground(bgColor);
        
        addMouseListener(this);

        initSurface();
        initMaillage();
        initTeams();
    }

    public void initSurface() {
        surface = new Surface(5, wxsize,wysize);
    }
    
    public void initMaillage() {
    	maillage = new Maillage(25, surface);   	
    }
    
    public void initTeams() {
    	team1 = new Team(10, maillage, Color.BLUE);
    	team2 = new Team(10, maillage, Color.RED);
    	
    	team1.setEnnemis(team2);
    	team2.setEnnemis(team1);
    }

    public static void main(String args[])
    {
    	int size = 570;
        new MainFrame(new BattleField(size, size), size, size); //on cree la fenetre
    }
    
    public void start()
    {
        if(update == null)
        {
            update = new Thread(this);
            update.start();
        }
    }

    public void stop()
    {
        update = null;
    }

    // The main loop of the applet... We sleep a lot...
    public void run()
    {
    	do
        {
    		//on fait l'animation
        	anim();
			//on met a jour l'affichage
			paint(this.getGraphics());
			
			//on dort
			try {
				Thread.sleep((long) 33);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
        } while(true);
    }
    
    // anim the scene
    public void anim()
    {
    	//apparition des powerup
    	PowerUp.event(maillage);
    	
    	//met a jour les positions des unites des equipes
    	team1.move();
    	team2.move();
    }

    public void paint(Graphics g) {
		super.paint(canvasG);
		
        surface.draw(canvasG);
        maillage.draw(canvasG);
        PowerUp.drawAll(canvasG);
        team1.draw(canvasG);
        team2.draw(canvasG);
        
        update(g);
    }
    
    public void update(Graphics g)
    {
        //affiche le buffer
    	g.drawImage(canvasimage, 0, 0, this);
    }

    public void mouseClicked(MouseEvent e) {
		levelDetail = (levelDetail + 1) % 4;
	}

	public void mouseEntered(MouseEvent e) {}
	public void mouseExited(MouseEvent e) {}
	public void mousePressed(MouseEvent e) {}
	public void mouseReleased(MouseEvent e) {}
}
