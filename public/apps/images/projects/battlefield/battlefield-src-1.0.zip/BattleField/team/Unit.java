package team;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;

import applets.BattleField;

import surface.Surface;
import utils.Object2d;
import utils.Vector2d;
import weapon.Ammo;
import weapon.Weapon;

public abstract class Unit extends Object2d {
	Color teamColor;
	public Weapon currWeapon;
	
	Boid boidParent;
	
	Team teamEnnemi;
	
	int tailleTeamInfo;
	
	public Unit(Surface surface, Color teamColor, Boid boidParent) {
		super(surface);
		this.boidParent = boidParent;
		currWeapon = new Weapon(surface);
		
		this.teamColor = teamColor;
		
		maxLife = 100;
		life = maxLife;
		
		maxSpeed = 5;
		taille = 5;
		tailleTeamInfo = 2;
	}

	public void draw(Graphics g) {
		//affiche le point de l'unite
		coord.fillCircle(g, taille);
		coord.drawLine(g, coord.add(speed.scale(10)));
		
		g.setColor(teamColor);
		coord.fillCircle(g, tailleTeamInfo);
		
		//affiche les balles tirees par l'unite
		currWeapon.draw(g);
		
		if(BattleField.levelDetail >= 2) {
			//affiche la vision de tir
			coord.drawCircle(g, currWeapon.currView);
		}
		
		//affiche la vie de l'unite
		Vector2d rectCoord = new Vector2d(coord);
		rectCoord.x -= 10;
		rectCoord.y -= 15;
		g.drawRect((int)rectCoord.x, (int)rectCoord.y, 20, 2);
		g.fillRect((int)rectCoord.x, (int)rectCoord.y, (int)(20 * life / maxLife), 2);
	}
	
	public void moveInFreePlace() {
		Vector2d futurCoord = coord.add(speed);
		
		/*while(!surface.cansee(coord, futurCoord)) {
			//on se deplace n'importe ou!!
			futurCoord = coord.add(Vector2d.randVect(5));
		}
		
		coord = futurCoord;*/
		
		//coord = projete sur de futurCoord sur le segment le plus proche s'il y a une collision
		surface.canseeGetProjection(coord, futurCoord);
		
		shoot();
	}
	
	private void shoot() {
		currWeapon.anim(teamEnnemi);
		
		if(currWeapon.canShoot()) {
			//l'unite tire sur le premier ennemi qu'elle voit
			Unit itEnnemi;
			Iterator<Unit> it = teamEnnemi.getUnits().iterator();
			while(it.hasNext()) {
				itEnnemi = it.next();
				if(canSee(itEnnemi, currWeapon.currView)) {
					currWeapon.shoot(coord, itEnnemi.coord.subtract(coord));
				}
			}
		}
	}

	public void setEnnemis(Team teamEnnemi) {
		this.teamEnnemi = teamEnnemi;
	}
	
	//l'unite est touchee par une balle
	public void touch(Ammo ammo) {
		life -= ammo.damage;
		
		if(life <= 0) {
			//l'unite est morte
			boidParent.unitKilled(this);
		}
	}

	public abstract boolean isLeader();
	
	//retourne tous les voisins allies de l'unite autour d'un rayon d'action
	public ArrayList<Unit> getVoisins(int rayon) {
		ArrayList<Unit> voisins = new ArrayList<Unit>();
		
		Unit uIt;
		Iterator<Unit> it = getTeam().getUnits().iterator();
		while(it.hasNext()) {
			uIt = it.next();
			if(coord.distance2(uIt.coord) <= rayon*rayon) {
				voisins.add(uIt);
			}
		}
		
		return voisins;
	}

	private Team getTeam() {
		return boidParent.parentTeam;
	}
}