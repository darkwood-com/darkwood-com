package team;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import patch.AStar;
import patch.Flag;
import patch.Maillage;

public class Boid {
	UnitLeader leader;
	ArrayList<UnitFollower> units;
	
	Team parentTeam;
	
	//nbBoid correspond au nombre de boids qui suivent le leader
	public Boid(int nbBoid, Maillage maillage, Color teamColor, Team parentTeam) {
		this.parentTeam = parentTeam;
		
		//on positionne le leader sur le terrain de facon a ce qu'il voit un flag
		leader = new UnitLeader(maillage.randValidPointInSurfaceSeeOneFlag(), maillage, teamColor, this);
		
		units = new ArrayList<UnitFollower>();
		
		for(int i = 0; i < nbBoid; i++) {
			units.add(new UnitFollower(leader, maillage.surface, teamColor, this));
		}
	}
	
	public void move() {
		leader.move();
		
		Iterator<UnitFollower> it = units.iterator();
		while(it.hasNext()) {
			it.next().move(units);
		}
	}

	public void draw(Graphics g) {
		g.setColor(Color.RED);
		leader.draw(g);
		
		Iterator<UnitFollower> it = units.iterator();
		while(it.hasNext()) {
			it.next().draw(g);
		}
	}

	public void setEnnemis(Team teamEnnemi) {
		leader.setEnnemis(teamEnnemi);
		
		Iterator<UnitFollower> it = units.iterator();
		while(it.hasNext()) {
			it.next().setEnnemis(teamEnnemi);
		}
	}

	public ArrayList<Unit> getUnits() {
		ArrayList<Unit> units = new ArrayList<Unit>();
		
		units.add(leader);
		units.addAll(this.units);
		
		return units;
	}

	//une unite a ete tuee
	public void unitKilled(Unit unit) {
		if(unit.isLeader()) {
			//on regarde s'il est tout seul
			if(units.size() == 0) {
				parentTeam.boidKilled(this);
				return;
			}
			
			//sinon on choisit un nouveau leader dans les boids follower
			UnitFollower getOneFollower = units.remove(0);
			
			//ici : code krad. Il aurait fallut faire le pattern State
			//le leader devient le follower
			leader.become(getOneFollower);
		} else {
			//on retire le follower qui vient d'etre tue
			units.remove(unit);
		}
		
		//on met a jour les unite dans la team
		parentTeam.updateUnitsInTeam();
	}
}
