package team;

import item.Base;
import item.Item;
import item.PowerUp;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;

import applets.BattleField;

import patch.AStar;
import patch.Flag;
import patch.Maillage;
import patch.Path;
import patch.PointWithFlag;
import surface.Surface;
import utils.Object2d;
import utils.Vector2d;

public class UnitLeader extends Unit {
	Object2d nextPos; //position que l'on doit atteindre
	Item target;
	
    AStar aStar;
	Maillage maillage;
	final int lifeTimeAStarMax = 250;
	int lifeTimeAStar;
    
    public UnitLeader(PointWithFlag startPos, Maillage maillage, Color teamColor, Boid boidParent) {
    	super(maillage.surface, teamColor, boidParent);
		this.maillage = maillage;
    	
		coord.set(startPos.point); //point le plus pres
		nextPos = startPos.flag;
		
		aStar = new AStar(maillage);
		Flag closedFlag = startPos.flag; //flag visible le plus proche
		newPathAStar(Base.getBaseAllie(teamColor), closedFlag);
		
		lifeTimeAStar = lifeTimeAStarMax;
	}

    public void newPathAStar(Item targetItem, Flag startFlag) {
    	aStar.searchPath(startFlag, targetItem);
    	target = targetItem;
    }
    
	public void move() {
		lifeTimeAStar --;
		//si l'item vers lequel on va a ete detruit
		if(target.removed == true || lifeTimeAStar < 0) {
			newDecision(); //on prend une nouvelle decision
		}
		
		//vitesse recherchee
		Vector2d reachSpeed = nextPos.coord.subtract(coord);
		reachSpeed.setApproximateTruncate(maxSpeed);
		
		//on linearise la vitesse courante avec la vitesse recherchee
		//par un coefficient alpha
		float alpha = (float) 0.90;
		speed = speed.scale(alpha).add(reachSpeed.scale(1-alpha));
		
		moveInFreePlace();
		
		//quand on se deplace,
		//on regarde si on ne voit pas directement un obj du chemin
		//que l'on aura a atteindre plus tard
		Object2d nextVisibleObj = aStar.currPath.nextVisibleObj(this, surface);
		if(nextVisibleObj != null) {
			nextPos = nextVisibleObj;
		}
		
		//quand on approche l'objet on vise l'objet suivant
		if (coord.distance2(nextPos.coord) < 5*5) {
			nextPos = aStar.currPath.nextVisibleObj(this, surface);
			
			//on a atteint la destination
			if(nextPos == target)
			{
				target.takenBy(this); //on prend l'item
				
				newDecision(); //on prend une nouvelle decision
			}
		}
	}
	
	//decision prise par l'unite leader pour choisir sa prochaine destination
	public void newDecision() {
		lifeTimeAStar = lifeTimeAStarMax;
		Flag seeFlag = maillage.getSeeFlag(coord.subtract(speed));
		if(seeFlag == null)
		{
			seeFlag = aStar.currPath.getLastSeenFlag();
		}
		
		//on regarde s'il n'y a pas d'autres powerup
		PowerUp pu = PowerUp.getOne();
		if(pu != null) {
			newPathAStar(pu, seeFlag);
		} else {
			//sinon on rentre a la base
			newPathAStar(Base.getBaseAllie(teamColor), seeFlag);
		}
	}
	
	public void draw(Graphics g) {
		if(BattleField.levelDetail >= 1) {
	        aStar.draw(g);
		}
        
		g.setColor(Color.GREEN);
		super.draw(g);
	}

	public boolean isLeader() {
		return true;
	}
	
	//le leader devient le follower passe en paramettre
	public void become(UnitFollower getOneFollower) {
		coord = getOneFollower.coord;
		speed = getOneFollower.speed;
		life = getOneFollower.life;
		maxLife = getOneFollower.maxLife;
	}

}
