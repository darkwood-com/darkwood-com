package team;

import item.Base;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

import patch.Maillage;

public class Team {
	ArrayList<Boid> boids;
	ArrayList<Unit> unitsInTeam;
	
	Base base; //base a defendre
	
	public Team(int nbUnit, Maillage maillage, Color teamColor) {
		base = new Base(maillage, teamColor);
		
		boids = new ArrayList<Boid>();
		if(nbUnit > 0) {
			boids.add(new Boid(nbUnit-1, maillage, teamColor, this));
		}
		
		unitsInTeam = new ArrayList<Unit>();
		updateUnitsInTeam();
	}

	public void move() {
		Iterator<Boid> it = boids.iterator();
		while(it.hasNext()) {
			it.next().move();
		}
	}

	public void draw(Graphics g) {
		base.draw(g);
		
		Iterator<Boid> it = boids.iterator();
		while(it.hasNext()) {
			it.next().draw(g);
		}
	}

	public void setEnnemis(Team teamEnnemi) {
		Iterator<Boid> it = boids.iterator();
		while(it.hasNext()) {
			it.next().setEnnemis(teamEnnemi);
		}
	}
	
	//met a jour les unites de la team
	public void updateUnitsInTeam() {
		unitsInTeam.clear();
		
		Iterator<Boid> it = boids.iterator();
		while(it.hasNext()) {
			unitsInTeam.addAll(it.next().getUnits());
		}
	}
	
	//on retourne toutes les unites du team
	public ArrayList<Unit> getUnits() {
		return unitsInTeam;
	}
	
	//on a un groupe de boids qui a ete tue
	public void boidKilled(Boid boidKilled) {
		boids.remove(boidKilled);
		
		updateUnitsInTeam();
	}
}
