package team;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

import applets.BattleField;

import surface.Surface;
import utils.Vector2d;

public class UnitFollower extends Unit {
	UnitLeader leader; //leader que l'on suit
	
	ArrayList<Unit> voisins;
	
	final float distanceVoisinCarre = 100*100;
	
	Vector2d steerSeparation;
	Vector2d steerAlignment;
	Vector2d steerCohesion;
	
	float maxSpeedArriver;
	
	public UnitFollower(UnitLeader other, Surface surface, Color teamColor, Boid boidParent) {
		super(surface, teamColor, boidParent);
		
		coord = other.coord;
		Vector2d startPos = null;
		do {
			//on place le point dans une zone ou il n'y a pas de mur
			startPos = coord.add(Vector2d.randVect(50));
		} while(surface.collide(startPos) != null);
		
		coord = startPos;
		
		voisins = new ArrayList<Unit>();
		
		steerSeparation = new Vector2d(); //vecteur qui repouse par rapport aux voisins
		steerAlignment = new Vector2d(); //moyenne des vitesses des voisins pour l'alignement
		steerCohesion = new Vector2d(); //vecteur qui va vers le baricentre des voisins
		
		maxSpeedArriver = maxSpeed;
		
		this.leader = other;
	}
	
	public void draw(Graphics g) {
		g.setColor(Color.GRAY);
		super.draw(g);
		
		if(BattleField.levelDetail >= 3) {
			g.setColor(Color.RED);
			coord.drawLine(g, coord.add(steerSeparation.scale(10)));
			g.setColor(Color.GREEN);
			coord.drawLine(g, coord.add(steerAlignment.scale(10)));
			g.setColor(Color.BLUE);
			coord.drawLine(g, coord.add(steerCohesion.scale(10)));
		}
	}

	public boolean move(ArrayList<UnitFollower> units) {
		
		speed = leader.coord.subtract(coord);
		speed.setApproximateTruncate(maxSpeedArriver);
		
		//quand on approche du leader on diminue la vitesse
		if (coord.distance(leader.coord) < 50) {
			//speed.set(0, 0);
			
			maxSpeedArriver = (float) (maxSpeedArriver * 0.9);
			if(maxSpeedArriver < 0.1) {
				maxSpeedArriver = (float) 0.1;
				speed.set(0, 0);
			}
		} else {
			//sinon on l'augmente
			maxSpeedArriver = Math.min( (float)(maxSpeedArriver * 1 / 0.9), maxSpeed);
		}
		//System.out.println(maxSpeedArriver);
		
		//on recupere les voisin les plus proches
		voisins.clear();
		if(coord.distance2(leader.coord) < distanceVoisinCarre) {
			voisins.add(leader);
		}
		
		UnitFollower uf;
		Iterator<UnitFollower> it = units.iterator();
		while(it.hasNext()) {
			uf = it.next();
			if(uf == this) continue;
			if(coord.distance2(uf.coord) < distanceVoisinCarre) {
				voisins.add(uf);
			}
		}
		
		//3 regles a respecter
		steerSeparation.set(0, 0);
		steerAlignment.set(0, 0);
		steerCohesion.set(0, 0);
		Unit ufV;
		Vector2d itVect;
		Iterator<Unit> itV = voisins.iterator();
		float lenght;
		while(itV.hasNext()) {
			ufV = itV.next();
			
			//separation
			itVect = ufV.coord.subtract(coord);
			lenght = itVect.magnitude();
			itVect.setScale(-1/Math.max(lenght, 10), itVect);
			steerSeparation.setAdd(itVect);
			
			//alignement
			steerAlignment.setAdd(ufV.speed);
			
			//cohesion
			steerCohesion.setAdd(ufV.coord);
		}
		int nbVoisin = voisins.size();
		if(nbVoisin != 0)
		{
			steerAlignment.setScale(1/(float)nbVoisin, steerAlignment);
			steerCohesion.setScale(1/(float)nbVoisin, steerCohesion);
			steerCohesion.setSubtract(coord);
		}
		
		steerAlignment.setScale(1/(float)5, steerAlignment);
		steerCohesion.setScale(1/(float)10, steerCohesion);
		
		speed.setAdd(steerSeparation);
		speed.setAdd(steerAlignment);
		speed.setAdd(steerCohesion);
		
		moveInFreePlace();
		
		return false;
	}

	public boolean isLeader() {
		return false;
	}
}
